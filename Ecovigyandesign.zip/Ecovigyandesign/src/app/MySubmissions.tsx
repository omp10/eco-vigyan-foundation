import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, 
  Calendar, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Award,
  Trash2,
  ExternalLink,
  Filter,
  ChevronDown,
  ChevronUp,
  ImageIcon,
  Navigation,
  Camera,
  Info,
  ArrowLeft,
  TrendingUp,
  Shield
} from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { useAuth } from './contexts/AuthContext';
import { useNavigate, Link } from 'react-router';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { toast } from 'sonner';

const OBSERVATIONS_KEY = 'ecovigyan_observations';

// Enhanced observation interface matching admin requirements
export interface MushroomObservation {
  id: string;
  userId: string;
  
  // Basic Info
  commonName?: string;
  scientificName?: string;
  description?: string;
  
  // Location & Time
  location: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  photoTimestamp?: string; // When photo was taken (from EXIF)
  submittedAt: string; // When submitted to platform
  
  // Status & Review
  status: 'pending' | 'approved' | 'rejected';
  approvedAt?: string;
  approvedBy?: string; // Admin who approved
  rejectedAt?: string;
  rejectionReason?: string; // Visible to user
  
  // Classification (added by admin)
  ecologicalRole?: string[];
  texture?: string;
  underside?: string;
  fruitingSurface?: string;
  stemPresence?: string;
  properties?: string[];
  
  // Media
  images: string[];
  
  // Admin Notes
  internalNotes?: string; // Not visible to user
  adminNotes?: string; // Legacy field
}

export default function MySubmissions() {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  const [observations, setObservations] = useState<MushroomObservation[]>([]);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [expandedItem, setExpandedItem] = useState<string | null>(null);
  const [observationToDelete, setObservationToDelete] = useState<MushroomObservation | null>(null);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
      return;
    }
    loadObservations();
  }, [isAuthenticated, navigate, user]);

  const loadObservations = () => {
    const stored = JSON.parse(localStorage.getItem(OBSERVATIONS_KEY) || '[]');
    const userObservations = stored.filter((o: MushroomObservation) => o.userId === user?.id);
    setObservations(userObservations);
  };

  const handleDelete = (observation: MushroomObservation) => {
    setObservationToDelete(observation);
  };

  const confirmDelete = () => {
    if (!observationToDelete) return;

    // Load all observations
    const allObservations = JSON.parse(localStorage.getItem(OBSERVATIONS_KEY) || '[]');
    const updated = allObservations.filter((o: MushroomObservation) => o.id !== observationToDelete.id);
    localStorage.setItem(OBSERVATIONS_KEY, JSON.stringify(updated));

    setObservationToDelete(null);
    loadObservations();
    toast.success('Submission deleted successfully');
  };

  const getFilteredObservations = () => {
    if (filter === 'all') return observations;
    return observations.filter(o => o.status === filter);
  };

  const filteredObservations = getFilteredObservations();

  const stats = {
    all: observations.length,
    pending: observations.filter(o => o.status === 'pending').length,
    approved: observations.filter(o => o.status === 'approved').length,
    rejected: observations.filter(o => o.status === 'rejected').length,
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'approved':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'rejected':
        return 'bg-red-50 text-red-700 border-red-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return Clock;
      case 'approved':
        return CheckCircle;
      case 'rejected':
        return XCircle;
      default:
        return AlertCircle;
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCoordinates = (coords: { lat: number; lng: number }) => {
    return `${coords.lat.toFixed(6)}°, ${coords.lng.toFixed(6)}°`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <Link 
              to="/dashboard"
              className="inline-flex items-center gap-2 text-emerald-600 hover:text-emerald-700 font-semibold mb-4 transition-colors"
            >
              <ArrowLeft size={20} />
              Back to Dashboard
            </Link>

            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  My Submissions
                </h1>
                <p className="text-gray-600">
                  Track your mushroom observation submissions and their review status
                </p>
              </div>
            </div>
          </motion.div>

          {/* Stats Cards */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
          >
            {[
              { label: 'All', value: stats.all, icon: Filter, color: 'bg-blue-500' },
              { label: 'Pending', value: stats.pending, icon: Clock, color: 'bg-amber-500' },
              { label: 'Approved', value: stats.approved, icon: CheckCircle, color: 'bg-emerald-500' },
              { label: 'Rejected', value: stats.rejected, icon: XCircle, color: 'bg-red-500' },
            ].map((stat) => {
              const Icon = stat.icon;
              const isActive = filter === stat.label.toLowerCase();
              
              return (
                <button
                  key={stat.label}
                  onClick={() => setFilter(stat.label.toLowerCase() as any)}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    isActive 
                      ? 'bg-white border-emerald-500 shadow-lg scale-105' 
                      : 'bg-white border-gray-200 hover:border-gray-300 hover:shadow-md'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className={`w-10 h-10 rounded-lg ${stat.color} flex items-center justify-center`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-2xl font-bold text-gray-900">{stat.value}</span>
                  </div>
                  <div className="text-sm font-semibold text-gray-600">{stat.label}</div>
                </button>
              );
            })}
          </motion.div>

          {/* Filter Info */}
          <div className="mb-6 flex items-center justify-between">
            <div className="text-sm text-gray-600">
              Showing <span className="font-bold text-gray-900">{filteredObservations.length}</span> {filter === 'all' ? 'total' : filter} submission{filteredObservations.length !== 1 ? 's' : ''}
            </div>
          </div>

          {/* Submissions List */}
          <div className="space-y-4">
            <AnimatePresence mode="popLayout">
              {filteredObservations.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="bg-white rounded-xl p-12 text-center border border-gray-200"
                >
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">No submissions yet</h3>
                  <p className="text-gray-600 mb-6">
                    Start contributing by submitting your mushroom observations
                  </p>
                  <Link
                    to="/shroomhub"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700 transition-colors"
                  >
                    <MapPin className="w-5 h-5" />
                    Go to Mushroom Hub
                  </Link>
                </motion.div>
              ) : (
                filteredObservations.map((observation, index) => {
                  const isExpanded = expandedItem === observation.id;
                  const StatusIcon = getStatusIcon(observation.status);

                  return (
                    <motion.div
                      key={observation.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ delay: index * 0.05 }}
                      className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow"
                    >
                      {/* Main Card */}
                      <div className="p-6">
                        <div className="flex flex-col md:flex-row gap-6">
                          {/* Image Thumbnail */}
                          <div className="w-full md:w-48 h-48 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                            {observation.images && observation.images.length > 0 ? (
                              <ImageWithFallback
                                src={observation.images[0]}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <ImageIcon className="w-12 h-12 text-gray-300" />
                              </div>
                            )}
                          </div>

                          {/* Info */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between mb-4">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-3 mb-2">
                                  <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border ${getStatusColor(observation.status)}`}>
                                    <StatusIcon className="w-3.5 h-3.5" />
                                    {observation.status.charAt(0).toUpperCase() + observation.status.slice(1)}
                                  </span>
                                </div>
                                
                                <h3 className="text-xl font-bold text-gray-900 mb-1">
                                  {observation.commonName || 'Unidentified Mushroom'}
                                </h3>
                                
                                {observation.scientificName && (
                                  <p className="text-sm text-gray-600 italic mb-2">{observation.scientificName}</p>
                                )}
                              </div>

                              {/* Actions */}
                              <button
                                onClick={() => handleDelete(observation)}
                                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                title="Delete submission"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>

                            {/* Key Details */}
                            <div className="grid md:grid-cols-2 gap-3 mb-4">
                              <div className="flex items-start gap-2 text-sm">
                                <MapPin className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                                <span className="text-gray-700">{observation.location}</span>
                              </div>
                              
                              <div className="flex items-center gap-2 text-sm">
                                <Navigation className="w-4 h-4 text-gray-400 flex-shrink-0" />
                                <span className="text-gray-700 font-mono text-xs">
                                  {formatCoordinates(observation.coordinates)}
                                </span>
                              </div>
                              
                              <div className="flex items-center gap-2 text-sm">
                                <Clock className="w-4 h-4 text-gray-400 flex-shrink-0" />
                                <span className="text-gray-600">
                                  Submitted: {formatDate(observation.submittedAt)}
                                </span>
                              </div>
                              
                              {observation.photoTimestamp && (
                                <div className="flex items-center gap-2 text-sm">
                                  <Camera className="w-4 h-4 text-gray-400 flex-shrink-0" />
                                  <span className="text-gray-600">
                                    Photo: {formatDate(observation.photoTimestamp)}
                                  </span>
                                </div>
                              )}
                            </div>

                            {/* Status-Specific Info */}
                            {observation.status === 'approved' && observation.approvedAt && (
                              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 mb-4">
                                <div className="flex items-start gap-2">
                                  <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                                  <div className="text-sm">
                                    <p className="font-semibold text-emerald-900 mb-1">Approved</p>
                                    <p className="text-emerald-700">
                                      {formatDate(observation.approvedAt)}
                                      {observation.approvedBy && ` by ${observation.approvedBy}`}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            )}

                            {observation.status === 'rejected' && observation.rejectionReason && (
                              <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                                <div className="flex items-start gap-2">
                                  <XCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                                  <div className="text-sm">
                                    <p className="font-semibold text-red-900 mb-1">Rejection Reason</p>
                                    <p className="text-red-700">{observation.rejectionReason}</p>
                                    {observation.rejectedAt && (
                                      <p className="text-red-600 text-xs mt-1">{formatDate(observation.rejectedAt)}</p>
                                    )}
                                  </div>
                                </div>
                              </div>
                            )}

                            {observation.status === 'pending' && (
                              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4">
                                <div className="flex items-start gap-2">
                                  <Clock className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                                  <div className="text-sm">
                                    <p className="font-semibold text-amber-900">Under Review</p>
                                    <p className="text-amber-700">Your submission is being reviewed by our team</p>
                                  </div>
                                </div>
                              </div>
                            )}

                            {/* Expand/Collapse Button */}
                            <button
                              onClick={() => setExpandedItem(isExpanded ? null : observation.id)}
                              className="flex items-center gap-2 text-sm font-semibold text-emerald-600 hover:text-emerald-700 transition-colors"
                            >
                              {isExpanded ? (
                                <>
                                  <ChevronUp className="w-4 h-4" />
                                  Hide Details
                                </>
                              ) : (
                                <>
                                  <ChevronDown className="w-4 h-4" />
                                  Show More Details
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Expanded Details */}
                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.3 }}
                            className="border-t border-gray-200 bg-gray-50 overflow-hidden"
                          >
                            <div className="p-6 space-y-6">
                              {/* Classification Details */}
                              {observation.status === 'approved' && (
                                <div>
                                  <h4 className="text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
                                    <Shield className="w-4 h-4 text-emerald-600" />
                                    Classification Details
                                  </h4>
                                  <div className="grid md:grid-cols-2 gap-4">
                                    {observation.ecologicalRole && observation.ecologicalRole.length > 0 && (
                                      <div>
                                        <div className="text-xs font-semibold text-gray-500 mb-1">Ecological Role</div>
                                        <div className="flex flex-wrap gap-1">
                                          {observation.ecologicalRole.map(role => (
                                            <span key={role} className="px-2 py-1 bg-emerald-100 text-emerald-700 rounded text-xs font-medium">
                                              {role}
                                            </span>
                                          ))}
                                        </div>
                                      </div>
                                    )}
                                    
                                    {observation.texture && (
                                      <div>
                                        <div className="text-xs font-semibold text-gray-500 mb-1">Texture</div>
                                        <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs font-medium">
                                          {observation.texture}
                                        </span>
                                      </div>
                                    )}
                                    
                                    {observation.undersideStructure && (
                                      <div>
                                        <div className="text-xs font-semibold text-gray-500 mb-1">Underside Structure</div>
                                        <span className="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs font-medium">
                                          {observation.undersideStructure}
                                        </span>
                                      </div>
                                    )}
                                    
                                    {observation.fruitingSurface && (
                                      <div>
                                        <div className="text-xs font-semibold text-gray-500 mb-1">Fruiting Surface</div>
                                        <span className="px-2 py-1 bg-amber-100 text-amber-700 rounded text-xs font-medium">
                                          {observation.fruitingSurface}
                                        </span>
                                      </div>
                                    )}
                                    
                                    {observation.hasStem !== undefined && (
                                      <div>
                                        <div className="text-xs font-semibold text-gray-500 mb-1">Stem</div>
                                        <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium">
                                          {observation.hasStem ? 'Has stem' : 'No stem'}
                                        </span>
                                      </div>
                                    )}
                                    
                                    {observation.commonUses && observation.commonUses.length > 0 && (
                                      <div className="md:col-span-2">
                                        <div className="text-xs font-semibold text-gray-500 mb-1">Common Uses</div>
                                        <div className="flex flex-wrap gap-1">
                                          {observation.commonUses.map(use => (
                                            <span 
                                              key={use} 
                                              className={`px-2 py-1 rounded text-xs font-medium ${
                                                use === 'poisonous' ? 'bg-red-100 text-red-700' :
                                                use === 'edible' ? 'bg-green-100 text-green-700' :
                                                use === 'medicinal' ? 'bg-indigo-100 text-indigo-700' :
                                                'bg-gray-100 text-gray-700'
                                              }`}
                                            >
                                              {use}
                                            </span>
                                          ))}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              )}

                              {/* Description */}
                              {observation.description && (
                                <div>
                                  <h4 className="text-sm font-bold text-gray-900 mb-2">Description</h4>
                                  <p className="text-sm text-gray-700">{observation.description}</p>
                                </div>
                              )}

                              {/* All Images */}
                              {observation.images && observation.images.length > 1 && (
                                <div>
                                  <h4 className="text-sm font-bold text-gray-900 mb-3">All Images ({observation.images.length})</h4>
                                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                    {observation.images.map((img, idx) => (
                                      <div key={idx} className="aspect-square rounded-lg overflow-hidden bg-gray-100">
                                        <ImageWithFallback
                                          src={img}
                                          className="w-full h-full object-cover"
                                        />
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {/* View on Map Link */}
                              <Link
                                to="/shroomhub"
                                className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg font-semibold text-sm hover:bg-emerald-700 transition-colors"
                              >
                                <ExternalLink className="w-4 h-4" />
                                View on Map
                              </Link>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      <Footer />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={!!observationToDelete}
        onClose={() => setObservationToDelete(null)}
        onConfirm={confirmDelete}
        title="Delete Submission"
        message="Are you sure you want to delete this submission? This action cannot be undone."
      />
    </div>
  );
}