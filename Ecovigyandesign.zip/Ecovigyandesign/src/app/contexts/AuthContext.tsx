import React, { createContext, useContext, useState, useEffect } from 'react';

// Authentication Context for Eco Vigyan Foundation
export type UserRole = 'visitor' | 'member' | 'writer' | 'admin';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
  joinedDate: string;
  phone?: string;
  bio?: string;
  school?: string;
  authProvider?: 'email' | 'google';
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  updateProfile: (updates: { name: string; email: string; phone?: string; bio?: string; school?: string; avatar?: string }) => Promise<{ success: boolean; error?: string }>;
  changePassword: (oldPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string; resetToken?: string }>;
  verifyResetToken: (email: string, token: string) => Promise<{ success: boolean; error?: string }>;
  updatePasswordWithToken: (email: string, token: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: () => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users database (stored in localStorage)
const MOCK_USERS_KEY = 'ecovigyan_users';
const CURRENT_USER_KEY = 'ecovigyan_current_user';
const RESET_TOKENS_KEY = 'ecovigyan_reset_tokens';

// Default admin account
const DEFAULT_ADMIN = {
  id: 'admin-001',
  email: 'admin@ecovigyan.org',
  password: 'admin123', // In production, this would be hashed
  name: 'Admin User',
  role: 'admin' as UserRole,
  joinedDate: '2024-01-01'
};

// Demo member accounts
const DEMO_MEMBERS = [
  {
    id: 'member-001',
    email: 'student@example.com',
    password: 'student123',
    name: 'Demo Student',
    role: 'member' as UserRole,
    joinedDate: '2024-02-15'
  },
  {
    id: 'member-002',
    email: 'scientist@example.com',
    password: 'scientist123',
    name: 'Demo Scientist',
    role: 'member' as UserRole,
    joinedDate: '2024-03-20'
  },
  {
    id: 'writer-001',
    email: 'writer@example.com',
    password: 'writer123',
    name: 'Demo Writer',
    role: 'writer' as UserRole,
    joinedDate: '2024-01-10'
  }
];

const initializeMockDatabase = () => {
  const stored = localStorage.getItem(MOCK_USERS_KEY);
  if (!stored) {
    const users = [DEFAULT_ADMIN, ...DEMO_MEMBERS];
    localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));
  } else {
    // Ensure writer account exists in existing database
    try {
      const users = JSON.parse(stored);
      const hasWriter = users.some((u: any) => u.email === 'writer@example.com');
      if (!hasWriter) {
        const writerAccount = {
          id: 'writer-001',
          email: 'writer@example.com',
          password: 'writer123',
          name: 'Demo Writer',
          role: 'writer' as UserRole,
          joinedDate: '2024-01-10'
        };
        users.push(writerAccount);
        localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));
      }
    } catch (error) {
      // If parsing fails, reinitialize
      const users = [DEFAULT_ADMIN, ...DEMO_MEMBERS];
      localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));
    }
  }
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Initialize mock database
    initializeMockDatabase();

    // Check for existing session
    const storedUser = localStorage.getItem(CURRENT_USER_KEY);
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
      } catch (error) {
        console.error('Failed to parse stored user:', error);
        localStorage.removeItem(CURRENT_USER_KEY);
      }
    }
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const usersData = localStorage.getItem(MOCK_USERS_KEY);
    if (!usersData) {
      return { success: false, error: 'System error. Please try again.' };
    }

    const users = JSON.parse(usersData);
    const foundUser = users.find((u: any) => u.email === email && u.password === password);

    if (foundUser) {
      const { password, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userWithoutPassword));
      return { success: true };
    }

    return { success: false, error: 'Invalid email or password' };
  };

  const signup = async (name: string, email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const usersData = localStorage.getItem(MOCK_USERS_KEY);
    if (!usersData) {
      return { success: false, error: 'System error. Please try again.' };
    }

    const users = JSON.parse(usersData);
    
    // Check if email already exists
    const existingUser = users.find((u: any) => u.email === email);
    if (existingUser) {
      return { success: false, error: 'Email already registered' };
    }

    // Create new user
    const newUser = {
      id: `member-${Date.now()}`,
      email,
      password,
      name,
      role: 'member' as UserRole,
      joinedDate: new Date().toISOString()
    };

    users.push(newUser);
    localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));

    // Auto-login after signup
    const { password: _, ...userWithoutPassword } = newUser;
    setUser(userWithoutPassword);
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userWithoutPassword));

    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(CURRENT_USER_KEY);
  };

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updatedUser));
    }
  };

  const updateProfile = async (updates: { name: string; email: string; phone?: string; bio?: string; school?: string; avatar?: string }): Promise<{ success: boolean; error?: string }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const usersData = localStorage.getItem(MOCK_USERS_KEY);
    if (!usersData) {
      return { success: false, error: 'System error. Please try again.' };
    }

    const users = JSON.parse(usersData);
    const foundUserIndex = users.findIndex((u: any) => u.id === user?.id);

    if (foundUserIndex !== -1) {
      // Don't include password in the update
      const { password } = users[foundUserIndex];
      const updatedUser = { ...users[foundUserIndex], ...updates, password };
      users[foundUserIndex] = updatedUser;
      localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));

      // Update current user (without password)
      const { password: _, ...userWithoutPassword } = updatedUser;
      setUser(userWithoutPassword);
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userWithoutPassword));

      return { success: true };
    }

    return { success: false, error: 'User not found' };
  };

  const changePassword = async (oldPassword: string, newPassword: string): Promise<{ success: boolean; error?: string }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const usersData = localStorage.getItem(MOCK_USERS_KEY);
    if (!usersData) {
      return { success: false, error: 'System error. Please try again.' };
    }

    const users = JSON.parse(usersData);
    const foundUserIndex = users.findIndex((u: any) => u.id === user?.id && u.password === oldPassword);

    if (foundUserIndex !== -1) {
      const updatedUser = { ...users[foundUserIndex], password: newPassword };
      users[foundUserIndex] = updatedUser;
      localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));

      return { success: true };
    }

    return { success: false, error: 'Invalid old password' };
  };

  const resetPassword = async (email: string): Promise<{ success: boolean; error?: string; resetToken?: string }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const usersData = localStorage.getItem(MOCK_USERS_KEY);
    if (!usersData) {
      return { success: false, error: 'System error. Please try again.' };
    }

    const users = JSON.parse(usersData);
    const foundUserIndex = users.findIndex((u: any) => u.email === email);

    if (foundUserIndex !== -1) {
      // Generate a reset token
      const resetToken = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      const resetTokens = JSON.parse(localStorage.getItem(RESET_TOKENS_KEY) || '{}');
      resetTokens[email] = resetToken;
      localStorage.setItem(RESET_TOKENS_KEY, JSON.stringify(resetTokens));

      // In a real application, you would send a password reset email here
      return { success: true, resetToken };
    }

    return { success: false, error: 'Email not found' };
  };

  const verifyResetToken = async (email: string, token: string): Promise<{ success: boolean; error?: string }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const resetTokens = JSON.parse(localStorage.getItem(RESET_TOKENS_KEY) || '{}');
    const storedToken = resetTokens[email];

    if (storedToken && storedToken === token) {
      return { success: true };
    }

    return { success: false, error: 'Invalid reset token' };
  };

  const updatePasswordWithToken = async (email: string, token: string, newPassword: string): Promise<{ success: boolean; error?: string }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const resetTokens = JSON.parse(localStorage.getItem(RESET_TOKENS_KEY) || '{}');
    const storedToken = resetTokens[email];

    if (storedToken && storedToken === token) {
      const usersData = localStorage.getItem(MOCK_USERS_KEY);
      if (!usersData) {
        return { success: false, error: 'System error. Please try again.' };
      }

      const users = JSON.parse(usersData);
      const foundUserIndex = users.findIndex((u: any) => u.email === email);

      if (foundUserIndex !== -1) {
        const updatedUser = { ...users[foundUserIndex], password: newPassword };
        users[foundUserIndex] = updatedUser;
        localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));

        // Remove the reset token
        delete resetTokens[email];
        localStorage.setItem(RESET_TOKENS_KEY, JSON.stringify(resetTokens));

        return { success: true };
      }

      return { success: false, error: 'User not found' };
    }

    return { success: false, error: 'Invalid reset token' };
  };

  const loginWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    // In a real application, you would handle Google login here
    return { success: false, error: 'Google login not implemented' };
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        signup,
        logout,
        updateUser,
        updateProfile,
        changePassword,
        resetPassword,
        verifyResetToken,
        updatePasswordWithToken,
        loginWithGoogle
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    // More helpful error message
    console.error('useAuth must be used within an AuthProvider. Make sure App.tsx wraps everything with <AuthProvider>.');
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}