import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate, useLocation } from 'react-router';
import { toast } from 'sonner';
import 'leaflet/dist/leaflet.css';
import 'leaflet-draw/dist/leaflet.draw.css';
import L from 'leaflet';
import 'leaflet.heat';
import 'leaflet-draw';
import { 
  Map as MapIcon, 
  Camera, 
  GalleryVertical, 
  Users, 
  Route, 
  Filter, 
  Search, 
  X, 
  Plus, 
  Check, 
  MapPin, 
  Info, 
  Clock, 
  ShieldCheck, 
  Zap, 
  ArrowUpRight,
  Navigation as NavigationIcon,
  ChevronRight,
  User,
  Star,
  Lock,
  Upload,
  Image as ImageIcon,
  Beaker,
  Globe,
  Trash2,
  AlertCircle,
  Sparkles,
  Play,
  Pause,
  TrendingUp,
  Layers,
  Square,
  Pentagon,
  Edit3,
  Save
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip,
  Legend
} from 'recharts';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { MUSHROOM_DATA, CONTRIBUTORS, TRAILS, CATEGORIES } from './mushroom-data';
import { useAuth } from './contexts/AuthContext';

// --- Mock Zones Data ---
const MOCK_ZONES = [
  {
    id: 1,
    name: 'Western Ghats Biodiversity Zone',
    description: 'UNESCO World Heritage Site with rich fungal diversity. Known for endemic species and monsoon-dependent mushrooms.',
    type: 'rectangle',
    bounds: [[8.5, 74.5], [13.5, 77.5]],
    creator: 'Dr. Sharma',
    createdAt: '2024-01-15',
    color: '#10B981'
  },
  {
    id: 2,
    name: 'Himalayan High Altitude Study Area',
    description: 'Critical research zone for alpine and subalpine fungi. Temperature-sensitive ecosystem.',
    type: 'polygon',
    bounds: [[30.5, 76.5], [32.0, 76.0], [33.5, 77.5], [34.0, 79.0], [32.5, 80.0], [31.0, 78.5]],
    creator: 'Admin Team',
    createdAt: '2024-02-20',
    color: '#3B82F6'
  },
  {
    id: 3,
    name: 'Sundarbans Mangrove Myco Zone',
    description: 'Unique mangrove ecosystem with specialized salt-tolerant fungi.',
    type: 'polygon',
    bounds: [[21.5, 88.2], [22.5, 88.5], [22.5, 89.2], [21.8, 89.5], [21.3, 89.0]],
    creator: 'Research Team',
    createdAt: '2024-03-10',
    color: '#8B5CF6'
  },
  {
    id: 4,
    name: 'Eastern Ghats Dry Forest Zone',
    description: 'Dry deciduous forest with seasonal mushroom diversity.',
    type: 'rectangle',
    bounds: [[12.0, 78.0], [16.0, 81.0]],
    creator: 'Dr. Kumar',
    createdAt: '2024-01-25',
    color: '#F59E0B'
  },
  {
    id: 5,
    name: 'Nilgiri Hills Protected Area',
    description: 'Shola forests and grasslands with unique mycological communities.',
    type: 'polygon',
    bounds: [[11.0, 76.3], [11.5, 76.2], [11.7, 76.8], [11.3, 77.0], [10.8, 76.7]],
    creator: 'Conservation Team',
    createdAt: '2024-02-05',
    color: '#EC4899'
  }
];

// --- Point in Polygon Algorithm (Ray Casting) ---
const isPointInPolygon = (point, polygon) => {
  const [lat, lng] = point;
  let inside = false;
  
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const [lat1, lng1] = polygon[i];
    const [lat2, lng2] = polygon[j];
    
    const intersect = ((lng1 > lng) !== (lng2 > lng)) &&
      (lat < (lat2 - lat1) * (lng - lng1) / (lng2 - lng1) + lat1);
    
    if (intersect) inside = !inside;
  }
  
  return inside;
};

// --- Check if point is in rectangle bounds ---
const isPointInRectangle = (point, bounds) => {
  const [lat, lng] = point;
  const [[south, west], [north, east]] = bounds;
  return lat >= south && lat <= north && lng >= west && lng <= east;
};

// --- Check if point is in zone ---
const isPointInZone = (point, zone) => {
  if (zone.type === 'rectangle') {
    return isPointInRectangle(point, zone.bounds);
  } else if (zone.type === 'polygon') {
    return isPointInPolygon(point, zone.bounds);
  }
  return false;
};

// --- Sub-Components ---

const StatBadge = ({ icon: Icon, label, value, color = "bg-emerald-50 text-emerald-800" }) => (
  <div className={`${color} px-4 py-2 rounded-xl flex items-center gap-2.5 text-[11px] font-bold border border-emerald-100/50 shadow-sm`}>
    <Icon size={14} className="opacity-60" />
    <span className="opacity-40 uppercase tracking-widest">{label}:</span>
    <span className="text-emerald-950">{value}</span>
  </div>
);

const SectionTitle = ({ title, subtitle, centered = false }) => (
  <div className={`mb-12 ${centered ? 'text-center' : ''}`}>
    <h2 className="text-4xl md:text-5xl font-bold font-serif text-emerald-950 mb-4 tracking-tight leading-tight">{title}</h2>
    <p className="text-emerald-800/50 max-w-4xl text-lg leading-relaxed">{subtitle}</p>
    <style dangerouslySetInnerHTML={{ __html: `
      .mushroom-popup .leaflet-popup-content-wrapper {
        padding: 0;
        overflow: hidden;
        border-radius: 24px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        border: 1px solid rgba(16, 185, 129, 0.1);
      }
      .mushroom-popup .leaflet-popup-content {
        margin: 0;
        width: auto !important;
      }
      .mushroom-popup .leaflet-popup-tip {
        background: white;
      }
    `}} />
  </div>
);

const LayerToggle = ({ active, onClick, icon, title, subtitle, color = "emerald" }) => {
  const colors = {
    emerald: { bg: 'bg-emerald-50', text: 'text-emerald-600', activeBg: 'bg-emerald-600', border: 'border-emerald-100', activeBorder: 'border-emerald-200' },
    orange: { bg: 'bg-orange-50', text: 'text-orange-600', activeBg: 'bg-orange-500', border: 'border-orange-100', activeBorder: 'border-orange-200' },
    blue: { bg: 'bg-blue-50', text: 'text-blue-600', activeBg: 'bg-blue-600', border: 'border-blue-100', activeBorder: 'border-blue-200' },
  }[color];

  return (
    <button 
      onClick={onClick} 
      className={`w-full p-4 rounded-2xl border flex items-center justify-between transition-all ${active ? `${colors.bg} ${colors.activeBorder}` : 'bg-white border-emerald-50'}`}
    >
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${active ? `${colors.activeBg} text-white` : `${colors.bg} ${colors.text}`}`}>{icon}</div>
        <div className="text-left">
          <span className="text-xs font-bold text-emerald-950 block">{title}</span>
          <span className="text-[9px] text-emerald-800/40 font-medium">{subtitle}</span>
        </div>
      </div>
      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${active ? `${colors.activeBg} border-transparent` : 'border-emerald-100'}`}>
        {active && <Check size={12} className="text-white" />}
      </div>
    </button>
  );
};

// --- 1. Explore Map Component ---
const MapExplorer = ({ observations, onAddClick, onViewDetails, isPickingLocation, onLocationPick, selectedObservation }) => {
  const mapRef = useRef(null);
  const [mapInstance, setMapInstance] = useState(null);
  const markersRef = useRef([]);
  const polygonsRef = useRef([]);
  
  const [activeFilter, setActiveFilter] = useState('All');
  const [showDelta, setShowDelta] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState('');
  const [locationSearch, setLocationSearch] = useState('');
  const [debouncedLocationSearch, setDebouncedLocationSearch] = useState('');
  const [locationBounds, setLocationBounds] = useState(null);
  const [locationName, setLocationName] = useState('');
  const [autocompleteSuggestions, setAutocompleteSuggestions] = useState([]);
  const [showAutocomplete, setShowAutocomplete] = useState(false);
  const [selectedObs, setSelectedObs] = useState(null);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [showZones, setShowZones] = useState(true);
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [showRainfall, setShowRainfall] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('filters'); // 'filters' or 'analysis'
  const [currentZoom, setCurrentZoom] = useState(5); // Track current zoom level
  const heatmapRef = useRef(null);
  const rainfallRef = useRef(null);
  const locationPolygonRef = useRef(null);
  
  // Zones state
  const [zones, setZones] = useState(MOCK_ZONES);
  const [selectedZone, setSelectedZone] = useState(null);
  const [isZonesModalOpen, setIsZonesModalOpen] = useState(false);
  const [isDrawingMode, setIsDrawingMode] = useState(false);
  const [drawingType, setDrawingType] = useState(null); // 'rectangle' or 'polygon'
  const [drawnZone, setDrawnZone] = useState(null);
  const [isSaveZoneModalOpen, setIsSaveZoneModalOpen] = useState(false);
  const [newZoneName, setNewZoneName] = useState('');
  const [newZoneDescription, setNewZoneDescription] = useState('');
  const drawControlRef = useRef(null);
  const drawnLayersRef = useRef([]);
  const zoneLayersRef = useRef([]);
  const drawnItemsRef = useRef(null); // Add ref for drawn items feature group
  const rectangleHandlerRef = useRef(null); // Add ref for rectangle handler
  const polygonHandlerRef = useRef(null); // Add ref for polygon handler
  
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  // Zoom threshold for switching between heatmap and markers
  const ZOOM_THRESHOLD = 8;

  // Debounced Species Search (300ms delay)
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchQuery(searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Debounced Location Search (800ms delay to reduce API calls)
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedLocationSearch(locationSearch);
    }, 800);
    return () => clearTimeout(timer);
  }, [locationSearch]);

  // Autocomplete Suggestions (up to 8 unique names)
  useEffect(() => {
    if (searchQuery.trim().length > 0) {
      const uniqueNames = new Set();
      observations.forEach(obs => {
        if (obs.commonName && obs.commonName.toLowerCase().includes(searchQuery.toLowerCase())) {
          uniqueNames.add(obs.commonName);
        }
        if (obs.scientificName && obs.scientificName.toLowerCase().includes(searchQuery.toLowerCase())) {
          uniqueNames.add(obs.scientificName);
        }
      });
      const suggestions = Array.from(uniqueNames).slice(0, 8);
      setAutocompleteSuggestions(suggestions);
      setShowAutocomplete(suggestions.length > 0);
    } else {
      setAutocompleteSuggestions([]);
      setShowAutocomplete(false);
    }
  }, [searchQuery, observations]);

  // Location-based Search with Nominatim API
  useEffect(() => {
    if (!debouncedLocationSearch.trim()) {
      setLocationBounds(null);
      setLocationName('');
      // Remove location polygon from map
      if (locationPolygonRef.current && mapInstance) {
        mapInstance.removeLayer(locationPolygonRef.current);
        locationPolygonRef.current = null;
      }
      return;
    }

    const fetchLocationBounds = async () => {
      try {
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(debouncedLocationSearch)}&format=json&polygon_geojson=1&limit=1`,
          {
            headers: {
              'User-Agent': 'EcoVigyanFoundation/1.0'
            }
          }
        );
        const data = await response.json();
        
        if (data && data.length > 0 && data[0].geojson) {
          const location = data[0];
          const bounds = location.boundingbox; // [south, north, west, east]
          
          setLocationBounds({
            south: parseFloat(bounds[0]),
            north: parseFloat(bounds[1]),
            west: parseFloat(bounds[2]),
            east: parseFloat(bounds[3])
          });
          setLocationName(location.display_name);

          // Draw location boundary on map
          if (mapInstance && location.geojson) {
            // Remove previous polygon
            if (locationPolygonRef.current) {
              mapInstance.removeLayer(locationPolygonRef.current);
            }

            // Add new polygon
            const geoJsonLayer = L.geoJSON(location.geojson, {
              style: {
                color: '#8B5CF6',
                weight: 3,
                opacity: 0.8,
                fillColor: '#8B5CF6',
                fillOpacity: 0.1
              }
            }).addTo(mapInstance);
            
            locationPolygonRef.current = geoJsonLayer;
            
            // Zoom to bounds
            mapInstance.fitBounds(geoJsonLayer.getBounds(), { padding: [50, 50] });
          }
        } else {
          setLocationBounds(null);
          setLocationName('');
          toast.error(`Location "${debouncedLocationSearch}" not found`);
        }
      } catch (error) {
        console.error('Location search error:', error);
        toast.error('Failed to search location');
      }
    };

    fetchLocationBounds();
  }, [debouncedLocationSearch, mapInstance]);

  // Rainfall Gradient Logic (Mocked)
  useEffect(() => {
    if (!mapInstance) return;
    if (showRainfall) {
      // Mocking a rainfall gradient using large circles
      const rainfallZones = [
        { center: [10.85, 76.27], radius: 150000, color: '#3B82F6' }, // Western Ghats
        { center: [31.10, 77.17], radius: 200000, color: '#60A5FA' }  // Himalayas
      ];
      
      const layers = rainfallZones.map(z => {
        try {
          return L.circle(z.center, {
            radius: z.radius,
            fillColor: z.color,
            fillOpacity: 0.15,
            stroke: false
          }).addTo(mapInstance);
        } catch (e) {
          console.warn("Rainfall layer error:", e);
          return null;
        }
      }).filter(Boolean);
      
      rainfallRef.current = layers;
    } else {
      if (rainfallRef.current) {
        rainfallRef.current.forEach(l => l.remove());
        rainfallRef.current = null;
      }
    }
    return () => {
      if (rainfallRef.current) {
        rainfallRef.current.forEach(l => l.remove());
      }
    };
  }, [showRainfall, mapInstance]);

  // Draw zones on map
  useEffect(() => {
    if (!mapInstance) return;
    
    // Safety check: ensure map container is still valid
    try {
      if (!mapInstance.getContainer()) return;
    } catch (e) {
      return;
    }
    
    // Remove existing zone layers
    zoneLayersRef.current.forEach(layer => {
      try {
        mapInstance.removeLayer(layer);
      } catch (e) {}
    });
    zoneLayersRef.current = [];
    
    // Draw all zones
    zones.forEach(zone => {
      let layer;
      if (zone.type === 'rectangle') {
        layer = L.rectangle(zone.bounds, {
          color: zone.color,
          weight: 2,
          opacity: 0.8,
          fillColor: zone.color,
          fillOpacity: selectedZone?.id === zone.id ? 0.25 : 0.1
        });
      } else if (zone.type === 'polygon') {
        layer = L.polygon(zone.bounds, {
          color: zone.color,
          weight: 2,
          opacity: 0.8,
          fillColor: zone.color,
          fillOpacity: selectedZone?.id === zone.id ? 0.25 : 0.1
        });
      }
      
      if (layer) {
        try {
          layer.addTo(mapInstance);
          layer.bindPopup(`
            <div style="padding: 8px;">
              <strong style="color: ${zone.color};">${zone.name}</strong>
              <p style="margin: 4px 0; font-size: 12px;">${zone.description}</p>
              <p style="margin-top: 4px; font-size: 11px; color: #666;">
                Created by ${zone.creator} on ${new Date(zone.createdAt).toLocaleDateString()}
              </p>
            </div>
          `);
          zoneLayersRef.current.push(layer);
        } catch (e) {
          console.error('Error adding zone layer:', e);
        }
      }
    });
    
    return () => {
      zoneLayersRef.current.forEach(layer => {
        try {
          mapInstance.removeLayer(layer);
        } catch (e) {}
      });
      zoneLayersRef.current = [];
    };
  }, [mapInstance, zones, selectedZone]);

  // Initialize Leaflet Draw controls (Admin only)
  useEffect(() => {
    if (!mapInstance || !isAdmin) return;
    
    // Safety check: ensure map container is still valid
    try {
      if (!mapInstance.getContainer()) return;
    } catch (e) {
      return;
    }
    
    const drawnItems = new L.FeatureGroup();
    try {
      mapInstance.addLayer(drawnItems);
      drawnItemsRef.current = drawnItems;
    } catch (e) {
      console.error('Error adding drawnItems layer:', e);
      return;
    }
    
    // Create drawing handlers
    const rectangleHandler = new L.Draw.Rectangle(mapInstance, {
      shapeOptions: {
        color: '#8B5CF6',
        weight: 3,
        fillOpacity: 0.2
      }
    });
    rectangleHandlerRef.current = rectangleHandler;
    
    const polygonHandler = new L.Draw.Polygon(mapInstance, {
      shapeOptions: {
        color: '#8B5CF6',
        weight: 3,
        fillOpacity: 0.2
      },
      showArea: false,
      allowIntersection: false
    });
    polygonHandlerRef.current = polygonHandler;
    
    // Handle drawing created
    const onDrawCreated = (e) => {
      const layer = e.layer;
      const type = e.layerType;
      
      drawnItems.addLayer(layer);
      drawnLayersRef.current.push(layer);
      
      let bounds = [];
      if (type === 'rectangle') {
        const latLngs = layer.getLatLngs()[0];
        bounds = [
          [latLngs[0].lat, latLngs[0].lng],
          [latLngs[2].lat, latLngs[2].lng]
        ];
      } else if (type === 'polygon') {
        bounds = layer.getLatLngs()[0].map(latLng => [latLng.lat, latLng.lng]);
      }
      
      setDrawnZone({
        type: type,
        bounds: bounds,
        color: '#8B5CF6'
      });
      setIsSaveZoneModalOpen(true);
      setIsDrawingMode(false);
    };
    
    mapInstance.on(L.Draw.Event.CREATED, onDrawCreated);
    
    return () => {
      mapInstance.off(L.Draw.Event.CREATED, onDrawCreated);
      if (drawnItemsRef.current && mapInstance) {
        drawnItemsRef.current.clearLayers();
        try {
          mapInstance.removeLayer(drawnItemsRef.current);
        } catch (e) {}
      }
      rectangleHandlerRef.current = null;
      polygonHandlerRef.current = null;
      drawnItemsRef.current = null;
    };
  }, [mapInstance, isAdmin]);

  // Species Diversification Data for the current view
  const speciesDiversity = useMemo(() => {
    const counts = {};
    observations.forEach(obs => {
      counts[obs.category] = (counts[obs.category] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [observations]);

  const COLORS = ['#10B981', '#34D399', '#6EE7B7', '#A7F3D0'];

  useEffect(() => {
    if (window.innerWidth >= 768) {
      setSidebarOpen(true);
    }
  }, []);

  useEffect(() => {
    if (!mapInstance) return;

    const onMapClick = (e) => {
      if (isPickingLocation) {
        onLocationPick(e.latlng);
      }
    };

    mapInstance.on('click', onMapClick);
    return () => mapInstance.off('click', onMapClick);
  }, [mapInstance, isPickingLocation, onLocationPick]);

  // Handle map resizing when sidebar toggles
  useEffect(() => {
    if (mapInstance) {
      const timer = setTimeout(() => {
        try { mapInstance.invalidateSize(); } catch (e) {}
      }, 300); // Wait for sidebar animation
      return () => clearTimeout(timer);
    }
  }, [mapInstance, sidebarOpen]);

  const filteredPins = observations.filter(obs => {
    // Safety check: ensure observation has coordinates
    if (!obs || !obs.coordinates || typeof obs.coordinates.lat === 'undefined' || typeof obs.coordinates.lng === 'undefined') {
      return false;
    }

    const matchesFilter = (activeFilter === 'All' || obs.category === activeFilter);
    
    // Species Search (uses debounced query)
    const matchesSpeciesSearch = debouncedSearchQuery.trim() === '' || 
      (obs.commonName && obs.commonName.toLowerCase().includes(debouncedSearchQuery.toLowerCase())) ||
      (obs.scientificName && obs.scientificName.toLowerCase().includes(debouncedSearchQuery.toLowerCase())) ||
      (obs.name && obs.name.toLowerCase().includes(debouncedSearchQuery.toLowerCase()));
    
    // Location-based Search (checks if observation is within bounds)
    const matchesLocationSearch = !locationBounds || (
      obs.coordinates.lat >= locationBounds.south &&
      obs.coordinates.lat <= locationBounds.north &&
      obs.coordinates.lng >= locationBounds.west &&
      obs.coordinates.lng <= locationBounds.east
    );
    
    // Zone Filtering (uses point-in-polygon algorithm)
    const matchesZone = !selectedZone || isPointInZone([obs.coordinates.lat, obs.coordinates.lng], selectedZone);
    
    return matchesFilter && matchesSpeciesSearch && matchesLocationSearch && matchesZone;
  });

  // Toast notification for combined search results
  useEffect(() => {
    if (debouncedSearchQuery && locationName && filteredPins.length >= 0) {
      const speciesText = debouncedSearchQuery;
      const locationText = locationName.split(',')[0]; // Get main location name
      toast.success(`Found ${filteredPins.length} observation${filteredPins.length !== 1 ? 's' : ''} of "${speciesText}" in ${locationText}`, {
        duration: 3000
      });
    } else if (debouncedSearchQuery && !locationName && filteredPins.length >= 0) {
      toast.info(`Found ${filteredPins.length} observation${filteredPins.length !== 1 ? 's' : ''} matching "${debouncedSearchQuery}"`, {
        duration: 2000
      });
    } else if (!debouncedSearchQuery && locationName && filteredPins.length >= 0) {
      const locationText = locationName.split(',')[0];
      toast.info(`Showing ${filteredPins.length} observation${filteredPins.length !== 1 ? 's' : ''} in ${locationText}`, {
        duration: 2000
      });
    }
  }, [debouncedSearchQuery, locationName, filteredPins.length]);

  const clearDrawnLayers = () => {
    if (drawnItemsRef.current) {
      drawnItemsRef.current.clearLayers();
    }
    drawnLayersRef.current = [];
  };

  const handleSaveZone = () => {
    if (!newZoneName.trim() || !drawnZone) {
      toast.error('Please provide a zone name');
      return;
    }
    
    const newZone = {
      id: Date.now(),
      name: newZoneName,
      description: newZoneDescription,
      type: drawnZone.type,
      bounds: drawnZone.bounds,
      creator: user?.name || 'Admin',
      createdAt: new Date().toISOString(),
      color: drawnZone.color
    };
    
    // Mock save - in real app would POST to /api/zones
    setZones([...zones, newZone]);
    toast.success(`Zone "${newZoneName}" saved successfully!`);
    
    // Clear drawn layers from the map after saving
    clearDrawnLayers();
    
    // Reset
    setIsSaveZoneModalOpen(false);
    setNewZoneName('');
    setNewZoneDescription('');
    setDrawnZone(null);
  };

  const handleSelectZone = (zone) => {
    if (selectedZone?.id === zone.id) {
      setSelectedZone(null);
      toast.info('Zone filter cleared');
    } else {
      setSelectedZone(zone);
      toast.success(`Filtering by: ${zone.name}`);
      
      // Zoom to zone
      if (mapInstance) {
        if (zone.type === 'rectangle') {
          const bounds = L.latLngBounds(zone.bounds);
          mapInstance.fitBounds(bounds, { padding: [50, 50] });
        } else if (zone.type === 'polygon') {
          const bounds = L.latLngBounds(zone.bounds);
          mapInstance.fitBounds(bounds, { padding: [50, 50] });
        }
      }
    }
    setIsZonesModalOpen(false);
  };

  useEffect(() => {
    let instance = null;
    if (!mapRef.current || mapInstance) return;

    try {
      instance = L.map(mapRef.current, { 
        scrollWheelZoom: true, 
        fadeAnimation: true, 
        zoomAnimation: true, 
        trackResize: true, 
        zoomControl: false,
        attributionControl: false
      }).setView([22.5937, 78.9629], 5);
      
      L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', { 
        attribution: '&copy; CARTO' 
      }).addTo(instance);
      
      L.control.zoom({ position: 'topright' }).addTo(instance);
      L.control.attribution({ position: 'bottomleft' }).addTo(instance);
      
      // Track zoom level changes
      instance.on('zoomend', () => {
        const zoom = instance.getZoom();
        setCurrentZoom(zoom);
      });
      
      // Force a redraw once ready
      instance.whenReady(() => {
        setMapInstance(instance);
        setCurrentZoom(instance.getZoom()); // Set initial zoom
        setTimeout(() => instance.invalidateSize(), 100);
      });
    } catch (err) {
      console.error("Leaflet init error:", err);
    }

    return () => {
      if (instance) { 
        instance.off(); 
        instance.remove(); 
        setMapInstance(null); 
      }
    };
  }, []);

  // Center map on selected observation and open popup
  useEffect(() => {
    if (mapInstance && selectedObservation && mapInstance.getContainer()) {
      // Check if map is properly initialized and in the DOM
      try {
        mapInstance.flyTo([selectedObservation.lat, selectedObservation.lng], 12, {
          duration: 1.5
        });
        
        // Wait for the flyTo animation and markers to be created, then open popup
        setTimeout(() => {
          const marker = markersRef.current.find(m => {
            const latlng = m.getLatLng();
            return latlng.lat === selectedObservation.lat && latlng.lng === selectedObservation.lng;
          });
          if (marker) {
            marker.openPopup();
          }
        }, 1600); // Slightly after the flyTo animation
      } catch (error) {
        console.error('Error flying to location:', error);
      }
    }
  }, [mapInstance, selectedObservation]);

  useEffect(() => {
    if (!mapInstance) return;

    let isMounted = true;

    const updateLayers = () => {
      if (!isMounted || !mapInstance) return;
      
      const container = mapInstance.getContainer();
      if (!container || !container.parentNode) return;

      try {
        // Clear old layers
        markersRef.current.forEach(m => {
          try { m.remove(); } catch(e) {}
        });
        polygonsRef.current.forEach(p => {
          try { p.remove(); } catch(e) {}
        });
        if (heatmapRef.current) {
          try { heatmapRef.current.remove(); } catch(e) {}
          heatmapRef.current = null;
        }
        markersRef.current = [];
        polygonsRef.current = [];

        // Automatic heatmap display based on zoom level
        const shouldShowHeatmap = currentZoom < ZOOM_THRESHOLD;
        const shouldShowMarkers = currentZoom >= ZOOM_THRESHOLD;

        // Show heatmap when zoomed out
        if (shouldShowHeatmap && filteredPins.length > 0) {
          try {
            const heatPoints = filteredPins
              .filter(o => typeof o.lat === 'number' && typeof o.lng === 'number' && !isNaN(o.lat) && !isNaN(o.lng))
              .map(obs => [obs.lat, obs.lng, 0.8]);
            
            if (heatPoints.length > 0) {
              // @ts-ignore - heatLayer added by leaflet.heat
              heatmapRef.current = L.heatLayer(heatPoints, {
                radius: 35,
                blur: 25,
                maxZoom: 17,
                max: 1.0,
                gradient: { 
                  0.0: '#D1FAE5',
                  0.2: '#6EE7B7', 
                  0.4: '#10B981', 
                  0.6: '#F59E0B', 
                  0.8: '#F97316',
                  1.0: '#EF4444' 
                }
              }).addTo(mapInstance);
            }
          } catch (e) {
            console.warn("Error adding heatmap:", e);
          }
        }

        if (showZones) {
          zones.forEach(zone => {
            try {
              const poly = L.polygon(zone.positions, { 
                fillColor: zone.health === 'Excellent' ? '#10B981' : zone.health === 'Good' ? '#3B82F6' : '#EF4444', 
                color: zone.health === 'Excellent' ? '#10B981' : zone.health === 'Good' ? '#3B82F6' : '#EF4444', 
                weight: 2, 
                opacity: 0.4, 
                fillOpacity: 0.1, 
                dashArray: '5, 10' 
              }).addTo(mapInstance);
              
              poly.bindPopup(`<div class="p-2 min-w-[150px]"><h4 class="font-bold text-emerald-900">${zone.name}</h4><p class="text-[10px] text-emerald-600 font-bold mb-1">${zone.type}</p></div>`);
              polygonsRef.current.push(poly);
            } catch (e) {
              console.warn("Error adding polygon:", e);
            }
          });
        }

        // Show individual markers when zoomed in
        if (shouldShowMarkers) {
          filteredPins.forEach(obs => {
            try {
              // Coordinate Validation
              const lat = Number(obs.lat);
              const lng = Number(obs.lng);
              if (isNaN(lat) || isNaN(lng)) return;

              const icon = L.divIcon({
                html: `<div class="marker-container" style="background-color: ${obs.category === 'Toxic' ? '#EF4444' : obs.category === 'Medicinal' ? '#8B5CF6' : '#059669'}; width: 36px; height: 36px; border: 4px solid white; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; box-shadow: 0 12px 20px -5px rgba(0, 0, 0, 0.2);"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 4.993-5.539 10.16-7.382 11.762a1.017 1.017 0 0 1-1.236 0C9.539 20.16 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg></div>`,
                className: 'custom-mushroom-marker', 
                iconSize: [36, 36], 
                iconAnchor: [18, 36],
              });
              
              const popupContent = document.createElement('div');
              popupContent.className = 'p-4 min-w-[240px] font-sans';
              popupContent.innerHTML = `
                <div class="flex gap-3 mb-3">
                  <div class="w-16 h-16 rounded-xl overflow-hidden shrink-0 shadow-sm">
                    <img src="${obs.image}" class="w-full h-full object-cover" />
                  </div>
                  <div class="flex-1">
                    <h4 class="font-bold text-emerald-950 text-sm leading-tight mb-1">${obs.name}</h4>
                    <p class="text-[10px] text-emerald-800/50 mb-2">${obs.location}</p>
                    <div class="inline-block px-2 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-widest" style="background-color: ${obs.category === 'Toxic' ? '#FEE2E2' : obs.category === 'Medicinal' ? '#F3E8FF' : '#DCFCE7'}; color: ${obs.category === 'Toxic' ? '#B91C1C' : obs.category === 'Medicinal' ? '#7E22CE' : '#15803D'}">
                      ${obs.category}
                    </div>
                  </div>
                </div>
                <div class="flex items-center justify-between pt-3 border-t border-emerald-50">
                  <div class="text-[8px] font-bold text-emerald-900/40 uppercase">By ${obs.contributor}</div>
                  <button class="view-details-btn bg-emerald-900 text-white px-3 py-1.5 rounded-lg text-[9px] font-bold hover:bg-emerald-950 transition-all">DETAILS</button>
                </div>
              `;

              const marker = L.marker([obs.lat, obs.lng], { icon })
                .bindPopup(popupContent, {
                  className: 'mushroom-popup',
                  maxWidth: 300,
                  minWidth: 240,
                  closeButton: false,
                  offset: [0, -32]
                })
                .addTo(mapInstance);

              marker.on('popupopen', () => {
                const btn = popupContent.querySelector('.view-details-btn');
                if (btn) {
                  btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    onViewDetails(obs);
                  });
                }
              });

              markersRef.current.push(marker);
            } catch (e) {
              console.warn("Error adding marker:", e);
            }
          });
        }
      } catch (e) {
        console.warn("Layer update error:", e);
      }
    };

    mapInstance.whenReady(updateLayers);
    
    return () => {
      isMounted = false;
    };
  }, [filteredPins, showZones, mapInstance, currentZoom]);

  return (
    <div className="bg-white rounded-[40px] md:rounded-[48px] overflow-hidden border border-emerald-100 shadow-2xl relative h-[750px] md:h-[1000px] flex transition-all">
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSidebarOpen(false)} className="absolute inset-0 bg-emerald-950/20 backdrop-blur-sm z-30 md:hidden" />
            <motion.div initial={{ x: -400, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -400, opacity: 0 }} className="absolute md:relative w-[320px] md:w-[400px] bg-white border-r border-emerald-100 flex flex-col z-40 h-full shrink-0">
              
              {/* Sidebar Tabs */}
              <div className="flex border-b border-emerald-50">
                <button onClick={() => setActiveTab('filters')} className={`flex-1 py-4 text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'filters' ? 'text-emerald-900 border-b-2 border-emerald-900 bg-emerald-50/20' : 'text-emerald-900/40 hover:bg-emerald-50/10'}`}>Filters</button>
                <button onClick={() => setActiveTab('analysis')} className={`flex-1 py-4 text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'analysis' ? 'text-emerald-900 border-b-2 border-emerald-900 bg-emerald-50/20' : 'text-emerald-900/40 hover:bg-emerald-50/10'}`}>Analysis</button>
              </div>

              <div className="p-5 md:p-6 space-y-6 overflow-y-auto scrollbar-hide flex-1">
                {activeTab === 'filters' ? (
                  <>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="font-bold text-emerald-950 text-lg">Discovery Hub</h3>
                        <button onClick={() => setSidebarOpen(false)} className="md:hidden p-2 hover:bg-emerald-50 rounded-xl text-emerald-400"><X size={20} /></button>
                      </div>
                      
                      {/* Species Search with Autocomplete */}
                      <div className="relative">
                        <div className="relative group">
                          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-400 group-focus-within:text-emerald-600 transition-colors z-10" size={18} />
                          <input 
                            type="text" 
                            placeholder="Search species (common or scientific name)..." 
                            className="w-full bg-emerald-50/50 rounded-2xl py-3 pl-12 pr-10 text-sm focus:outline-none border border-transparent focus:border-emerald-200 focus:bg-white transition-all shadow-inner" 
                            value={searchQuery} 
                            onChange={(e) => setSearchQuery(e.target.value)}
                            onFocus={() => setShowAutocomplete(autocompleteSuggestions.length > 0)}
                            onBlur={() => setTimeout(() => setShowAutocomplete(false), 200)}
                          />
                          {searchQuery && (
                            <button
                              onClick={() => setSearchQuery('')}
                              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-emerald-100 rounded-lg transition-colors z-10"
                            >
                              <X size={16} className="text-emerald-400" />
                            </button>
                          )}
                        </div>
                        
                        {/* Autocomplete Dropdown */}
                        <AnimatePresence>
                          {showAutocomplete && autocompleteSuggestions.length > 0 && (
                            <motion.div
                              initial={{ opacity: 0, y: -10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -10 }}
                              className="absolute top-full mt-2 w-full bg-white rounded-xl border border-emerald-200 shadow-xl overflow-hidden z-50"
                            >
                              <div className="p-2 space-y-1 max-h-64 overflow-y-auto">
                                {autocompleteSuggestions.map((suggestion, index) => (
                                  <button
                                    key={index}
                                    onClick={() => {
                                      setSearchQuery(suggestion);
                                      setShowAutocomplete(false);
                                      toast.info(`Searching for "${suggestion}"`, { duration: 1500 });
                                    }}
                                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-emerald-50 transition-colors text-sm text-emerald-900 font-medium"
                                  >
                                    {suggestion}
                                  </button>
                                ))}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>

                      {/* Location-based Search */}
                      <div className="relative group">
                        <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-purple-400 group-focus-within:text-purple-600 transition-colors z-10" size={18} />
                        <input 
                          type="text" 
                          placeholder="Search location (city, region, country)..." 
                          className="w-full bg-purple-50/50 rounded-2xl py-3 pl-12 pr-10 text-sm focus:outline-none border border-transparent focus:border-purple-200 focus:bg-white transition-all shadow-inner" 
                          value={locationSearch} 
                          onChange={(e) => setLocationSearch(e.target.value)}
                        />
                        {locationSearch && (
                          <button
                            onClick={() => setLocationSearch('')}
                            className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-purple-100 rounded-lg transition-colors z-10"
                          >
                            <X size={16} className="text-purple-400" />
                          </button>
                        )}
                      </div>

                      {/* Active Filters Display */}
                      {(debouncedSearchQuery || locationName) && (
                        <div className="bg-gradient-to-r from-emerald-50 to-purple-50 border border-emerald-200 rounded-xl p-3 space-y-2">
                          <div className="text-[10px] font-bold text-emerald-900/60 uppercase tracking-widest mb-2">Active Filters</div>
                          {debouncedSearchQuery && (
                            <div className="flex items-center gap-2 text-xs">
                              <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                              <span className="text-emerald-900 font-medium">Species: {debouncedSearchQuery}</span>
                            </div>
                          )}
                          {locationName && (
                            <div className="flex items-center gap-2 text-xs">
                              <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                              <span className="text-purple-900 font-medium">Location: {locationName.split(',')[0]}</span>
                            </div>
                          )}
                          <div className="text-xs font-bold text-emerald-700 pt-1 border-t border-emerald-200/50">
                            {filteredPins.length} observation{filteredPins.length !== 1 ? 's' : ''} found
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h4 className="font-bold text-emerald-900/40 text-[10px] uppercase tracking-[0.2em]">Primary Taxonomy</h4>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {['All', 'Edible', 'Toxic', 'Medicinal'].map(cat => (
                          <button key={cat} onClick={() => setActiveFilter(cat)} className={`px-4 py-2 rounded-xl text-[10px] font-bold transition-all border ${activeFilter === cat ? 'bg-emerald-900 text-white border-emerald-900 shadow-lg' : 'bg-white text-emerald-800 border-emerald-100 hover:border-emerald-200'}`}>{cat}</button>
                        ))}
                      </div>
                      <button 
                        onClick={() => setIsCategoryModalOpen(true)} 
                        className="w-full py-3 rounded-2xl border border-emerald-100 bg-emerald-50/50 text-emerald-600 text-[10px] font-bold uppercase tracking-widest hover:bg-emerald-100 transition-all flex items-center justify-center gap-2"
                      >
                        <Zap size={14} /> Full Scientific Matrix
                      </button>
                    </div>

                    {/* Zones Section */}
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h4 className="font-bold text-emerald-900/40 text-[10px] uppercase tracking-[0.2em]">Biodiversity Zones</h4>
                        {isAdmin && (
                          <div className="flex gap-1">
                            <button
                              onClick={() => {
                                if (rectangleHandlerRef.current) {
                                  rectangleHandlerRef.current.enable();
                                  toast.info('Click and drag to draw a rectangle zone', { duration: 3000 });
                                  setIsDrawingMode(true);
                                  setDrawingType('rectangle');
                                }
                              }}
                              className="p-1.5 hover:bg-purple-50 rounded-lg transition-colors"
                              title="Draw Rectangle Zone"
                            >
                              <Square size={14} className="text-purple-600" />
                            </button>
                            <button
                              onClick={() => {
                                if (polygonHandlerRef.current) {
                                  polygonHandlerRef.current.enable();
                                  toast.info('Click to add points, double-click to finish polygon', { duration: 3000 });
                                  setIsDrawingMode(true);
                                  setDrawingType('polygon');
                                }
                              }}
                              className="p-1.5 hover:bg-purple-50 rounded-lg transition-colors"
                              title="Draw Polygon Zone"
                            >
                              <Pentagon size={14} className="text-purple-600" />
                            </button>
                          </div>
                        )}
                      </div>
                      
                      <button
                        onClick={() => setIsZonesModalOpen(true)}
                        className="w-full py-3 rounded-2xl border border-purple-100 bg-purple-50/50 text-purple-600 text-[10px] font-bold uppercase tracking-widest hover:bg-purple-100 transition-all flex items-center justify-center gap-2"
                      >
                        <Layers size={14} /> Browse Saved Zones ({zones.length})
                      </button>
                      
                      {selectedZone && (
                        <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-xl p-3">
                          <div className="text-[10px] font-bold text-purple-900/60 uppercase tracking-widest mb-2">Active Zone</div>
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="text-sm font-bold text-purple-950">{selectedZone.name}</div>
                              <div className="text-xs text-purple-700 mt-1">{selectedZone.description}</div>
                            </div>
                            <button
                              onClick={() => {
                                setSelectedZone(null);
                                toast.info('Zone filter cleared');
                              }}
                              className="p-1 hover:bg-purple-100 rounded-lg transition-colors flex-shrink-0"
                            >
                              <X size={14} className="text-purple-600" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-bold text-emerald-900/40 text-[10px] uppercase tracking-[0.2em]">Map Layers & Overlays</h4>
                      
                      {/* Zoom Status Indicator */}
                      <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] font-bold text-emerald-900/60 uppercase tracking-widest">View Mode</span>
                          <span className="text-xs font-black text-emerald-700">Zoom: {currentZoom}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {currentZoom < ZOOM_THRESHOLD ? (
                            <>
                              <Sparkles size={16} className="text-orange-500" />
                              <span className="text-sm font-bold text-emerald-950">Heatmap (Density View)</span>
                            </>
                          ) : (
                            <>
                              <MapPin size={16} className="text-emerald-600" />
                              <span className="text-sm font-bold text-emerald-950">Markers (Detail View)</span>
                            </>
                          )}
                        </div>
                        <p className="text-[9px] text-emerald-600/70 mt-2">
                          {currentZoom < ZOOM_THRESHOLD 
                            ? 'Zoom in to see individual observations' 
                            : 'Zoom out to see density heatmap'}
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <LayerToggle 
                          active={showZones} 
                          onClick={() => setShowZones(!showZones)} 
                          icon={<ShieldCheck size={18} />} 
                          title="Bio-Safe Zones" 
                          subtitle="Protected Corridors"
                          color="emerald"
                        />
                        <LayerToggle 
                          active={showRainfall} 
                          onClick={() => setShowRainfall(!showRainfall)} 
                          icon={<Globe size={18} />} 
                          title="Precipitation Zones" 
                          subtitle="Seasonal Gradient"
                          color="blue"
                        />
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-4">
                      <h4 className="font-bold text-emerald-900/40 text-[10px] uppercase tracking-[0.2em]">Specimen Distribution</h4>
                      <div className="h-48 w-full bg-emerald-50/30 rounded-[32px] border border-emerald-100/50 p-4">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={speciesDiversity}
                              innerRadius={40}
                              outerRadius={60}
                              paddingAngle={5}
                              dataKey="value"
                            >
                              {speciesDiversity.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip 
                              contentStyle={{ 
                                borderRadius: '16px', 
                                border: 'none', 
                                boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                                fontSize: '10px',
                                fontWeight: 'bold'
                              }} 
                            />
                            <Legend 
                              verticalAlign="bottom" 
                              align="center"
                              wrapperStyle={{ fontSize: '9px', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '0.05em' }}
                            />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                          <div className="text-[9px] font-bold text-emerald-900/40 uppercase mb-1">Total Specimens</div>
                          <div className="text-xl font-bold text-emerald-950 font-serif">{filteredPins.length}</div>
                        </div>
                        <div className="p-4 bg-orange-50 rounded-2xl border border-orange-100">
                          <div className="text-[9px] font-bold text-orange-900/40 uppercase mb-1">Active Researchers</div>
                          <div className="text-xl font-bold text-orange-950 font-serif">{CONTRIBUTORS.length}</div>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
              
              <div className="p-5 border-t border-emerald-100 bg-emerald-50/30 mt-auto">
                <div className="flex items-center gap-3">
                   <div className="bg-emerald-900 p-2.5 rounded-xl text-white shadow-lg"><MapPin size={16} /></div>
                   <div><div className="text-[9px] font-bold text-emerald-900/40 uppercase tracking-widest leading-tight">Live Observations</div><div className="text-xs font-bold text-emerald-950 leading-tight">{filteredPins.length} Data Points Active</div></div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <div className="flex-1 relative bg-emerald-50 overflow-hidden z-10">
        {isPickingLocation && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[2000] bg-emerald-900 text-white px-6 py-3 rounded-full font-black text-xs uppercase tracking-[0.2em] shadow-2xl flex items-center gap-3 animate-bounce">
            <MapPin size={16} className="text-emerald-400" /> Click Map to Pick Location
          </div>
        )}
        {isDrawingMode && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[2000] bg-purple-600 text-white px-6 py-3 rounded-full font-black text-xs uppercase tracking-[0.2em] shadow-2xl flex items-center gap-3 animate-pulse">
            {drawingType === 'rectangle' ? <Square size={16} /> : <Pentagon size={16} />}
            Drawing {drawingType === 'rectangle' ? 'Rectangle' : 'Polygon'} Zone
          </div>
        )}
        <div ref={mapRef} className={`h-full w-full z-0 ${isPickingLocation ? 'cursor-crosshair' : isDrawingMode ? 'cursor-crosshair' : ''}`} />
        
        {/* Zoom Mode Indicator */}
        {!sidebarOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute top-4 left-1/2 -translate-x-1/2 z-20"
          >
            <div className={`px-5 py-2.5 rounded-full font-bold text-xs uppercase tracking-widest shadow-xl border-2 flex items-center gap-2 transition-all ${
              currentZoom < ZOOM_THRESHOLD 
                ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white border-orange-300' 
                : 'bg-white text-emerald-900 border-emerald-200'
            }`}>
              {currentZoom < ZOOM_THRESHOLD ? (
                <>
                  <Sparkles size={14} />
                  <span>Density Heatmap</span>
                </>
              ) : (
                <>
                  <MapPin size={14} />
                  <span>Detail View</span>
                </>
              )}
            </div>
          </motion.div>
        )}
        
        {/* Floating Controls */}
        <div className="absolute top-4 left-4 z-20 flex flex-col gap-2">
          {!sidebarOpen && (
            <button onClick={() => setSidebarOpen(true)} className="bg-white p-3.5 rounded-2xl shadow-xl border border-emerald-100 text-emerald-900 hover:scale-105 transition-all"><Filter size={20} /></button>
          )}
        </div>

        <AnimatePresence>
          {isCategoryModalOpen && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-emerald-950/20 backdrop-blur-xl z-[2000] p-4 md:p-12 flex items-center justify-center">
              <motion.div initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} className="bg-white w-full max-w-4xl rounded-[48px] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                <div className="p-10 border-b border-emerald-50 flex justify-between items-center">
                  <div>
                    <h3 className="text-3xl font-bold text-emerald-950 font-serif">Deep Bio-Filtering</h3>
                    <p className="text-emerald-800/50 text-sm mt-1">Select specialized taxonomic filters for advanced mapping.</p>
                  </div>
                  <button onClick={() => setIsCategoryModalOpen(false)} className="p-3 hover:bg-emerald-50 rounded-2xl text-emerald-400 transition-all"><X size={24}/></button>
                </div>
                <div className="flex-1 overflow-y-auto p-10 scrollbar-hide">
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {CATEGORIES.map((cat, i) => (
                      <div key={cat} className={`group relative p-6 rounded-3xl border flex flex-col items-center justify-center text-center gap-3 transition-all duration-300 ${i > 3 ? 'opacity-40 grayscale bg-slate-50 border-slate-100' : 'bg-white border-emerald-100 hover:border-emerald-500 hover:shadow-xl cursor-pointer'}`} onClick={() => i <= 3 && (setActiveFilter(cat), setIsCategoryModalOpen(false))}>
                        {i > 3 && <div className="absolute top-3 right-3 bg-emerald-900 text-white p-1.5 rounded-lg shadow-lg"><Lock size={12} /></div>}
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110 ${i > 3 ? 'bg-slate-200 text-slate-400' : 'bg-emerald-100 text-emerald-600'}`}><Zap size={24} /></div>
                        <span className="text-[11px] font-bold text-emerald-950 uppercase tracking-tight">{cat}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="p-10 bg-emerald-950 text-white flex flex-col md:flex-row items-center justify-between gap-8">
                  <div className="max-w-md text-left">
                    <h4 className="text-xl font-bold mb-2">Scientific Premium Tier</h4>
                    <p className="text-emerald-300/80 text-sm leading-relaxed">Access micro-habitat variables, humidity gradients, and historical colonization patterns for all species.</p>
                  </div>
                  <button className="w-full md:w-auto bg-emerald-500 hover:bg-emerald-400 text-white px-10 py-5 rounded-2xl font-bold transition-all shadow-xl shadow-emerald-500/20 active:scale-95">Unlock All Features</button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Zones Browse Modal */}
        <AnimatePresence>
          {isZonesModalOpen && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              className="absolute inset-0 bg-purple-950/20 backdrop-blur-xl z-[2000] p-4 md:p-12 flex items-center justify-center"
              onClick={() => setIsZonesModalOpen(false)}
            >
              <motion.div 
                initial={{ scale: 0.95, y: 20 }} 
                animate={{ scale: 1, y: 0 }} 
                className="bg-white w-full max-w-4xl rounded-[48px] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="p-10 border-b border-purple-50 flex justify-between items-center">
                  <div>
                    <h3 className="text-3xl font-bold text-purple-950 font-serif">Biodiversity Zones</h3>
                    <p className="text-purple-800/50 text-sm mt-1">Select a zone to filter observations within its boundaries</p>
                  </div>
                  <button onClick={() => setIsZonesModalOpen(false)} className="p-3 hover:bg-purple-50 rounded-2xl text-purple-400 transition-all">
                    <X size={24}/>
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto p-10 scrollbar-hide">
                  <div className="space-y-4">
                    {zones.map((zone) => {
                      const obsInZone = observations.filter(obs => 
                        obs?.coordinates && 
                        typeof obs.coordinates.lat !== 'undefined' && 
                        typeof obs.coordinates.lng !== 'undefined' &&
                        isPointInZone([obs.coordinates.lat, obs.coordinates.lng], zone)
                      ).length;
                      
                      return (
                        <div 
                          key={zone.id} 
                          className={`p-6 rounded-3xl border-2 cursor-pointer transition-all ${
                            selectedZone?.id === zone.id 
                              ? 'border-purple-500 bg-purple-50 shadow-lg' 
                              : 'border-purple-100 bg-white hover:border-purple-300 hover:shadow-md'
                          }`}
                          onClick={() => handleSelectZone(zone)}
                        >
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <div 
                                  className="w-4 h-4 rounded-full" 
                                  style={{ backgroundColor: zone.color }}
                                ></div>
                                <h4 className="text-lg font-bold text-purple-950">{zone.name}</h4>
                              </div>
                              <p className="text-sm text-purple-700 mb-3">{zone.description}</p>
                              <div className="flex flex-wrap gap-2 text-xs">
                                <div className="px-3 py-1.5 bg-purple-100 text-purple-700 rounded-full font-medium">
                                  {zone.type === 'rectangle' ? <Square size={12} className="inline mr-1" /> : <Pentagon size={12} className="inline mr-1" />}
                                  {zone.type}
                                </div>
                                <div className="px-3 py-1.5 bg-emerald-100 text-emerald-700 rounded-full font-medium">
                                  {obsInZone} observations
                                </div>
                                <div className="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-full font-medium">
                                  By {zone.creator}
                                </div>
                              </div>
                            </div>
                            {selectedZone?.id === zone.id && (
                              <div className="flex-shrink-0 w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                                <Check size={16} className="text-white" />
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
                {isAdmin && (
                  <div className="p-10 bg-purple-950 text-white flex flex-col md:flex-row items-center justify-between gap-8">
                    <div className="max-w-md text-left">
                      <h4 className="text-xl font-bold mb-2">Draw Custom Zones</h4>
                      <p className="text-purple-300/80 text-sm leading-relaxed">Use the drawing tools in the map controls to create custom research zones with rectangle or polygon boundaries.</p>
                    </div>
                    <button 
                      onClick={() => setIsZonesModalOpen(false)}
                      className="w-full md:w-auto bg-purple-500 hover:bg-purple-400 text-white px-10 py-5 rounded-2xl font-bold transition-all shadow-xl shadow-purple-500/20 active:scale-95 flex items-center gap-2"
                    >
                      <Edit3 size={18} /> Start Drawing
                    </button>
                  </div>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Save Zone Modal */}
        <AnimatePresence>
          {isSaveZoneModalOpen && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              className="absolute inset-0 bg-purple-950/20 backdrop-blur-xl z-[2100] p-4 md:p-12 flex items-center justify-center"
              onClick={() => {
                clearDrawnLayers();
                setIsSaveZoneModalOpen(false);
                setNewZoneName('');
                setNewZoneDescription('');
                setDrawnZone(null);
              }}
            >
              <motion.div 
                initial={{ scale: 0.95, y: 20 }} 
                animate={{ scale: 1, y: 0 }} 
                className="bg-white w-full max-w-2xl rounded-[48px] shadow-2xl overflow-hidden"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="p-10 border-b border-purple-50">
                  <h3 className="text-3xl font-bold text-purple-950 font-serif mb-2">Save Custom Zone</h3>
                  <p className="text-purple-800/50 text-sm">Name and describe your newly created biodiversity zone</p>
                </div>
                <div className="p-10 space-y-6">
                  <div>
                    <label className="block text-xs font-bold text-purple-900/60 uppercase tracking-widest mb-2">Zone Name *</label>
                    <input
                      type="text"
                      value={newZoneName}
                      onChange={(e) => setNewZoneName(e.target.value)}
                      placeholder="e.g., Western Ghats Research Area"
                      className="w-full px-4 py-3 rounded-2xl border border-purple-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 outline-none transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-purple-900/60 uppercase tracking-widest mb-2">Description (Optional)</label>
                    <textarea
                      value={newZoneDescription}
                      onChange={(e) => setNewZoneDescription(e.target.value)}
                      placeholder="Describe the ecological significance, research focus, or notable features of this zone..."
                      rows={4}
                      className="w-full px-4 py-3 rounded-2xl border border-purple-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 outline-none transition-all text-sm resize-none"
                    />
                  </div>
                  {drawnZone && (
                    <div className="bg-purple-50 rounded-2xl p-4 border border-purple-100">
                      <div className="text-xs font-bold text-purple-900/60 uppercase tracking-widest mb-2">Zone Details</div>
                      <div className="flex gap-2 text-xs">
                        <div className="px-3 py-1.5 bg-white text-purple-700 rounded-full font-medium border border-purple-200">
                          Type: {drawnZone.type}
                        </div>
                        <div className="px-3 py-1.5 bg-white text-purple-700 rounded-full font-medium border border-purple-200">
                          {drawnZone.bounds.length} points
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-10 bg-gray-50 flex gap-4">
                  <button
                    onClick={() => {
                      clearDrawnLayers();
                      setIsSaveZoneModalOpen(false);
                      setNewZoneName('');
                      setNewZoneDescription('');
                      setDrawnZone(null);
                    }}
                    className="flex-1 px-6 py-4 rounded-2xl border-2 border-gray-200 text-gray-700 font-bold hover:bg-gray-100 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveZone}
                    className="flex-1 px-6 py-4 rounded-2xl bg-purple-600 text-white font-bold hover:bg-purple-500 transition-all shadow-lg shadow-purple-600/20 active:scale-95 flex items-center justify-center gap-2"
                  >
                    <Save size={18} /> Save Zone
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <button onClick={onAddClick} className="absolute bottom-6 right-6 w-14 h-14 bg-emerald-600 text-white rounded-2xl shadow-xl flex items-center justify-center hover:scale-105 active:scale-95 transition-all z-40 shadow-emerald-600/30"><Plus className="w-6 h-6" /></button>
    </div>
  );
};

// --- Observation Hub Logic Components ---

const CustomDropdown = ({ label, value, options, onChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const selectedOption = options.find(opt => opt.label === value);

  return (
    <div className="space-y-1 md:space-y-2 relative" ref={containerRef}>
      <label className="block text-[9px] md:text-[10px] font-black text-stone-400 uppercase tracking-widest">{label}</label>
      <button 
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full bg-white border rounded-xl md:rounded-full px-4 md:px-6 py-3 md:py-4 text-xs md:text-sm font-medium flex items-center justify-between transition-all ${isOpen ? 'border-emerald-500 ring-4 ring-emerald-500/5' : 'border-stone-100'}`}
      >
        <div className="flex items-center gap-2 md:gap-3">
          {selectedOption ? (
            <div className="flex items-center gap-2">
              <span className="text-base md:text-lg shrink-0">{selectedOption.icon}</span>
              <span className="text-emerald-950 font-bold truncate max-w-[120px] md:max-w-none">{selectedOption.label}</span>
            </div>
          ) : (
            <span className="text-stone-300">Select...</span>
          )}
        </div>
        <ChevronRight size={16} className={`text-stone-300 transition-transform md:w-5 md:h-5 ${isOpen ? 'rotate-90' : ''}`} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute left-0 right-0 top-full mt-2 bg-white border border-emerald-50 rounded-2xl md:rounded-3xl shadow-2xl z-[300] overflow-hidden max-h-60 overflow-y-auto scrollbar-hide"
          >
            <div 
              className="p-3 md:p-4 hover:bg-emerald-50/50 cursor-pointer text-emerald-600 font-bold text-[10px] md:text-xs border-b border-emerald-50"
              onClick={() => { onChange(''); setIsOpen(false); }}
            >
              — Reset Selection —
            </div>
            {options.map((opt) => (
              <div 
                key={opt.label}
                onClick={() => { onChange(opt.label); setIsOpen(false); }}
                className={`flex items-center gap-3 md:gap-4 p-3 md:p-4 hover:bg-emerald-50 cursor-pointer transition-colors ${value === opt.label ? 'bg-emerald-50/80' : ''}`}
              >
                <span className="text-lg md:text-xl shrink-0">{opt.icon}</span>
                <span className={`text-xs md:text-sm font-bold ${value === opt.label ? 'text-emerald-600' : 'text-emerald-900'}`}>{opt.label}</span>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const AddObservation = ({ isOpen, onClose, onEnterPickingMode, pickedLocation, clearPickedLocation, form, setForm, step, setStep, onAdd }) => {
  const [locationMode, setLocationMode] = useState('map');
  const [isLocating, setIsLocating] = useState(false);
  const [isLocationSet, setIsLocationSet] = useState(false);
  const [isSearchingCity, setIsSearchingCity] = useState(false);

  useEffect(() => {
    if (pickedLocation) {
      setForm(prev => ({ 
        ...prev, 
        lat: pickedLocation.lat.toFixed(5), 
        lng: pickedLocation.lng.toFixed(5) 
      }));
      setIsLocationSet(true);
      clearPickedLocation();
    }
  }, [pickedLocation, clearPickedLocation, setForm]);

  if (!isOpen) return null;

  const resetAndClose = () => {
    onClose();
  };

  const handleCitySearch = async (cityName) => {
    setForm(prev => ({ ...prev, city: cityName }));
    if (!cityName || cityName.length < 3) return;
    
    setIsSearchingCity(true);
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(cityName)}`);
      const data = await response.json();
      if (data && data[0]) {
        setForm(prev => ({ 
          ...prev, 
          lat: parseFloat(data[0].lat).toFixed(5), 
          lng: parseFloat(data[0].lon).toFixed(5) 
        }));
        setIsLocationSet(true);
      }
    } catch (err) {
      console.error("City search error:", err);
    } finally {
      setIsSearchingCity(false);
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setForm(prev => ({ ...prev, image: URL.createObjectURL(e.target.files[0]) }));
    }
  };

  const toggleUse = (use) => {
    setForm(prev => ({
      ...prev,
      commonUses: prev.commonUses.includes(use) 
        ? prev.commonUses.filter(u => u !== use)
        : [...prev.commonUses, use]
    }));
  };

  const detectLocation = () => {
    setIsLocating(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        setForm(prev => ({ ...prev, lat: position.coords.latitude.toFixed(5), lng: position.coords.longitude.toFixed(5) }));
        setIsLocationSet(true);
        setIsLocating(false);
      }, () => {
        setIsLocating(false);
      });
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center md:p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-emerald-950/40 backdrop-blur-md" onClick={resetAndClose} />
      
      <motion.div 
        initial={{ opacity: 0, y: 50, scale: 0.95 }} 
        animate={{ opacity: 1, y: 0, scale: 1 }} 
        exit={{ opacity: 0, y: 50, scale: 0.95 }} 
        className="relative bg-white w-full md:max-w-xl h-full md:h-[700px] md:max-h-[85vh] md:rounded-[40px] shadow-2xl overflow-hidden flex flex-col"
      >
        {/* Header */}
        <div className="p-6 md:p-10 pb-4 md:pb-6 shrink-0 bg-white">
          <div className="flex justify-between items-start mb-6 md:mb-8">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-1 md:w-1 h-3 md:h-4 bg-[#00A86B] rounded-full" />
                <span className="text-[10px] font-black text-[#00A86B] uppercase tracking-[0.2em]">Research Portal</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-black text-emerald-950 uppercase tracking-tighter leading-none">
                ADD <span className="text-[#00A86B]">SPECIMEN</span>
              </h2>
            </div>
            <button onClick={resetAndClose} className="p-2 text-[#00A86B]/30 hover:text-[#00A86B] transition-colors">
              <X size={24} className="md:w-8 md:h-8" />
            </button>
          </div>

          {/* Stepper */}
          {step <= 3 && (
            <div className="px-0 md:px-2">
              <div className="bg-[#00A86B] rounded-full py-3 md:py-4 px-6 md:px-10 flex items-center justify-between relative shadow-lg">
                {[
                  { id: 1, icon: Camera, label: 'Visuals' },
                  { id: 2, icon: Trash2, label: 'Biology' }, 
                  { id: 3, icon: Globe, label: 'Location' }
                ].map((s) => {
                  const isActive = step === s.id;
                  return (
                    <div key={s.id} className="flex flex-col items-center gap-1.5 relative">
                      <div className={`w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center transition-all duration-500 z-10 ${isActive ? 'bg-white text-[#00A86B]' : 'bg-emerald-700/20 text-emerald-100/40'}`}>
                        <s.icon size={isActive ? 14 : 12} className="md:w-4 md:h-4" />
                      </div>
                      <span className={`text-[7px] md:text-[8px] font-black uppercase tracking-[0.15em] text-center ${isActive ? 'text-white' : 'text-emerald-100/40'}`}>
                        {s.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="flex-1 overflow-hidden relative">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div 
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="absolute inset-0 overflow-y-auto px-6 md:px-10 py-4 md:py-6 space-y-5 md:space-y-6 scrollbar-hide"
              >
                {/* Tip & Note Box */}
                <div className="bg-[#F0FFF9] rounded-[28px] p-6 md:p-8 space-y-4 md:space-y-5">
                  <div className="flex gap-3 md:gap-4 items-start">
                    <div className="w-8 h-8 md:w-9 md:h-9 bg-white rounded-full flex items-center justify-center shadow-sm shrink-0">
                      <Camera size={16} className="text-[#00A86B]" />
                    </div>
                    <p className="text-xs md:text-sm font-bold text-emerald-950 leading-tight pt-1">
                      <span className="text-[#00A86B]">Tip:</span> Use "Take Photo with Camera" to automatically capture GPS location and date/time from your device.
                    </p>
                  </div>
                </div>

        {/* Photo Upload Section */}
        <div className="space-y-3 md:space-y-4 pb-2">
          {form.image ? (
            <div className="relative group rounded-2xl md:rounded-[32px] overflow-hidden aspect-[16/9] border-4 border-emerald-100 shadow-lg">
              <img src={form.image} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <button onClick={() => setForm(prev => ({ ...prev, image: null }))} className="absolute top-3 right-3 bg-red-500 text-white p-2 rounded-full shadow-lg">
                <Trash2 size={16} />
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-2.5">
              <label className="flex flex-col items-center justify-center h-28 md:h-32 border-2 border-dashed border-[#00A86B]/20 rounded-2xl md:rounded-[32px] cursor-pointer hover:bg-emerald-50 group transition-all bg-white relative overflow-hidden">
                <div className="bg-[#00A86B] p-2 rounded-full shadow-md group-hover:scale-110 transition-transform text-white mb-1.5">
                  <Camera size={16} />
                </div>
                <h4 className="text-[10px] md:text-xs text-[#00A86B] font-black uppercase tracking-widest text-center">Take Photo with Camera</h4>
                <input type="file" className="hidden" accept="image/*" capture="environment" onChange={handleFileChange} />
              </label>

              <label className="flex flex-col items-center justify-center h-28 md:h-32 border-2 border-dashed border-stone-200 rounded-2xl md:rounded-[32px] cursor-pointer hover:bg-stone-50 group transition-all bg-white relative overflow-hidden">
                <div className="bg-stone-400 p-2 rounded-full shadow-md group-hover:scale-110 transition-transform text-white mb-1.5">
                  <ImageIcon size={16} />
                </div>
                <h4 className="text-[10px] md:text-xs text-stone-600 font-black uppercase tracking-widest text-center">Upload from Gallery</h4>
                <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
              </label>
            </div>
          )}
        </div>

                {/* Names Section */}
                <div className="space-y-3">
                  <label className="block text-[9px] md:text-[10px] font-black text-stone-400 uppercase tracking-[0.2em]">Identification Names</label>
                  <div className="space-y-2 md:space-y-3">
                    <div className="relative group">
                      <div className="absolute left-4 md:left-5 top-1/2 -translate-y-1/2 text-emerald-400 group-focus-within:text-emerald-600 transition-colors">
                        <ImageIcon size={16} />
                      </div>
                      <input 
                        type="text" 
                        placeholder="Common Name (e.g. Lion's Mane)" 
                        className="w-full bg-stone-50 border border-stone-100 rounded-xl md:rounded-[24px] pl-12 md:pl-14 pr-5 py-3 md:py-4 focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-300 outline-none transition-all font-bold text-emerald-950 placeholder:text-stone-300 text-xs md:text-sm"
                        value={form.commonName}
                        onChange={e => setForm(prev => ({ ...prev, commonName: e.target.value }))}
                      />
                    </div>
                    <div className="relative group">
                      <div className="absolute left-4 md:left-5 top-1/2 -translate-y-1/2 text-emerald-400 group-focus-within:text-emerald-600 transition-colors">
                        <Beaker size={16} />
                      </div>
                      <input 
                        type="text" 
                        placeholder="Scientific Name (e.g. Hericium erinaceus)" 
                        className="w-full bg-stone-50 border border-stone-100 rounded-xl md:rounded-[24px] pl-12 md:pl-14 pr-5 py-3 md:py-4 focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-300 outline-none transition-all font-bold text-emerald-950 placeholder:text-stone-300 italic text-xs md:text-sm"
                        value={form.scientificName}
                        onChange={e => setForm(prev => ({ ...prev, scientificName: e.target.value }))}
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div 
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="absolute inset-0 overflow-y-auto px-6 md:px-10 py-4 md:py-6 space-y-5 md:space-y-6 scrollbar-hide"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                  <CustomDropdown 
                    label="Texture" 
                    value={form.texture} 
                    options={[
                      { label: 'Soft To Touch', icon: '☁️' },
                      { label: 'Hard To Touch', icon: '🪵' },
                      { label: 'Jelly Like', icon: '🍮' },
                      { label: 'Leathery', icon: '👞' }
                    ]}
                    onChange={val => setForm(prev => ({ ...prev, texture: val }))}
                  />
                  <CustomDropdown 
                    label="Underside" 
                    value={form.underside} 
                    options={[
                      { label: 'Gills', icon: '♒' },
                      { label: 'Pores', icon: '🕳️' },
                      { label: 'Teeth', icon: '🦷' },
                      { label: 'No Bottom', icon: '🚫' },
                      { label: 'Jelly', icon: '🍮' },
                      { label: 'Sponge', icon: '🧽' }
                    ]}
                    onChange={val => setForm(prev => ({ ...prev, underside: val }))}
                  />
                  <CustomDropdown 
                    label="Surface" 
                    value={form.fruitingSurface} 
                    options={[
                      { label: 'Ground', icon: '🏜️' },
                      { label: 'Leaf', icon: '🍃' },
                      { label: 'Wood', icon: '🪵' },
                      { label: 'Dung', icon: '💩' }
                    ]}
                    onChange={val => setForm(prev => ({ ...prev, fruitingSurface: val }))}
                  />
                  <CustomDropdown 
                    label="Stem Presence" 
                    value={form.stemPresence} 
                    options={[
                      { label: 'Has Stem', icon: '🌱' },
                      { label: 'Has No Stem', icon: '🚫' }
                    ]}
                    onChange={val => setForm(prev => ({ ...prev, stemPresence: val }))}
                  />
                </div>

                <div className="space-y-3">
                  <label className="block text-[9px] md:text-[10px] font-black text-stone-400 uppercase tracking-[0.2em]">Category</label>
                  <div className="flex flex-wrap gap-2">
                    {['Edible', 'Poisonous', 'Medicinal', 'Unknown'].map(use => (
                      <button 
                        key={use} 
                        onClick={() => toggleUse(use)}
                        className={`px-4 py-2.5 rounded-full text-[8px] md:text-[9px] font-black uppercase tracking-[0.15em] transition-all border ${form.commonUses.includes(use) ? 'bg-emerald-600 text-white border-emerald-600 shadow-md ring-4 ring-emerald-500/10' : 'bg-white border-stone-100 text-emerald-950 hover:bg-stone-50'}`}
                      >
                        {use}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-5 md:p-6 bg-amber-50 rounded-2xl md:rounded-[32px] border border-amber-100 flex gap-3 md:gap-4">
                  <div className="w-8 h-8 md:w-10 md:h-10 rounded-xl bg-white flex items-center justify-center text-amber-600 shadow-sm shrink-0">
                    <Star size={16} />
                  </div>
                  <div>
                    <h4 className="text-[9px] font-black text-amber-900 uppercase tracking-widest mb-0.5">Expert Contribution</h4>
                    <p className="text-[11px] text-amber-900/60 leading-relaxed font-medium">Detailed morphology helps differentiate lookalike species.</p>
                  </div>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div 
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="absolute inset-0 overflow-y-auto px-6 md:px-10 py-4 md:py-6 space-y-5 md:space-y-6 scrollbar-hide"
              >
                {/* Location Section */}
                <div className="space-y-5">
                  <div className="bg-stone-100 p-1 rounded-xl md:rounded-[22px] flex gap-1">
                    {[
                      { id: 'map', label: 'Map', icon: MapPin },
                      { id: 'city', label: 'City', icon: Search },
                      { id: 'manual', label: 'Manual', icon: NavigationIcon }
                    ].map(mode => (
                      <button 
                        key={mode.id}
                        onClick={() => setLocationMode(mode.id)}
                        className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 md:py-3.5 rounded-lg md:rounded-[18px] text-[8px] md:text-[9px] font-black uppercase tracking-widest transition-all ${locationMode === mode.id ? 'bg-white text-emerald-900 shadow-sm' : 'text-stone-500 hover:text-stone-700'}`}
                      >
                        <mode.icon size={12} className={mode.id === 'manual' ? 'rotate-45' : ''} /> {mode.label}
                      </button>
                    ))}
                  </div>

                  <div className="space-y-3">
                    {locationMode === 'map' && (
                      <div className="space-y-3">
                        {isLocationSet && (
                          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="p-3 md:p-4 bg-emerald-50 border border-emerald-100 rounded-xl md:rounded-[24px] flex items-center justify-between">
                             <div className="flex items-center gap-3">
                               <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-600/20"><Check size={16} /></div>
                               <div>
                                 <p className="text-[10px] font-black text-emerald-950 uppercase tracking-widest">Pin Confirmed</p>
                                 <p className="text-[10px] text-emerald-600 font-bold">{form.lat}, {form.lng}</p>
                               </div>
                             </div>
                             <button onClick={detectLocation} className="w-8 h-8 rounded-lg bg-white text-emerald-600 shadow-sm flex items-center justify-center hover:bg-emerald-50 transition-all border border-emerald-50">
                               <Clock size={12} />
                             </button>
                          </motion.div>
                        )}
                        <button 
                          onClick={onEnterPickingMode}
                          className="w-full bg-emerald-900 text-white rounded-2xl md:rounded-[32px] px-5 md:px-6 py-5 md:py-6 text-left transition-all shadow-xl shadow-emerald-900/20 hover:scale-[1.01] active:scale-95 group relative overflow-hidden"
                        >
                          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform duration-700">
                            <MapPin size={48} />
                          </div>
                          <div className="relative z-10 flex justify-between items-center">
                            <div className="flex-1">
                              <p className="text-[8px] font-black uppercase tracking-widest text-emerald-400 mb-1">Immersive Mapping</p>
                              <h4 className="text-base md:text-lg font-black italic leading-tight">Global Map Explorer</h4>
                            </div>
                            <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-emerald-500 transition-all shrink-0 ml-4">
                              <ChevronRight size={16} />
                            </div>
                          </div>
                        </button>
                      </div>
                    )}

                    {locationMode === 'city' && (
                      <div className="space-y-3">
                        <div className="relative group">
                          <Search className={`absolute left-4 top-1/2 -translate-y-1/2 transition-colors ${isSearchingCity ? 'text-emerald-500 animate-pulse' : 'text-stone-300 group-focus-within:text-emerald-600'}`} size={16} />
                          <input 
                            type="text" 
                            placeholder="Type city or region..." 
                            className="w-full bg-stone-50 border border-stone-100 rounded-xl md:rounded-[24px] px-10 md:px-12 py-3 md:py-4 focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-300 outline-none transition-all font-bold text-emerald-950 placeholder:text-stone-300 text-xs md:text-sm shadow-sm"
                            value={form.city || ''}
                            onChange={e => handleCitySearch(e.target.value)}
                          />
                        </div>
                      </div>
                    )}

                    {locationMode === 'manual' && (
                      <div className="grid grid-cols-2 gap-2 md:gap-3">
                        <div className="relative group">
                          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[8px] font-black text-stone-300 group-focus-within:text-emerald-500">LAT</div>
                          <input 
                            type="text" 
                            placeholder="00.000" 
                            className="w-full bg-stone-50 border border-stone-100 rounded-xl md:rounded-[24px] pl-10 pr-3 py-3 md:py-4 focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-300 outline-none transition-all font-bold text-emerald-950 placeholder:text-stone-200 text-xs"
                            value={form.lat || ''}
                            onChange={e => {
                              setForm(prev => ({ ...prev, lat: e.target.value }));
                              setIsLocationSet(true);
                            }}
                          />
                        </div>
                        <div className="relative group">
                          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[8px] font-black text-stone-300 group-focus-within:text-emerald-500">LNG</div>
                          <input 
                            type="text" 
                            placeholder="00.000" 
                            className="w-full bg-stone-50 border border-stone-100 rounded-xl md:rounded-[24px] pl-10 pr-3 py-3 md:py-4 focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-300 outline-none transition-all font-bold text-emerald-950 placeholder:text-stone-200 text-xs"
                            value={form.lng || ''}
                            onChange={e => {
                              setForm(prev => ({ ...prev, lng: e.target.value }));
                              setIsLocationSet(true);
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {step === 4 && (
              <motion.div 
                key="step4"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 flex flex-col items-center justify-center p-6 md:p-10 text-center bg-white"
              >
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', damping: 12 }} className="w-20 h-20 md:w-24 md:h-24 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 mb-6 md:mb-8 shadow-inner relative">
                  <div className="absolute inset-0 rounded-full bg-emerald-400/20 animate-ping" />
                  <Check size={40} className="relative z-10" strokeWidth={4} />
                </motion.div>
                <h3 className="text-2xl md:text-3xl font-black text-emerald-900 uppercase tracking-tight italic mb-2 md:mb-3 leading-tight">Contribution <span className="text-emerald-500">Encoded</span></h3>
                <p className="text-xs md:text-sm text-emerald-800/60 mb-6 md:mb-8 leading-relaxed px-4 font-medium">Your field observation has been integrated into the global database.</p>
                <button onClick={resetAndClose} className="w-full max-w-xs bg-emerald-950 text-white py-3.5 md:py-4 rounded-xl md:rounded-[24px] font-black uppercase tracking-[0.2em] hover:bg-black transition-all shadow-lg active:scale-95">Explorer Home</button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer Navigation */}
        {step <= 3 && (
          <div className="p-6 md:p-10 pt-0 shrink-0 bg-white">
            <button 
              onClick={() => {
                if (step === 3) {
                  onAdd({ ...form });
                  setStep(4);
                } else setStep(prev => prev + 1);
              }}
              className="w-full bg-[#00A86B] hover:bg-emerald-600 text-white py-4 md:py-5 rounded-2xl md:rounded-full font-black text-xs md:text-sm uppercase tracking-[0.2em] shadow-xl shadow-emerald-500/20 active:scale-[0.98] transition-all flex items-center justify-center gap-3 group"
            >
              <span>{step === 3 ? 'SEAL CONTRIBUTION' : 'CONTINUE'}</span>
              <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
};

const ObservationGallery = ({ observations, onViewDetails, onViewOnMap }) => {
  const [filter, setFilter] = useState('');
  const filtered = observations.filter(o => o.name.toLowerCase().includes(filter.toLowerCase()));
  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <SectionTitle title="My Observations" subtitle="Manage and track the mushroom sightings you've contributed." />
        <div className="relative w-full md:w-64">
           <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-emerald-400" size={16} />
           <input type="text" placeholder="Filter species..." className="w-full bg-white border border-emerald-100 rounded-xl py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-emerald-300 transition-all" onChange={(e) => setFilter(e.target.value)} />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {filtered.map((obs) => (
          <motion.div key={obs.id} whileHover={{ y: -5 }} className="bg-white rounded-[32px] overflow-hidden border border-emerald-50 hover:shadow-2xl transition-all group">
            <div className="relative h-48 cursor-pointer" onClick={() => onViewDetails(obs)}>
              <ImageWithFallback src={obs.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-[10px] font-bold text-emerald-900 flex items-center gap-1"><MapPin size={10} className="text-emerald-600" /> India</div>
            </div>
            <div className="p-6">
              <h4 className="font-bold text-emerald-950 mb-1">{obs.name}</h4>
              <p className="text-xs text-emerald-800/40 mb-4">{obs.date}</p>
              <div className="flex items-center justify-between mb-3">
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${obs.category === 'Toxic' ? 'bg-red-50 text-red-600' : obs.category === 'Medicinal' ? 'bg-purple-50 text-purple-600' : 'bg-emerald-50 text-emerald-600'}`}>{obs.category}</span>
                <button onClick={() => onViewDetails(obs)} className="text-emerald-400 group-hover:text-emerald-600 transition-colors"><ArrowUpRight size={18} /></button>
              </div>
              <button 
                onClick={() => onViewOnMap(obs)}
                className="w-full bg-emerald-600 text-white py-2 rounded-xl font-bold text-xs hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
              >
                <MapIcon size={14} />
                View on Map
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

const TrailsSection = () => {
  const [enrolling, setEnrolling] = useState(null);
  const handleEnroll = (id) => {
    setEnrolling(id);
    setTimeout(() => { alert("Welcome to the trail! Our field team will contact you."); setEnrolling(null); }, 1500);
  };
  return (
    <div className="space-y-12">
      <SectionTitle title="Walking Trails" subtitle="Curated ecological trails designed for mycology enthusiasts." />
      <div className="grid lg:grid-cols-2 gap-8">
        {TRAILS.map((trail) => (
          <div key={trail.id} className="bg-white rounded-[48px] p-8 border border-emerald-100 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-bl-[64px] transition-all group-hover:w-full group-hover:h-full group-hover:rounded-none z-0 opacity-50" />
            <div className="relative z-10">
              <div className="flex flex-wrap gap-3 mb-6">
                <StatBadge icon={Zap} label="Difficulty" value={trail.difficulty} color="bg-amber-100 text-amber-700" />
                <StatBadge icon={Info} label="Richness" value={trail.richness} color="bg-emerald-100 text-emerald-700" />
                <StatBadge icon={Clock} label="Duration" value={trail.duration} color="bg-blue-100 text-blue-700" />
              </div>
              <h3 className="text-3xl font-bold text-emerald-950 mb-4">{trail.name}</h3>
              <p className="text-emerald-800/60 mb-8 max-w-md">Located in {trail.location}, this trail features a high concentration of fungal biodiversity.</p>
              <button onClick={() => handleEnroll(trail.id)} disabled={enrolling === trail.id} className="bg-emerald-900 text-white px-10 py-4 rounded-2xl font-bold flex items-center gap-3 hover:bg-emerald-950 transition-all shadow-xl disabled:opacity-50">{enrolling === trail.id ? <Clock size={18} className="animate-spin" /> : <Lock size={18} />} {enrolling === trail.id ? 'Processing...' : 'Unlock Trail'}</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const ContributorsList = () => {
  const navigate = useNavigate();

  const handleContributorClick = (user) => {
    const contributorSlug = user.name.toLowerCase().replace(/\s+/g, '-');
    navigate(`/contributor/${contributorSlug}`);
  };

  // Calculate actual observation counts for each contributor
  const getObservationCount = (contributorName) => {
    return MUSHROOM_DATA.filter(obs => {
      const obsContributor = obs.contributor.toLowerCase();
      const fullName = contributorName.toLowerCase();
      const obsParts = obsContributor.split(' ').filter(p => p.length > 0);
      return obsParts.every(part => fullName.includes(part));
    }).length;
  };

  return (
    <div className="bg-emerald-50 rounded-[48px] p-8 md:p-12">
      <div className="text-center mb-16"><h2 className="text-3xl font-bold font-serif text-emerald-950 mb-4">Top Contributors</h2><p className="text-emerald-800/60">Fueling our scientific database.</p></div>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {CONTRIBUTORS.map((user, idx) => {
          const observationCount = getObservationCount(user.name);
          return (
            <div 
              key={user.id} 
              onClick={() => handleContributorClick(user)}
              className="bg-white p-6 rounded-[32px] text-center border border-white shadow-lg relative cursor-pointer hover:shadow-2xl hover:scale-105 transition-all group"
            >
             <div className="absolute top-4 left-4 w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center font-bold text-emerald-600 text-xs group-hover:bg-emerald-600 group-hover:text-white transition-colors">#{idx + 1}</div>
             <div className="relative mb-6 mx-auto w-24 h-24"><div className="absolute inset-0 bg-emerald-100 rounded-full scale-110 group-hover:bg-emerald-200 transition-colors" /><ImageWithFallback src={user.avatar} className="relative rounded-full w-full h-full object-cover border-4 border-white" /></div>
             <h4 className="font-bold text-emerald-950 mb-1 group-hover:text-emerald-700 transition-colors">{user.name}</h4><p className="text-emerald-600 text-xs font-bold mb-4">{user.level}</p>
             <div className="bg-emerald-50 py-2 px-4 rounded-xl inline-block group-hover:bg-emerald-600 group-hover:text-white transition-colors"><span className="text-lg font-bold text-emerald-900 group-hover:text-white">{observationCount}</span><span className="text-[10px] font-bold text-emerald-900/40 uppercase ml-1 group-hover:text-white/80">Observations</span></div>
          </div>
        );
        })}
      </div>
    </div>
  );
};

// --- Main Page Component ---

export default function MushroomHub() {
  const location = useLocation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('map');
  const [observations, setObservations] = useState(MUSHROOM_DATA);
  const [isObservationModalOpen, setIsObservationModalOpen] = useState(false);
  const [isPickingLocation, setIsPickingLocation] = useState(false);
  const [pickedLocation, setPickedLocation] = useState(null);
  const [selectedObservation, setSelectedObservation] = useState(null);

  // Handle incoming navigation state
  useEffect(() => {
    if (location.state?.selectedObservation) {
      // Only switch to map tab if NOT opening modal (i.e., "View on Map" button)
      if (location.state.openModal === false) {
        setActiveTab('map');
        setSelectedObservation(location.state.selectedObservation);
      } else {
        // Navigate to observation detail page instead of opening modal
        navigate(`/shroomhub/observation/${location.state.selectedObservation.id}`, { replace: true });
      }
    }
  }, [location.state, navigate]);

  const [observationForm, setObservationForm] = useState({
    commonName: '',
    scientificName: '',
    lat: '23.61606',
    lng: '79.05800',
    city: '',
    ecologicalRole: '',
    texture: '',
    underside: '',
    fruitingSurface: '',
    stemPresence: '',
    commonUses: [],
    image: null
  });
  const [observationStep, setObservationStep] = useState(1);

  return (
    <div className="min-h-screen bg-[#F9FAF8] selection:bg-emerald-200 scroll-smooth">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            <div className="lg:col-span-2">
              <div className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest mb-4"><ShieldCheck size={14} /> Verified Mycology Hub</div>
              <h1 className="text-4xl md:text-6xl font-bold font-serif text-emerald-950 mb-4 tracking-tight">Mushroom Hub</h1>
              <p className="text-emerald-800/60 max-w-xl text-lg">Map and discover the fungal kingdom of India through citizen science.</p>
            </div>
            <div className="bg-emerald-900 rounded-[32px] p-6 text-white relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-32 h-32 opacity-20 -mr-10 -mt-10 group-hover:scale-110 transition-transform"><Zap size={100} fill="white" /></div>
               <div className="relative z-10"><div className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-2">Species of the Day</div><h3 className="text-2xl font-bold mb-4 font-serif italic">Amanita Muscaria</h3><div className="flex items-center gap-3"><div className="w-12 h-12 rounded-xl overflow-hidden shadow-lg"><ImageWithFallback src="https://images.unsplash.com/photo-1649279595591-cfc7a11203fd" className="w-full h-full object-cover" /></div><button onClick={() => navigate(`/shroomhub/observation/${MUSHROOM_DATA[0].id}`)} className="bg-white/10 hover:bg-white/20 backdrop-blur-md px-4 py-2 rounded-xl text-xs font-bold transition-all">View Profile</button></div></div>
            </div>
          </div>
          
          <div className="bg-white p-1.5 rounded-2xl shadow-sm border border-emerald-100 flex gap-1 w-full md:w-fit max-w-full overflow-x-auto scrollbar-hide mb-12">
              {[ { id: 'map', label: 'Explore Map', icon: MapIcon }, { id: 'observations', label: 'Observations', icon: GalleryVertical }, { id: 'trails', label: 'Trails', icon: Route }, { id: 'community', label: 'Community', icon: Users } ].map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold transition-all whitespace-nowrap ${activeTab === tab.id ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'text-emerald-800/40 hover:text-emerald-800/60'}`}><tab.icon size={18} />{tab.label}</button>
              ))}
          </div>

          <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="mb-20">
            {activeTab === 'map' && (
              <MapExplorer 
                observations={observations} 
                onAddClick={() => setIsObservationModalOpen(true)} 
                onViewDetails={(obs) => navigate(`/shroomhub/observation/${obs.id}`)} 
                isPickingLocation={isPickingLocation}
                selectedObservation={selectedObservation}
                onLocationPick={(latlng) => {
                  setPickedLocation(latlng);
                  setIsPickingLocation(false);
                  setIsObservationModalOpen(true);
                  setObservationStep(3); // Set back to location step
                }}
              />
            )}
            {activeTab === 'observations' && (
              <ObservationGallery 
                observations={observations} 
                onViewDetails={(obs) => navigate(`/shroomhub/observation/${obs.id}`)}
                onViewOnMap={(obs) => {
                  setActiveTab('map');
                  setSelectedObservation(obs);
                }}
              />
            )}
            {activeTab === 'trails' && <TrailsSection />}
            {activeTab === 'community' && <ContributorsList />}
          </motion.div>
        </div>
      </main>
      <Footer />
      <AnimatePresence>
        {isObservationModalOpen && (
          <AddObservation 
            isOpen={isObservationModalOpen} 
            onClose={() => {
              setIsObservationModalOpen(false);
              setObservationStep(1);
              setObservationForm({
                commonName: '',
                scientificName: '',
                lat: '23.61606',
                lng: '79.05800',
                city: '',
                ecologicalRole: '',
                texture: '',
                underside: '',
                fruitingSurface: '',
                stemPresence: '',
                commonUses: [],
                image: null
              });
            }} 
            onEnterPickingMode={() => {
              setIsObservationModalOpen(false);
              setIsPickingLocation(true);
            }}
            pickedLocation={pickedLocation}
            clearPickedLocation={() => setPickedLocation(null)}
            form={observationForm}
            setForm={setObservationForm}
            step={observationStep}
            setStep={setObservationStep}
            onAdd={(newObs) => {
              const obsWithId = {
                ...newObs,
                id: Date.now(),
                name: newObs.commonName || 'Unnamed Specimen',
                category: newObs.commonUses && newObs.commonUses.length > 0 ? newObs.commonUses[0] : 'Unknown',
                location: newObs.city || 'Field Location',
                contributor: 'You',
                date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
              };
              setObservations(prev => [obsWithId, ...prev]);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}