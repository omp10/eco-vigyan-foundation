export const MUSHROOM_DATA = [
  { 
    id: '1', 
    name: 'Amanita Muscaria', 
    scientificName: 'Amanita muscaria',
    category: 'Toxic', 
    lat: 31.1048, 
    lng: 77.1734, 
    location: 'Shimla, HP', 
    image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', 
    contributor: 'Dr. Sharma', 
    date: 'February 2026',
    ecologicalRole: 'Decomposer',
    texture: 'Soft To Touch',
    characteristics: {
      underside: 'Gills',
      stem: 'Has Stem',
    }
  },
  { 
    id: '2', 
    name: 'Boletus Edulis', 
    scientificName: 'Boletus edulis',
    category: 'Edible', 
    lat: 32.2432, 
    lng: 77.1892, 
    location: 'Manali, HP', 
    image: 'https://images.unsplash.com/photo-1760125485581-94e5fdf0de5c', 
    contributor: 'Vikram M.', 
    date: 'February 2026',
    ecologicalRole: 'Mycorrhizal',
    texture: 'Firm',
    characteristics: {
      underside: 'Pores',
      stem: 'Has Stem',
    }
  },
  { 
    id: '3', 
    name: 'Chanterelle', 
    scientificName: 'Cantharellus cibarius',
    category: 'Medicinal', 
    lat: 10.8505, 
    lng: 76.2711, 
    location: 'Wayanad, Kerala', 
    image: 'https://images.unsplash.com/photo-1767606924643-1c00ddce5a5b', 
    contributor: 'Sarah C.', 
    date: 'February 2026',
    ecologicalRole: 'Mycorrhizal',
    texture: 'Smooth',
    characteristics: {
      underside: 'False Gills',
      stem: 'Has Stem',
    }
  },
  { 
    id: '4', 
    name: 'Death Cap', 
    scientificName: 'Amanita phalloides',
    category: 'Toxic', 
    lat: 18.5204, 
    lng: 73.8567, 
    location: 'Pune, MH', 
    image: 'https://images.unsplash.com/photo-1642102507644-012ac6859e5e', 
    contributor: 'Rahul V.', 
    date: 'February 2026',
    ecologicalRole: 'Mycorrhizal',
    texture: 'Smooth',
    characteristics: {
      underside: 'Gills',
      stem: 'Has Stem',
    }
  },
  { 
    id: '5', 
    name: 'Oyster Mushroom', 
    scientificName: 'Pleurotus ostreatus',
    category: 'Edible', 
    lat: 30.3165, 
    lng: 78.0322, 
    location: 'Dehradun, UK', 
    image: 'https://images.unsplash.com/photo-1768176560100-d8a1d73171a6', 
    contributor: 'Dr. Sharma', 
    date: 'February 2026',
    ecologicalRole: 'Decomposer',
    texture: 'Soft',
    characteristics: {
      underside: 'Gills',
      stem: 'Has No Stem',
    }
  },
  { 
    id: '6', 
    name: 'Shiitake', 
    scientificName: 'Lentinula edodes',
    category: 'Edible', 
    lat: 25.5788, 
    lng: 91.8933, 
    location: 'Shillong, Meghalaya', 
    image: 'https://images.unsplash.com/photo-1764627198595-65471a257c91', 
    contributor: 'Vikram M.', 
    date: 'February 2026',
    ecologicalRole: 'Decomposer',
    texture: 'Firm',
    characteristics: {
      underside: 'Gills',
      stem: 'Has Stem',
    }
  },
  { 
    id: '7', 
    name: 'Lion\'s Mane', 
    scientificName: 'Hericium erinaceus',
    category: 'Medicinal', 
    lat: 24.5854, 
    lng: 73.7125, 
    location: 'Udaipur, RJ', 
    image: 'https://images.unsplash.com/photo-1767606924643-1c00ddce5a5b', 
    contributor: 'Sarah C.', 
    date: 'February 2026',
    ecologicalRole: 'Decomposer',
    texture: 'Soft',
    characteristics: {
      underside: 'Teeth',
      stem: 'Has No Stem',
    }
  },
  { 
    id: '8', 
    name: 'Shaggy Mane', 
    scientificName: 'Coprinus comatus',
    category: 'Edible', 
    lat: 26.8467, 
    lng: 80.9462, 
    location: 'Lucknow, UP', 
    image: 'https://images.unsplash.com/photo-1768176560100-d8a1d73171a6', 
    contributor: 'Rahul V.', 
    date: 'February 2026',
    ecologicalRole: 'Decomposer',
    texture: 'Delicate',
    characteristics: {
      underside: 'Gills',
      stem: 'Has Stem',
    }
  },
  { 
    id: '9', 
    name: 'Reishi', 
    scientificName: 'Ganoderma lucidum',
    category: 'Medicinal', 
    lat: 22.5726, 
    lng: 88.3639, 
    location: 'Kolkata, WB', 
    image: 'https://images.unsplash.com/photo-1760125485581-94e5fdf0de5c', 
    contributor: 'Dr. Sharma', 
    date: 'February 2026',
    ecologicalRole: 'Decomposer',
    texture: 'Hard',
    characteristics: {
      underside: 'Pores',
      stem: 'Has No Stem',
    }
  },
  { 
    id: '10', 
    name: 'Honey Fungus', 
    scientificName: 'Armillaria mellea',
    category: 'Edible', 
    lat: 12.9716, 
    lng: 77.5946, 
    location: 'Bangalore, KA', 
    image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', 
    contributor: 'Sarah C.', 
    date: 'February 2026',
    ecologicalRole: 'Parasite',
    texture: 'Firm',
    characteristics: {
      underside: 'Gills',
      stem: 'Has Stem',
    }
  },
  { 
    id: '11', 
    name: 'Inky Cap', 
    scientificName: 'Coprinopsis atramentaria',
    category: 'Toxic', 
    lat: 17.3850, 
    lng: 78.4867, 
    location: 'Hyderabad, TS', 
    image: 'https://images.unsplash.com/photo-1642102507644-012ac6859e5e', 
    contributor: 'Vikram M.', 
    date: 'February 2026',
    ecologicalRole: 'Decomposer',
    texture: 'Delicate',
    characteristics: {
      underside: 'Gills',
      stem: 'Has Stem',
    }
  },
  { 
    id: '12', 
    name: 'Fly Agaric', 
    scientificName: 'Amanita muscaria var.',
    category: 'Toxic', 
    lat: 34.0837, 
    lng: 74.7973, 
    location: 'Srinagar, J&K', 
    image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', 
    contributor: 'Dr. Sharma', 
    date: 'February 2026',
    ecologicalRole: 'Mycorrhizal',
    texture: 'Soft',
    characteristics: {
      underside: 'Gills',
      stem: 'Has Stem',
    }
  },
  { 
    id: '13', 
    name: 'Wood Ear', 
    scientificName: 'Auricularia auricula-judae',
    category: 'Medicinal', 
    lat: 15.2993, 
    lng: 74.1240, 
    location: 'North Goa', 
    image: 'https://images.unsplash.com/photo-1768176560100-d8a1d73171a6', 
    contributor: 'Sarah C.', 
    date: 'February 2026',
    ecologicalRole: 'Decomposer',
    texture: 'Gelatinous',
    characteristics: {
      underside: 'Smooth',
      stem: 'Has No Stem',
    }
  },
  { 
    id: '14', 
    name: 'False Morel', 
    scientificName: 'Gyromitra esculenta',
    category: 'Toxic', 
    lat: 27.1751, 
    lng: 78.0421, 
    location: 'Agra, UP', 
    image: 'https://images.unsplash.com/photo-1642102507644-012ac6859e5e', 
    contributor: 'Rahul V.', 
    date: 'February 2026',
    ecologicalRole: 'Decomposer',
    texture: 'Waxy',
    characteristics: {
      underside: 'Wrinkled',
      stem: 'Has Stem',
    }
  },
  // Additional density for Western Ghats
  { id: '15', name: 'Ghats Specimen A', scientificName: 'Species unknown', category: 'Medicinal', lat: 10.9505, lng: 76.3711, location: 'Western Ghats', image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', contributor: 'System', date: 'August 2025', ecologicalRole: 'Decomposer', texture: 'Unknown', characteristics: {underline: 'Unknown', stem: 'Unknown' } },
  { id: '16', name: 'Ghats Specimen B', scientificName: 'Species unknown', category: 'Toxic', lat: 10.7505, lng: 76.1711, location: 'Western Ghats', image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', contributor: 'System', date: 'September 2025', ecologicalRole: 'Unknown', texture: 'Unknown', characteristics: {underline: 'Unknown', stem: 'Unknown' } },
  { id: '17', name: 'Ghats Specimen C', scientificName: 'Species unknown', category: 'Edible', lat: 11.0505, lng: 76.4711, location: 'Western Ghats', image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', contributor: 'System', date: 'October 2024', ecologicalRole: 'Unknown', texture: 'Unknown', characteristics: {underline: 'Unknown', stem: 'Unknown' } },
  { id: '18', name: 'Ghats Specimen D', scientificName: 'Species unknown', category: 'Medicinal', lat: 10.8505, lng: 76.2711, location: 'Western Ghats', image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', contributor: 'System', date: 'November 2024', ecologicalRole: 'Unknown', texture: 'Unknown', characteristics: {underline: 'Unknown', stem: 'Unknown' } },
  { id: '19', name: 'Ghats Specimen E', scientificName: 'Species unknown', category: 'Toxic', lat: 10.8205, lng: 76.2411, location: 'Western Ghats', image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', contributor: 'System', date: 'December 2025', ecologicalRole: 'Unknown', texture: 'Unknown', characteristics: {underline: 'Unknown', stem: 'Unknown' } },
  // Additional density for Himalayas
  { id: '20', name: 'Himalayan Specimen A', scientificName: 'Species unknown', category: 'Medicinal', lat: 31.2048, lng: 77.2734, location: 'Himalayas', image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', contributor: 'System', date: 'May 2025', ecologicalRole: 'Unknown', texture: 'Unknown', characteristics: {underline: 'Unknown', stem: 'Unknown' } },
  { id: '21', name: 'Himalayan Specimen B', scientificName: 'Species unknown', category: 'Medicinal', lat: 31.0048, lng: 77.0734, location: 'Himalayas', image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', contributor: 'System', date: 'June 2024', ecologicalRole: 'Unknown', texture: 'Unknown', characteristics: {underline: 'Unknown', stem: 'Unknown' } },
  { id: '22', name: 'Himalayan Specimen C', scientificName: 'Species unknown', category: 'Edible', lat: 31.1548, lng: 77.2234, location: 'Himalayas', image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', contributor: 'System', date: 'July 2025', ecologicalRole: 'Unknown', texture: 'Unknown', characteristics: {underline: 'Unknown', stem: 'Unknown' } },
  { id: '23', name: 'Himalayan Specimen D', scientificName: 'Species unknown', category: 'Medicinal', lat: 31.0548, lng: 77.1234, location: 'Himalayas', image: 'https://images.unsplash.com/photo-1649279595591-cfc7a11203fd', contributor: 'System', date: 'August 2024', ecologicalRole: 'Unknown', texture: 'Unknown', characteristics: {underline: 'Unknown', stem: 'Unknown' } },
];

export const CONTRIBUTORS = [
  { id: 1, name: 'Dr. Anjali Sharma', count: 142, level: 'Master Mycologist', avatar: 'https://images.unsplash.com/photo-1758685734511-4f49ce9a382b' },
  { id: 2, name: 'Vikram Mehta', count: 98, level: 'Forest Ranger', avatar: 'https://images.unsplash.com/photo-1563483698880-22d436fe9b68' },
  { id: 3, name: 'Sarah Chen', count: 75, level: 'Research Lead', avatar: 'https://images.unsplash.com/photo-1647150370279-69d9b1a0ecbb' },
  { id: 4, name: 'Rahul Varma', count: 42, level: 'Active Observer', avatar: 'https://images.unsplash.com/photo-1721457616561-701d25702874' },
];

export const TRAILS = [
  {
    id: 1,
    name: 'The Whispering Pines Trail',
    location: 'Kasol, HP',
    difficulty: 'Moderate',
    richness: 'High (12+ species)',
    duration: '120 mins',
    mushrooms: ['Amanita Muscaria', 'Boletus Edulis', 'Oyster'],
    isPremium: true
  },
  {
    id: 2,
    name: 'Silent Valley Myco-Walk',
    location: 'Kerala',
    difficulty: 'Hard',
    richness: 'Very High (20+ species)',
    duration: '240 mins',
    mushrooms: ['Chanterelle', 'Lions Mane', 'Turkey Tail'],
    isPremium: true
  }
];

export const CATEGORIES = [
  'Edible', 'Toxic', 'Medicinal', 'Psychoactive', 'Gilled', 'Bolete', 'Coral', 'Puffball', 
  'Wood-decay', 'Mycorrhizal', 'Parasitic', 'Rare', 'Endangered', 'Invasive', 'Common',
  'Autumnal', 'Vernal', 'Tropical', 'Alpine', 'Temperate', 'Coastal', 'Urban', 'Deep Forest',
  'Rocky Terrain', 'Marshy Ground'
];