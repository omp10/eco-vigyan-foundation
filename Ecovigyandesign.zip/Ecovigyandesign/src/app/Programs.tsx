import React, { useState } from 'react';
import { Calendar, Clock, Users, MapPin, Award, Sprout, School, Recycle, ChevronRight, CheckCircle2, Star, BookOpen, Leaf, TreeDeciduous, GraduationCap, Heart, Mail, ArrowLeft, Send, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { useAuth } from './contexts/AuthContext';
import { LoginPrompt } from './components/LoginPrompt';
import { ProgramModal } from './components/ProgramModal';

interface Program {
  id: string;
  title: string;
  tagline: string;
  description: string;
  isPrimary?: boolean;
  icon: React.ElementType;
  duration: string;
  participants: string;
  highlights: string[];
  syllabus: string[];
  outcomes: string[];
  targetAudience: string[];
  image: string;
  color: string;
  statistics?: {
    label: string;
    value: string;
    description: string;
  };
  locations?: string[];
  testimonials?: {
    name: string;
    text: string;
  }[];
  videoUrl?: string;
  videoEmbed?: string;
  additionalLink?: {
    text: string;
    url: string;
  };
}

const programs: Program[] = [
  {
    id: 'mushroom-walk',
    title: 'Guided Mushroom Walks',
    tagline: 'Discover biodiversity through year-round mushroom identification',
    description: 'Discover biodiversity through year-round mushroom identification, focusing on the monsoon season. This exciting project helps demystify the ecological roles of fungi with six key features, followed by the creation of mobile mushroom museums.',
    icon: Sprout,
    duration: 'Year-round (peak season: Monsoon)',
    participants: 'Small groups',
    highlights: [
      'Expert-guided mushroom walks across 18+ locations',
      'Year-round identification with focus on monsoon season',
      'Hands-on biodiversity discovery and documentation',
      'Learn ecological roles and fungi interactions',
      'Pre-monsoon habitat tagging experiments',
      'Creation of mobile mushroom museums'
    ],
    syllabus: [
      'Introduction to fungi biodiversity and identification basics',
      'Habitat tagging and fruiting prediction techniques',
      'Monsoon season intensive walks and species documentation',
      'Ecological roles of fungi in forest ecosystems',
      'Photography and field documentation methods',
      'Mobile mushroom museum creation and curation'
    ],
    outcomes: [
      'Identify mushroom species in their natural habitats',
      'Understand fungi\'s crucial ecological roles',
      'Participate in citizen science documentation',
      'Contribute to regional biodiversity knowledge'
    ],
    targetAudience: [
      'Nature enthusiasts and hikers',
      'Students and educators',
      'Amateur mycologists',
      'Families seeking outdoor education'
    ],
    statistics: {
      label: 'Success Rate',
      value: '36/40',
      description: 'In a pre-monsoon experiment, students tagged potential habitats; two months later, 36 out of 40 tags successfully fruited with mushrooms.'
    },
    locations: [
      'Bangalore',
      'Nalagarh',
      'Churdhar Peak',
      'Shali Peak',
      'Gurugram',
      'Mussoorie',
      'Dehradun',
      'Chandigarh',
      'Joshimath',
      'Manali',
      'Mandi',
      'Rudraprayag',
      'Ramnagar',
      'Shimla',
      'Bir',
      'Dharampur',
      'Solan',
      'Summerhill'
    ],
    testimonials: [
      {
        name: 'Padmini Parmar',
        text: 'A very interesting and informative mushroom walk organised by Shrey and Ashish. Never knew a whole new, exciting world of fungi existed right beside the road which I had passed countless times.'
      }
    ],
    videoUrl: 'https://youtu.be/vqc6lOWicPE',
    videoEmbed: 'https://www.youtube.com/embed/vqc6lOWicPE',
    additionalLink: {
      text: 'A look back at our walks from last year',
      url: 'https://youtu.be/vqc6lOWicPE'
    },
    image: 'forest mushroom expedition',
    color: 'from-amber-500 to-orange-600'
  },
  {
    id: 'grow-mushrooms',
    title: 'Grow Your Own Mushrooms',
    tagline: 'Turn your kitchen waste into a bountiful mushroom harvest',
    description: 'This is an online, hands-on series of 8 sessions to help you grow your own oyster mushrooms on kitchen waste. Follow along & towards the end of this series, you will be able to successfully harvest your first crop in 30 days.',
    isPrimary: true,
    icon: TreeDeciduous,
    duration: '8 online sessions',
    participants: 'Individual learners',
    highlights: [
      'Grow oyster mushrooms on kitchen waste',
      '8 comprehensive hands-on sessions',
      'First harvest in just 30 days',
      'Beginner friendly - no experience needed',
      'Step-by-step guidance from experts',
      'Online format - learn from home'
    ],
    syllabus: [
      'Session 1: Introduction to mushroom cultivation and kitchen waste preparation',
      'Session 2: Understanding oyster mushroom biology and growth requirements',
      'Session 3: Substrate preparation using kitchen scraps',
      'Session 4: Spawn inoculation and sterile techniques',
      'Session 5: Creating optimal growing conditions at home',
      'Session 6: Monitoring growth and troubleshooting common issues',
      'Session 7: Fruiting initiation and pinning phase',
      'Session 8: Harvesting techniques and celebrating your first crop'
    ],
    outcomes: [
      'Successfully grow oyster mushrooms from kitchen waste',
      'Harvest your first mushroom crop within 30 days',
      'Reduce kitchen waste through productive recycling',
      'Gain confidence to continue growing mushrooms independently'
    ],
    targetAudience: [
      'Home gardeners and urban dwellers',
      'Sustainability enthusiasts',
      'Beginners with no prior experience',
      'Anyone wanting to reduce kitchen waste',
      'Families seeking fun educational projects'
    ],
    testimonials: [
      {
        name: 'Romi Kohsala',
        text: 'I am not sure which is easier- to push a car uphill single-handedly or to enthuse an 80-year person to get excited to grow mushrooms. But Shrey has done just that. I was successful. Oysters grew. I just followed what he told me to do.'
      },
      {
        name: 'Raman Bhal',
        text: 'Something that I couldn\'t even measure was the happiness which I got post getting the first harvest! It was invaluable!'
      },
      {
        name: 'Anonymous Participant',
        text: 'My family says there must be something extraordinary about him. They are absolutely right.'
      }
    ],
    image: 'mushroom cultivation workshop',
    color: 'from-emerald-500 to-teal-600'
  },
  {
    id: 'demystify-fungi',
    title: 'Demystify Your Local Fungi',
    tagline: 'Become local mushroom experts and create a field guide',
    description: 'Join us on an exciting journey to become local mushroom experts! You\'ll become masters at spotting and understanding the ecological importance of mushrooms for life. Plus, we\'ll create a field guide of the mushrooms around you.',
    icon: BookOpen,
    duration: 'Multi-week program',
    participants: 'Small groups',
    highlights: [
      'Field exploration in your local area',
      'Macro observation and photography techniques',
      'Regular local mushroom walks and surveys',
      'Species identification and documentation',
      'Co-create a comprehensive field guide for your region',
      'Understand ecological importance of fungi'
    ],
    syllabus: [
      'Week 1: Introduction to local fungi biodiversity and field techniques',
      'Week 2-3: Field exploration and habitat surveys in your area',
      'Week 3-4: Macro observation and mushroom photography',
      'Week 4-5: Species identification and ecological roles',
      'Week 5-6: Field guide creation and documentation',
      'Week 6: Final field guide presentation and publishing'
    ],
    outcomes: [
      'Become experts at spotting local mushroom species',
      'Understand the ecological importance of fungi',
      'Co-create a published field guide for your region',
      'Contribute to local biodiversity knowledge'
    ],
    targetAudience: [
      'Citizen scientists and nature recorders',
      'Local community members interested in nature',
      'Amateur naturalists and photographers',
      'Environmental educators and students'
    ],
    testimonials: [
      {
        name: 'Venus Joshi',
        text: 'Got yet another reason to walk in Woods.. Definitely looking forward to Co-creating a guide book for my area.'
      }
    ],
    image: 'scientific fungi documentation',
    color: 'from-blue-500 to-indigo-600'
  },
  {
    id: 'wipro-earthian',
    title: 'Wipro Earthian Program',
    tagline: 'National Level School Competition for Sustainability',
    description: 'Eco Vigyan gladly invites you to attend the National Level School Competition for Sustainability managed by Wipro earthian in collaboration with Wipro earthian\'s Sustainability Program and the Department of Education (DOE) Himachal Pradesh. This competition is open to all Schools, Administrations, Teachers, and Educational Institutions across India to build knowledge, skills, and a mindset for self-reliance.',
    isPrimary: true,
    icon: School,
    duration: 'Full academic year',
    participants: 'Whole school community',
    highlights: [
      'Biodiversity & Nature Care initiatives',
      'Water & Waste Management projects',
      'Community Awareness campaigns',
      'National-level competition participation',
      'Collaboration with DOE Himachal Pradesh',
      'Build knowledge, skills, and self-reliance mindset'
    ],
    syllabus: [
      'Phase 1: Registration and eco-club formation',
      'Phase 2: Biodiversity surveys and nature care projects',
      'Phase 3: Water conservation and waste management systems',
      'Phase 4: Community outreach and awareness programs',
      'Phase 5: Project documentation and presentation',
      'Phase 6: National competition and awards ceremony'
    ],
    outcomes: [
      'Develop comprehensive sustainability projects',
      'Compete at national level with schools across India',
      'Build leadership and project management skills',
      'Create lasting environmental impact in school communities'
    ],
    targetAudience: [
      'Schools across India',
      'School Administrations',
      'Teachers and Educators',
      'Educational Institutions'
    ],
    videoUrl: 'https://youtu.be/Ri-3fJ3JoHY',
    videoEmbed: 'https://www.youtube.com/embed/Ri-3fJ3JoHY',
    additionalLink: {
      text: 'To look back at our journey with the program in Himachal last year, click here!',
      url: '#'
    },
    image: 'school environmental education',
    color: 'from-purple-500 to-pink-600'
  },
  {
    id: 'chemical-free',
    title: 'Chemical Free Living Series',
    tagline: '3 Sessions to decode non-toxic living',
    description: 'To handhold you and get you off most synthetic chemicals in your everyday routine, we are happy to announce a journey of 3 sessions to decode a synthetic chemical-free living.',
    isPrimary: true,
    icon: Heart,
    duration: '3 sessions',
    participants: 'Small groups',
    highlights: [
      'Chemical-free Edibles: Decode what goes into your food and transition to natural alternatives',
      'Personal Care Products: Learn to identify synthetic chemicals in skincare and hygiene routines',
      'Household Cleaning: Create effective, non-toxic cleaners for a safer home environment',
      'Hands-on sessions with practical solutions',
      'Make bio-products with easily available ingredients',
      'Reflective approach focusing on solutions, not just problems'
    ],
    syllabus: [
      'Session 1: Chemical-free Edibles - Understanding food ingredients and natural alternatives',
      'Session 1: Decoding labels and identifying harmful additives in everyday foods',
      'Session 2: Personal Care Products - Synthetic chemicals in skincare and hygiene',
      'Session 2: Creating natural alternatives for personal care routines',
      'Session 3: Household Cleaning - Non-toxic cleaners for home environment',
      'Session 3: DIY bio-products with easily accessible ingredients'
    ],
    outcomes: [
      'Identify synthetic chemicals in everyday products',
      'Create natural alternatives for food, personal care, and cleaning',
      'Transition to a non-toxic living routine',
      'Make bio-products on your own with simple ingredients'
    ],
    targetAudience: [
      'Health-conscious families and parents',
      'Educators and school communities',
      'Anyone seeking toxin-free living solutions',
      'Environmental enthusiasts'
    ],
    testimonials: [
      {
        name: 'Educator',
        text: 'It was reflective and provided solutions rather just discussing about problems'
      },
      {
        name: 'Educator',
        text: 'What is not good for you & me is not good for Mother earth too!'
      },
      {
        name: 'Educator',
        text: 'We could make bioproducts on our own and the ingredients were as easily available as the process.'
      }
    ],
    image: 'natural products workshop',
    color: 'from-rose-500 to-red-600'
  },
  {
    id: 'waste-management',
    title: 'Mastering Solid Waste Management',
    tagline: 'Empower your community in waste management',
    description: 'This is our pilot program, designed to empower institutes, households, and communities in waste management. Learn practical solutions for composting, zero-waste events, and community-wide sustainability initiatives.',
    icon: Recycle,
    duration: '6-8 months for full cycle',
    participants: 'Institutes, households, communities',
    highlights: [
      'Streamlined Composting: Deliver organic compost in just 6-8 months',
      'Zero-Waste Events: Host events where waste is upcycled following the 3 R\'s',
      'Transform waste into decorations and unique gifts',
      'Community-wide waste management systems',
      'Hands-on training for institutes and households',
      'Proven pilot program with successful implementations'
    ],
    syllabus: [
      'Module 1: Introduction to waste management and the 3 R\'s (Reduce, Reuse, Recycle)',
      'Module 2: Setting up streamlined composting systems for organic waste',
      'Module 3: Waste segregation and collection best practices',
      'Module 4: Planning and executing zero-waste events',
      'Module 5: Upcycling waste into decorations and gifts',
      'Module 6: Scaling to community-wide sustainability initiatives'
    ],
    outcomes: [
      'Produce organic compost in 6-8 months from waste',
      'Host successful zero-waste events in your community',
      'Upcycle waste into useful decorations and gifts',
      'Transform from nature lover to nature protector'
    ],
    targetAudience: [
      'Educational institutes and schools',
      'Households seeking sustainable practices',
      'Community organizations and NGOs',
      'Event organizers and planners'
    ],
    videoUrl: 'https://youtu.be/lyseeUQZv0Y',
    videoEmbed: 'https://www.youtube.com/embed/lyseeUQZv0Y',
    additionalLink: {
      text: 'Check out how school events transform waste into decorations & unique gifts',
      url: 'https://youtu.be/lyseeUQZv0Y'
    },
    testimonials: [
      {
        name: 'Dr. Shilpi Singh',
        text: 'From being a nature lover I became a nature protector. Thank you, Shery to show me the easy way of living keep up the good work and keep inspiring'
      }
    ],
    image: 'waste management training',
    color: 'from-green-500 to-emerald-600'
  }
];

export default function Programs() {
  const [selectedProgram, setSelectedProgram] = useState<Program | null>(null);
  const [modalView, setModalView] = useState<'details' | 'enrollment' | 'success'>('details');
  const { user, isAuthenticated } = useAuth();
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Reset modal state when program changes
  const openProgramModal = (program: Program) => {
    setSelectedProgram(program);
    setModalView('details');
    if (user) {
      setFormData({
        fullName: user.name || '',
        email: user.email || '',
        phone: '',
        message: ''
      });
    }
  };

  const handleEnrollClick = () => {
    setModalView('enrollment');
  };

  const handleBackToDetails = () => {
    setModalView('details');
  };

  const handleCloseModal = () => {
    setSelectedProgram(null);
    setModalView('details');
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      message: ''
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Save to localStorage
    const enrollment = {
      id: `enrollment-${Date.now()}`,
      userId: user?.id,
      programId: selectedProgram?.id,
      programTitle: selectedProgram?.title,
      studentName: formData.fullName,
      email: formData.email,
      phone: formData.phone,
      message: formData.message,
      status: 'pending',
      submittedAt: new Date().toISOString()
    };

    const existingEnrollments = JSON.parse(localStorage.getItem('ecovigyan_enrollments') || '[]');
    localStorage.setItem('ecovigyan_enrollments', JSON.stringify([...existingEnrollments, enrollment]));
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setModalView('success');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-br from-emerald-600 to-teal-700 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-96 h-96 border-2 border-white rounded-full" />
          <div className="absolute bottom-10 right-10 w-64 h-64 border-2 border-white rounded-full" />
          <div className="absolute top-1/2 left-1/2 w-80 h-80 border border-white rounded-full" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-white/90 text-sm font-medium mb-6">
              <GraduationCap className="w-4 h-4" />
              <span>Education Meets Adventure</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 font-serif">
              Sustainability Programs
            </h1>
            <p className="text-xl md:text-2xl text-emerald-50 max-w-3xl mx-auto leading-relaxed">
              Explore our exciting programs where environmental science comes alive through hands-on learning and community action
            </p>
          </motion.div>
        </div>
      </section>

      {/* Programs Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {programs.map((program, index) => (
              <motion.div
                key={program.id}
                id={program.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group relative"
              >
                <div className="h-full bg-white rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border border-emerald-100">
                  {/* Header with Gradient */}
                  <div className={`relative h-48 bg-gradient-to-br ${program.color} p-8 flex items-center justify-between`}>
                    <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_50%_120%,_white,transparent)]" />
                    <div className="relative z-10 flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                          <program.icon className="w-7 h-7 text-white" />
                        </div>
                        {program.isPrimary && (
                          <span className="bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-xs font-bold">
                            FEATURED
                          </span>
                        )}
                      </div>
                      <h3 className="text-3xl font-bold text-white mb-2 font-serif">
                        {program.title}
                      </h3>
                      <p className="text-white/90 text-sm">
                        {program.tagline}
                      </p>
                    </div>
                  </div>

                  <div className="p-8">
                    {/* Quick Info */}
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Clock className="w-4 h-4 text-emerald-600" />
                        <span>{program.duration}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Users className="w-4 h-4 text-emerald-600" />
                        <span>{program.participants}</span>
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-gray-600 leading-relaxed mb-6">
                      {program.description}
                    </p>

                    {/* Highlights Preview */}
                    <div className="mb-6">
                      <h4 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                        <Star className="w-4 h-4 text-yellow-500" />
                        Program Highlights
                      </h4>
                      <ul className="space-y-2">
                        {program.highlights.slice(0, 3).map((highlight, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-gray-600">
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                            <span>{highlight}</span>
                          </li>
                        ))}
                        {program.highlights.length > 3 && (
                          <li className="text-sm text-emerald-600 font-medium pl-6">
                            + {program.highlights.length - 3} more benefits
                          </li>
                        )}
                      </ul>
                    </div>

                    {/* CTA Button */}
                    <button
                      onClick={() => openProgramModal(program)}
                      className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-6 py-4 rounded-xl font-bold hover:from-emerald-700 hover:to-teal-700 transition-all flex items-center justify-center gap-2 group shadow-lg"
                    >
                      <span>View Full Details & Enroll</span>
                      <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-br from-emerald-900 to-teal-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 right-20 w-96 h-96 border border-white rounded-full" />
          <div className="absolute bottom-10 left-10 w-64 h-64 border border-white rounded-full" />
        </div>
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Leaf className="w-16 h-16 text-emerald-400 mx-auto mb-6" />
          <h2 className="text-4xl font-bold text-white mb-6 font-serif">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl text-emerald-100 mb-8 leading-relaxed">
            Join thousands of learners who have transformed their relationship with nature and sustainability through our programs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-white text-emerald-900 px-8 py-4 rounded-xl font-bold hover:bg-emerald-50 transition-all shadow-xl"
            >
              Enroll in a Program
            </button>
            <button 
              onClick={() => window.location.href = 'mailto:ecovigyan@gmail.com'}
              className="bg-emerald-700 text-white px-8 py-4 rounded-xl font-bold hover:bg-emerald-600 transition-all border-2 border-emerald-500 flex items-center gap-2"
            >
              <Mail className="w-5 h-5" />
              <span>Contact Us</span>
            </button>
          </div>
        </div>
      </section>

      {/* Single Modal with Transitioning Content */}
      {selectedProgram && (
        <ProgramModal
          program={selectedProgram}
          modalView={modalView}
          formData={formData}
          isSubmitting={isSubmitting}
          onClose={handleCloseModal}
          onEnrollClick={handleEnrollClick}
          onBackToDetails={handleBackToDetails}
          onSubmit={handleSubmit}
          onChange={handleChange}
        />
      )}
      
      <Footer />
    </div>
  );
}