import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FileText, Calendar, User, Edit, Trash2, Plus, BookOpen, ChevronLeft, ChevronRight } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Link } from 'react-router';
import { useAuth } from './contexts/AuthContext';
import { ArticleCreateModal, ArticleFormData } from './components/ArticleCreateModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';

const ARTICLES_STORAGE_KEY = 'ecovigyan_articles';
const ARTICLES_PER_PAGE = 5;

export interface Article {
  id: string;
  title: string;
  content: string;
  images: string[];
  author: string;
  authorRole: string;
  publishedDate: string;
}

const defaultArticles: Article[] = [
  {
    id: '1',
    title: 'The Hidden World of Himalayan Fungi: Nature\'s Recyclers',
    content: 'In the dense forests of Himachal Pradesh, beneath the carpet of fallen leaves and decaying wood, exists a fascinating world that most hikers never notice. Fungi, the silent workers of the forest ecosystem, play a crucial role in breaking down organic matter and recycling nutrients back into the soil.\n\nDuring our recent mushroom documentation project in Shimla district, we discovered over 45 different species of macrofungi, each serving unique ecological functions. From the vibrant orange Chicken of the Woods (Laetiporus sulphureus) growing on oak trees to the delicate Ghost Fungus (Omphalotus nidiformis) glowing softly in the dark, these organisms are essential indicators of forest health.\n\nWhat makes fungi particularly fascinating is their symbiotic relationships with trees. Mycorrhizal fungi form networks with tree roots, extending far beyond the tree\'s reach and helping it absorb water and nutrients. In return, the tree provides sugars produced through photosynthesis. This underground network, sometimes called the "Wood Wide Web," connects entire forests in a complex communication system.\n\nOur students from various eco-clubs have been instrumental in documenting these species through photography and careful observation. They\'ve learned that fungi are neither plants nor animals but belong to their own kingdom, playing an irreplaceable role in maintaining ecological balance.\n\nAs climate change affects the Himalayan ecosystem, monitoring fungal diversity becomes increasingly important. Changes in temperature and precipitation patterns directly impact fungal fruiting patterns, making them excellent bioindicators of environmental change.',
    images: [
      'https://images.unsplash.com/photo-1542601098-3adb3b87e4c4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNocm9vbXMlMjBmb3Jlc3QlMjBoaW1hbGF5YXxlbnwxfHx8fDE3NzI0Njk0NDl8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1594735751939-1a8f8c36f4e0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdW5naSUyMG5hdHVyZSUyMGNsb3NldXB8ZW58MXx8fHwxNzcyNDY5NDUwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    ],
    author: 'Dr. Rajesh Kumar',
    authorRole: 'Mycologist',
    publishedDate: '2024-02-15'
  },
  {
    id: '2',
    title: 'Chemical-Free Living: A Student\'s Journey to Sustainability',
    content: 'When we started the Chemical Free Living Series at our school, I never imagined how much it would change my perspective on everyday products. As a 10th-grade student, I used to think sustainability was something only adults needed to worry about. How wrong I was!\n\nOur first workshop focused on understanding the chemicals in common household products – from detergents to cosmetics. We learned that many of these products contain harmful substances that eventually make their way into our water systems and soil. The scary part? These chemicals don\'t just disappear; they bioaccumulate in the food chain.\n\nThe real transformation came when we started making our own alternatives. Our team learned to create:\n\n1. Natural cleaning solutions using vinegar, baking soda, and essential oils\n2. Herbal pest repellents from neem and tulsi leaves\n3. Organic compost from kitchen waste\n4. Natural skincare products using honey, turmeric, and aloe vera\n\nWhat surprised me most was how effective these natural alternatives were. Our homemade all-purpose cleaner worked just as well as commercial products, cost almost nothing to make, and didn\'t harm the environment.\n\nWe also started a school-wide initiative to eliminate single-use plastics and chemical pesticides from our campus. Within three months, we reduced our plastic waste by 60% and created a thriving organic garden using only natural fertilizers and pest control methods.\n\nThe most rewarding part has been teaching our families. My mother now uses the natural cleaning products we make, and our neighborhood aunties regularly ask for our recipes. Small changes, when adopted by many people, create significant impact.\n\nThis journey taught me that sustainability isn\'t about perfection – it\'s about making conscious choices every day. Each chemical-free product we use is a vote for a healthier planet.',
    images: [
      'https://images.unsplash.com/photo-1556911220-bff31c812dba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwY2xlYW5pbmclMjBwcm9kdWN0c3xlbnwxfHx8fDE3NzI0Njk0NTB8MA&ixlib=rb-4.1.0&q=80&w=1080'
    ],
    author: 'Priya Sharma',
    authorRole: 'Student Leader',
    publishedDate: '2024-03-01'
  },
  {
    id: '3',
    title: 'Transforming School Waste: Our Zero-Waste Journey',
    content: 'Every day, our school of 800 students generated approximately 50 kilograms of waste. Most of it ended up in landfills, contributing to environmental degradation. That\'s when our eco-club decided to tackle this problem head-on through the Mastering Solid Waste Management program.\n\nPhase 1: Understanding the Problem\nWe conducted a week-long waste audit, categorizing everything our school discarded. The results were eye-opening:\n- 35% organic waste (food scraps, garden waste)\n- 30% paper and cardboard\n- 20% plastic packaging\n- 10% metal and glass\n- 5% other materials\n\nPhase 2: Implementing Solutions\nBased on our findings, we designed a comprehensive waste management system:\n\nComposting Station: We built three large composting bins using recycled wood pallets. All organic waste from the cafeteria and gardens now goes into these bins, producing nutrient-rich compost for our school garden within 2-3 months.\n\nPaper Recycling Program: We partnered with a local recycling facility and set up collection boxes in every classroom. Students learned to separate white paper from colored paper and cardboard.\n\nPlastic Reduction Campaign: We banned single-use plastics on campus and introduced reusable steel water bottles for all students. The school installed water purification stations to eliminate the need for bottled water.\n\nE-Waste Collection: We created a designated area for electronic waste and organized quarterly e-waste drives where students could bring items from home.\n\nPhase 3: Education and Engagement\nWe didn\'t stop at infrastructure. Every new student receives a orientation on waste segregation, and we run monthly workshops on creative reuse projects. Students have made:\n- Pen holders from plastic bottles\n- Bags from old newspapers\n- Decorative items from bottle caps\n- Planters from discarded containers\n\nThe Results:\nSix months into the program:\n- 70% reduction in waste sent to landfills\n- 200 kg of compost produced and used in our garden\n- 150 kg of paper recycled\n- Zero single-use plastics on campus\n- 25 student waste management ambassadors trained\n\nThis project taught us that waste is not the problem – poor management is. Everything has value if we look at it differently. What we once called "waste" is now "resource."',
    images: [
      'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWN5Y2xpbmclMjBzY2hvb2wlMjBzdHVkZW50c3xlbnwxfHx8fDE3NzI0Njk0NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wb3N0JTIwZ2FyZGVuaW5nfGVufDF8fHx8MTc3MjQ2OTQ1MXww&ixlib=rb-4.1.0&q=80&w=1080'
    ],
    author: 'Arun Mehta',
    authorRole: 'Program Coordinator',
    publishedDate: '2024-01-20'
  }
];

export default function Articles() {
  const { user, isAuthenticated } = useAuth();
  const [articles, setArticles] = useState<Article[]>(defaultArticles);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [deleteArticle, setDeleteArticle] = useState<Article | null>(null);
  const [currentPage, setCurrentPage] = useState(1);

  const canManageArticles = user?.role === 'writer' || user?.role === 'admin';

  // Load articles from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(ARTICLES_STORAGE_KEY);
    if (stored) {
      try {
        const parsedArticles = JSON.parse(stored);
        setArticles(parsedArticles.length > 0 ? parsedArticles : defaultArticles);
      } catch {
        setArticles(defaultArticles);
      }
    } else {
      localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(defaultArticles));
    }
  }, []);

  // Pagination
  const totalPages = Math.ceil(articles.length / ARTICLES_PER_PAGE);
  const startIndex = (currentPage - 1) * ARTICLES_PER_PAGE;
  const paginatedArticles = articles.slice(startIndex, startIndex + ARTICLES_PER_PAGE);

  const handleSubmit = (formData: ArticleFormData) => {
    if (editingArticle) {
      // Update existing article
      const updated = articles.map(art =>
        art.id === editingArticle.id
          ? { ...art, ...formData }
          : art
      );
      setArticles(updated);
      localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(updated));
      setEditingArticle(null);
    } else {
      // Create new article
      const newArticle: Article = {
        id: Date.now().toString(),
        ...formData,
        author: user?.name || 'Anonymous',
        authorRole: user?.role === 'admin' ? 'Administrator' : 'Writer',
        publishedDate: new Date().toISOString().split('T')[0]
      };
      const updated = [newArticle, ...articles];
      setArticles(updated);
      localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(updated));
    }
    setIsCreateModalOpen(false);
  };

  const handleEdit = (article: Article) => {
    setEditingArticle(article);
    setIsCreateModalOpen(true);
  };

  const truncateContent = (content: string, maxLength: number = 250) => {
    if (content.length <= maxLength) return content;
    return content.slice(0, maxLength) + '...';
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-br from-emerald-700 to-emerald-900 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-96 h-96 border-2 border-white rounded-full" />
          <div className="absolute bottom-10 right-10 w-64 h-64 border-2 border-white rounded-full" />
          <div className="absolute top-1/2 left-1/2 w-80 h-80 border border-white rounded-full" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-white/90 text-sm font-medium mb-6">
              <BookOpen className="w-4 h-4" />
              <span>Environmental Insights</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 font-serif">
              ARTICLES & STORIES
            </h1>
            <p className="text-xl md:text-2xl text-emerald-50 max-w-4xl mx-auto leading-relaxed mb-8">
              Explore our collection of environmental research, student experiences, and conservation stories from the field.
            </p>

            {/* Writer/Admin Create Button */}
            {canManageArticles && (
              <button
                onClick={() => {
                  setEditingArticle(null);
                  setIsCreateModalOpen(true);
                }}
                className="inline-flex items-center gap-2 bg-white text-emerald-900 px-8 py-4 rounded-xl font-bold hover:bg-emerald-50 transition-all shadow-xl"
              >
                <Plus className="w-5 h-5" />
                Write New Article
              </button>
            )}
          </motion.div>
        </div>
      </section>

      {/* Articles List */}
      <section className="py-20 bg-gradient-to-b from-white to-emerald-50/30">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8">
            {paginatedArticles.map((article, index) => (
              <motion.article
                key={article.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="bg-white rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border border-emerald-100"
              >
                <div className="md:flex">
                  {/* Article Image */}
                  {article.images.length > 0 && (
                    <div className="md:w-2/5 relative">
                      <img
                        src={article.images[0]}
                        alt={article.title}
                        className="w-full h-64 md:h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                    </div>
                  )}

                  {/* Article Content */}
                  <div className={`${article.images.length > 0 ? 'md:w-3/5' : 'w-full'} p-8`}>
                    {/* Meta Info */}
                    <div className="flex items-center gap-4 mb-4 text-sm text-emerald-600">
                      <div className="flex items-center gap-1.5">
                        <User className="w-4 h-4" />
                        <span>{article.author}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(article.publishedDate).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                      </div>
                    </div>

                    {/* Title */}
                    <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4 font-serif hover:text-emerald-700 transition-colors">
                      <Link to={`/articles/${article.id}`}>
                        {article.title}
                      </Link>
                    </h2>

                    {/* Excerpt */}
                    <p className="text-gray-700 leading-relaxed mb-6">
                      {truncateContent(article.content)}
                    </p>

                    {/* Actions */}
                    <div className="flex items-center justify-between">
                      <Link
                        to={`/articles/${article.id}`}
                        className="inline-flex items-center gap-2 text-emerald-600 font-semibold hover:text-emerald-700 transition-colors"
                      >
                        Read Full Article
                        <ChevronRight className="w-4 h-4" />
                      </Link>

                      {/* Writer/Admin Actions */}
                      {canManageArticles && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleEdit(article)}
                            className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center hover:bg-blue-700 transition-colors"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteArticle(article)}
                            className="w-10 h-10 rounded-full bg-red-600 text-white flex items-center justify-center hover:bg-red-700 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-12 flex items-center justify-center gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="w-10 h-10 rounded-full bg-white border-2 border-emerald-300 text-emerald-700 flex items-center justify-center hover:bg-emerald-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`w-10 h-10 rounded-full font-semibold transition-colors ${
                    currentPage === page
                      ? 'bg-emerald-600 text-white'
                      : 'bg-white border-2 border-emerald-300 text-emerald-700 hover:bg-emerald-50'
                  }`}
                >
                  {page}
                </button>
              ))}

              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="w-10 h-10 rounded-full bg-white border-2 border-emerald-300 text-emerald-700 flex items-center justify-center hover:bg-emerald-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}

          {articles.length === 0 && (
            <div className="text-center py-20">
              <FileText className="w-16 h-16 text-emerald-300 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-2">No articles yet</h3>
              <p className="text-gray-600 mb-6">Be the first to share your environmental story!</p>
              {canManageArticles && (
                <button
                  onClick={() => setIsCreateModalOpen(true)}
                  className="inline-flex items-center gap-2 bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all"
                >
                  <Plus className="w-5 h-5" />
                  Write First Article
                </button>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Create/Edit Modal */}
      <ArticleCreateModal
        isOpen={isCreateModalOpen}
        onClose={() => {
          setIsCreateModalOpen(false);
          setEditingArticle(null);
        }}
        onSubmit={handleSubmit}
        editData={editingArticle || undefined}
        isEditing={!!editingArticle}
      />

      {/* Delete Confirm Modal */}
      <DeleteConfirmModal
        isOpen={!!deleteArticle}
        onClose={() => setDeleteArticle(null)}
        onConfirm={() => {
          if (deleteArticle) {
            const updated = articles.filter(art => art.id !== deleteArticle.id);
            setArticles(updated);
            localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(updated));
            // Adjust current page if needed
            if (updated.length <= (currentPage - 1) * ARTICLES_PER_PAGE && currentPage > 1) {
              setCurrentPage(currentPage - 1);
            }
          }
          setDeleteArticle(null);
        }}
        title={deleteArticle?.title || ''}
        itemName={`By ${deleteArticle?.author}`}
      />

      <Footer />
    </div>
  );
}