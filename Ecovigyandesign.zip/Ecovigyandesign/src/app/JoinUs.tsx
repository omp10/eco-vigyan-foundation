import React from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { motion } from 'motion/react';
import { Users, GraduationCap, Microscope, ArrowRight, Heart, Calendar, MapPin, Clock, CheckCircle, Sparkles, X } from 'lucide-react';
import { Link } from 'react-router';

export default function JoinUs() {
  const [showVolunteerForm, setShowVolunteerForm] = React.useState(false);
  const [showInternshipForm, setShowInternshipForm] = React.useState(false);
  const [showCitizenForm, setShowCitizenForm] = React.useState(false);
  const [formData, setFormData] = React.useState({
    fullName: '',
    email: '',
    phone: '',
    primaryInterest: '',
    message: ''
  });
  const [internshipData, setInternshipData] = React.useState({
    fullName: '',
    email: '',
    phone: '',
    currentStatus: '',
    duration: '',
    primaryInterest: '',
    message: ''
  });
  const [citizenData, setCitizenData] = React.useState({
    fullName: '',
    email: '',
    phone: '',
    cityRegion: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [submitSuccess, setSubmitSuccess] = React.useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleInternshipChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setInternshipData(prev => ({ ...prev, [name]: value }));
  };

  const handleCitizenChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setCitizenData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Create mailto link with form data
    const subject = encodeURIComponent('Volunteer Application - Eco Vigyan Foundation');
    const body = encodeURIComponent(
      `Volunteer Application Details:\n\n` +
      `Name: ${formData.fullName}\n` +
      `Email: ${formData.email}\n` +
      `Phone: ${formData.phone}\n` +
      `Primary Interest: ${formData.primaryInterest || 'Not specified'}\n\n` +
      `Availability/Message:\n${formData.message || 'Not provided'}`
    );
    
    // Open email client
    window.location.href = `mailto:ecovigyan@gmail.com?subject=${subject}&body=${body}`;
    
    // Show success message
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      
      // Reset form after 3 seconds and close modal
      setTimeout(() => {
        setShowVolunteerForm(false);
        setSubmitSuccess(false);
        setFormData({
          fullName: '',
          email: '',
          phone: '',
          primaryInterest: '',
          message: ''
        });
      }, 3000);
    }, 500);
  };

  const handleInternshipSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Create mailto link with internship data
    const subject = encodeURIComponent('Internship Application - Eco Vigyan Foundation');
    const body = encodeURIComponent(
      `Internship Application Details:\n\n` +
      `Name: ${internshipData.fullName}\n` +
      `Email: ${internshipData.email}\n` +
      `Phone: ${internshipData.phone}\n` +
      `Current Status: ${internshipData.currentStatus || 'Not specified'}\n` +
      `Duration (Weeks): ${internshipData.duration || 'Not specified'}\n` +
      `Primary Interest: ${internshipData.primaryInterest || 'Not specified'}\n\n` +
      `Availability/Message:\n${internshipData.message || 'Not provided'}`
    );
    
    // Open email client
    window.location.href = `mailto:ecovigyan@gmail.com?subject=${subject}&body=${body}`;
    
    // Show success message
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      
      // Reset form after 3 seconds and close modal
      setTimeout(() => {
        setShowInternshipForm(false);
        setSubmitSuccess(false);
        setInternshipData({
          fullName: '',
          email: '',
          phone: '',
          currentStatus: '',
          duration: '',
          primaryInterest: '',
          message: ''
        });
      }, 3000);
    }, 500);
  };

  const handleCitizenSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Create mailto link with citizen data
    const subject = encodeURIComponent('Citizen Science Program Application - Eco Vigyan Foundation');
    const body = encodeURIComponent(
      `Citizen Science Program Application Details:\n\n` +
      `Name: ${citizenData.fullName}\n` +
      `Email: ${citizenData.email}\n` +
      `Phone: ${citizenData.phone}\n` +
      `City/Region: ${citizenData.cityRegion || 'Not specified'}\n\n` +
      `Availability/Message:\n${citizenData.message || 'Not provided'}`
    );
    
    // Open email client
    window.location.href = `mailto:ecovigyan@gmail.com?subject=${subject}&body=${body}`;
    
    // Show success message
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      
      // Reset form after 3 seconds and close modal
      setTimeout(() => {
        setShowCitizenForm(false);
        setSubmitSuccess(false);
        setCitizenData({
          fullName: '',
          email: '',
          phone: '',
          cityRegion: '',
          message: ''
        });
      }, 3000);
    }, 500);
  };

  const opportunities = [
    {
      id: 'volunteer',
      title: 'Volunteer with Us',
      subtitle: 'Support environmental education, field activities, and community learning.',
      icon: Users,
      gradient: 'from-emerald-500 to-teal-600',
      description: 'Volunteers work closely with our team during nature walks, school programs, biodiversity surveys, and outreach. No prior expertise needed.',
      activities: [
        'Nature Walks & Field Activities',
        'School Programs',
        'Workshops & Outreach',
        'Biodiversity Surveys'
      ],
      commitment: 'Flexible hours, 4-8 hours per week',
      cta: 'Volunteer with Eco Vigyan',
      ctaLink: 'mailto:ecovigyan@gmail.com?subject=Volunteer%20Application'
    },
    {
      id: 'internship',
      title: 'Internship with Us',
      subtitle: 'Learn by doing. Contribute to real ecological work.',
      icon: GraduationCap,
      gradient: 'from-blue-500 to-indigo-600',
      description: 'Designed for students and early-career professionals wanting hands-on exposure to fungal biodiversity, citizen science, and conservation education.',
      activities: [
        'Fungal Biodiversity Research',
        'Environmental Education',
        'Data & Technology',
        'Storytelling & Content'
      ],
      commitment: '3-6 months, 20-25 hours per week',
      cta: 'Apply for Internship',
      ctaLink: 'mailto:ecovigyan@gmail.com?subject=Internship%20Application'
    },
    {
      id: 'scientist',
      title: 'Be an Eco वैज्ञानिक',
      subtitle: 'Explore mushrooms around you. Map India\'s fungal diversity.',
      icon: Microscope,
      gradient: 'from-amber-500 to-orange-600',
      description: 'Join our Citizen Science program focused on fungi. Learn to document local biodiversity and help build regional mushroom trails and fungi maps.',
      activities: [
        'Mushroom Observation',
        'Responsible Photography',
        'Mapping Biodiversity',
        'Guided Learning Sessions'
      ],
      commitment: 'Self-paced, contribute anytime',
      cta: 'Be an Eco वैज्ञानिक',
      ctaLink: 'mailto:ecovigyan@gmail.com?subject=Citizen%20Science%20Program'
    }
  ];

  return (
    <div className="min-h-screen bg-[#F9FAF8] font-sans">
      <Navbar />
      
      <main>
        {/* Hero Section */}
        <section className="pt-32 pb-20 px-4 bg-gradient-to-b from-teal-800 to-teal-900 text-white relative overflow-hidden">
          <div className="max-w-5xl mx-auto text-center relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-teal-700/50 text-white text-sm font-semibold mb-6"
            >
              <Sparkles className="w-4 h-4" />
              Join Our Community
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-5xl md:text-6xl font-bold font-serif mb-6"
            >
              Join Us in Building a Greener Future
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl text-white/90 max-w-3xl mx-auto leading-relaxed"
            >
              Whether you're a student, professional, or nature enthusiast, there's a place for you at Eco Vigyan Foundation. Choose how you'd like to contribute to environmental conservation.
            </motion.p>
          </div>
        </section>

        {/* Opportunities Grid */}
        <section className="py-24 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-8">
              {opportunities.map((opportunity, index) => (
                <motion.div
                  key={opportunity.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden group hover:shadow-2xl transition-all duration-300"
                >
                  {/* Card Header */}
                  <div className={`bg-gradient-to-br ${opportunity.gradient} p-8 text-white relative overflow-hidden`}>
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16" />
                    <opportunity.icon className="w-12 h-12 mb-4 relative z-10" />
                    <h3 className="text-2xl font-bold mb-2 relative z-10">{opportunity.title}</h3>
                    <p className="text-white/90 text-sm relative z-10 leading-relaxed">{opportunity.subtitle}</p>
                  </div>

                  {/* Card Body */}
                  <div className="p-8">
                    <p className="text-gray-600 mb-6 leading-relaxed">
                      {opportunity.description}
                    </p>

                    <div className="mb-6">
                      <h4 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-emerald-600" />
                        Key Activities
                      </h4>
                      <ul className="space-y-2">
                        {opportunity.activities.map((activity, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-gray-600">
                            <span className="text-emerald-600 mt-1">•</span>
                            <span>{activity}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex items-center gap-2 text-sm text-gray-500 mb-6 pb-6 border-b border-gray-100">
                      <Clock className="w-4 h-4" />
                      <span>{opportunity.commitment}</span>
                    </div>

                    {opportunity.id === 'volunteer' ? (
                      <button
                        onClick={() => setShowVolunteerForm(true)}
                        className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 text-white font-bold py-4 px-6 rounded-xl hover:from-emerald-700 hover:to-emerald-800 transition-all flex items-center justify-center gap-2 group-hover:scale-105"
                      >
                        {opportunity.cta}
                        <ArrowRight className="w-5 h-5" />
                      </button>
                    ) : opportunity.id === 'internship' ? (
                      <button
                        onClick={() => setShowInternshipForm(true)}
                        className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 text-white font-bold py-4 px-6 rounded-xl hover:from-emerald-700 hover:to-emerald-800 transition-all flex items-center justify-center gap-2 group-hover:scale-105"
                      >
                        {opportunity.cta}
                        <ArrowRight className="w-5 h-5" />
                      </button>
                    ) : opportunity.id === 'scientist' ? (
                      <button
                        onClick={() => setShowCitizenForm(true)}
                        className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 text-white font-bold py-4 px-6 rounded-xl hover:from-emerald-700 hover:to-emerald-800 transition-all flex items-center justify-center gap-2 group-hover:scale-105"
                      >
                        {opportunity.cta}
                        <ArrowRight className="w-5 h-5" />
                      </button>
                    ) : (
                      <a 
                        href={opportunity.ctaLink}
                        className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 text-white font-bold py-4 px-6 rounded-xl hover:from-emerald-700 hover:to-emerald-800 transition-all flex items-center justify-center gap-2 group-hover:scale-105"
                      >
                        {opportunity.cta}
                        <ArrowRight className="w-5 h-5" />
                      </a>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Why Join Section */}
        <section className="py-24 px-4 bg-gradient-to-br from-emerald-50 via-white to-amber-50/30">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-4xl md:text-5xl font-bold font-serif text-emerald-950 mb-4"
              >
                Why Join Eco Vigyan?
              </motion.h2>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="text-xl text-gray-600 max-w-3xl mx-auto"
              >
                Be part of a passionate community working towards environmental conservation
              </motion.p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {[
                {
                  title: 'Real-World Impact',
                  description: 'Work on actual conservation projects that make a tangible difference in local communities and ecosystems.',
                  icon: Heart
                },
                {
                  title: 'Learn from Experts',
                  description: 'Collaborate with experienced researchers, mycologists, and environmental educators.',
                  icon: GraduationCap
                },
                {
                  title: 'Flexible Engagement',
                  description: 'Choose how and when you contribute, whether full-time, part-time, or on a project basis.',
                  icon: Calendar
                },
                {
                  title: 'Pan-India Network',
                  description: 'Connect with like-minded individuals across India working towards the same environmental goals.',
                  icon: MapPin
                }
              ].map((item, index) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow"
                >
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-100 to-emerald-200 flex items-center justify-center mb-4">
                    <item.icon className="w-7 h-7 text-emerald-700" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{item.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Support CTA */}
        <section className="py-24 px-4 bg-gradient-to-br from-amber-50 to-orange-50">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center mx-auto mb-6">
                <Heart className="w-10 h-10 text-white" />
              </div>
              
              <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-900 mb-6">
                Can't Volunteer? Support Us Instead
              </h2>
              
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Your financial contribution helps fund research equipment, field studies, educational materials, and conservation projects across India.
              </p>
              
              <Link to="/donate">
                <button className="bg-gradient-to-r from-amber-500 to-orange-600 text-white font-bold py-5 px-10 rounded-2xl text-lg hover:from-amber-600 hover:to-orange-700 transition-all inline-flex items-center gap-3 shadow-xl hover:scale-105">
                  Support Our Research
                  <Heart className="w-6 h-6" />
                </button>
              </Link>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Volunteer Form Modal */}
      {showVolunteerForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl relative max-h-[90vh] flex flex-col"
          >
            {/* Close Button */}
            <div className="sticky top-0 bg-white rounded-t-3xl z-10 flex justify-end p-6 pb-0">
              <button
                onClick={() => setShowVolunteerForm(false)}
                className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto px-8 pb-8 md:px-12 md:pb-12">
              {/* Header */}
              <div className="mb-8">
                <h2 className="text-3xl md:text-4xl font-bold text-teal-900 mb-3">
                  VOLUNTEER WITH US
                </h2>
                {!submitSuccess && (
                  <p className="text-gray-600 text-lg">
                    Please fill out the details below and our team will get back to you shortly.
                  </p>
                )}
              </div>

              {submitSuccess ? (
                <div className="py-12 text-center">
                  <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="w-10 h-10 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">Application Submitted!</h3>
                  <p className="text-gray-600">Thank you for your interest. We'll get back to you soon.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Name and Email Row */}
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="fullName" className="block text-sm font-bold text-teal-900 mb-2">
                        FULL NAME <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        id="fullName"
                        name="fullName"
                        required
                        value={formData.fullName}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-bold text-teal-900 mb-2">
                        EMAIL ADDRESS <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      />
                    </div>
                  </div>

                  {/* Phone Number */}
                  <div>
                    <label htmlFor="phone" className="block text-sm font-bold text-teal-900 mb-2">
                      PHONE NUMBER <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      required
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    />
                  </div>

                  {/* Primary Interest */}
                  <div>
                    <label htmlFor="primaryInterest" className="block text-sm font-bold text-teal-900 mb-2">
                      PRIMARY INTEREST
                    </label>
                    <select
                      id="primaryInterest"
                      name="primaryInterest"
                      value={formData.primaryInterest}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all bg-white"
                    >
                      <option value="">Select your primary interest</option>
                      <option value="Nature Walks & Field Activities">Nature Walks & Field Activities</option>
                      <option value="School Programs">School Programs</option>
                      <option value="Workshops & Outreach">Workshops & Outreach</option>
                      <option value="Biodiversity Surveys">Biodiversity Surveys</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  {/* Availability / Message */}
                  <div>
                    <label htmlFor="message" className="block text-sm font-bold text-teal-900 mb-2">
                      TELL US ABOUT YOUR AVAILABILITY & WHY YOU'D LIKE TO JOIN
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={5}
                      value={formData.message}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 text-white font-bold py-4 px-6 rounded-xl hover:from-emerald-700 hover:to-emerald-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-lg"
                  >
                    {isSubmitting ? 'Submitting...' : 'Submit Application'}
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      )}

      {/* Internship Form Modal */}
      {showInternshipForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl relative max-h-[90vh] flex flex-col"
          >
            {/* Close Button */}
            <div className="sticky top-0 bg-white rounded-t-3xl z-10 flex justify-end p-6 pb-0">
              <button
                onClick={() => setShowInternshipForm(false)}
                className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto px-8 pb-8 md:px-12 md:pb-12">
              {/* Header */}
              <div className="mb-8">
                <h2 className="text-3xl md:text-4xl font-bold text-teal-900 mb-3">
                  APPLY FOR INTERNSHIP
                </h2>
                {!submitSuccess && (
                  <p className="text-gray-600 text-lg">
                    Please fill out the details below and our team will get back to you shortly.
                  </p>
                )}
              </div>

              {submitSuccess ? (
                <div className="py-12 text-center">
                  <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="w-10 h-10 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">Application Submitted!</h3>
                  <p className="text-gray-600">Thank you for your interest. We'll get back to you soon.</p>
                </div>
              ) : (
                <form onSubmit={handleInternshipSubmit} className="space-y-6">
                  {/* Name and Email Row */}
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="fullName" className="block text-sm font-bold text-teal-900 mb-2">
                        FULL NAME <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        id="fullName"
                        name="fullName"
                        required
                        value={internshipData.fullName}
                        onChange={handleInternshipChange}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-bold text-teal-900 mb-2">
                        EMAIL ADDRESS <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        required
                        value={internshipData.email}
                        onChange={handleInternshipChange}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      />
                    </div>
                  </div>

                  {/* Phone Number */}
                  <div>
                    <label htmlFor="phone" className="block text-sm font-bold text-teal-900 mb-2">
                      PHONE NUMBER <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      required
                      value={internshipData.phone}
                      onChange={handleInternshipChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    />
                  </div>

                  {/* Current Status */}
                  <div>
                    <label htmlFor="currentStatus" className="block text-sm font-bold text-teal-900 mb-2">
                      CURRENT STATUS
                    </label>
                    <select
                      id="currentStatus"
                      name="currentStatus"
                      value={internshipData.currentStatus}
                      onChange={handleInternshipChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all bg-white"
                    >
                      <option value="">Select your current status</option>
                      <option value="Student">Student</option>
                      <option value="Early Career Professional">Early Career Professional</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  {/* Duration */}
                  <div>
                    <label htmlFor="duration" className="block text-sm font-bold text-teal-900 mb-2">
                      DURATION (WEEKS)
                    </label>
                    <input
                      type="number"
                      id="duration"
                      name="duration"
                      value={internshipData.duration}
                      onChange={handleInternshipChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    />
                  </div>

                  {/* Primary Interest */}
                  <div>
                    <label htmlFor="primaryInterest" className="block text-sm font-bold text-teal-900 mb-2">
                      PRIMARY INTEREST
                    </label>
                    <select
                      id="primaryInterest"
                      name="primaryInterest"
                      value={internshipData.primaryInterest}
                      onChange={handleInternshipChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all bg-white"
                    >
                      <option value="">Select your primary interest</option>
                      <option value="Fungal Biodiversity Research">Fungal Biodiversity Research</option>
                      <option value="Environmental Education">Environmental Education</option>
                      <option value="Data & Technology">Data & Technology</option>
                      <option value="Storytelling & Content">Storytelling & Content</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  {/* Availability / Message */}
                  <div>
                    <label htmlFor="message" className="block text-sm font-bold text-teal-900 mb-2">
                      TELL US ABOUT YOUR AVAILABILITY & WHY YOU'D LIKE TO JOIN
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={5}
                      value={internshipData.message}
                      onChange={handleInternshipChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 text-white font-bold py-4 px-6 rounded-xl hover:from-emerald-700 hover:to-emerald-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-lg"
                  >
                    {isSubmitting ? 'Submitting...' : 'Submit Application'}
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      )}

      {/* Citizen Form Modal */}
      {showCitizenForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl relative max-h-[90vh] flex flex-col"
          >
            {/* Close Button */}
            <div className="sticky top-0 bg-white rounded-t-3xl z-10 flex justify-end p-6 pb-0">
              <button
                onClick={() => setShowCitizenForm(false)}
                className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto px-8 pb-8 md:px-12 md:pb-12">
              {/* Header */}
              <div className="mb-8">
                <h2 className="text-2xl md:text-3xl font-bold text-teal-900 mb-3 break-words">
                  BE AN ECO वैज्ञानिक
                </h2>
                {!submitSuccess && (
                  <p className="text-gray-600 text-lg">
                    Please fill out the details below and our team will get back to you shortly.
                  </p>
                )}
              </div>

              {submitSuccess ? (
                <div className="py-12 text-center">
                  <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="w-10 h-10 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">Application Submitted!</h3>
                  <p className="text-gray-600">Thank you for your interest. We'll get back to you soon.</p>
                </div>
              ) : (
                <form onSubmit={handleCitizenSubmit} className="space-y-6">
                  {/* Name and Email Row */}
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="fullName" className="block text-sm font-bold text-teal-900 mb-2">
                        FULL NAME <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        id="fullName"
                        name="fullName"
                        required
                        value={citizenData.fullName}
                        onChange={handleCitizenChange}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-bold text-teal-900 mb-2">
                        EMAIL ADDRESS <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        required
                        value={citizenData.email}
                        onChange={handleCitizenChange}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      />
                    </div>
                  </div>

                  {/* Phone Number */}
                  <div>
                    <label htmlFor="phone" className="block text-sm font-bold text-teal-900 mb-2">
                      PHONE NUMBER <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      required
                      value={citizenData.phone}
                      onChange={handleCitizenChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    />
                  </div>

                  {/* City/Region */}
                  <div>
                    <label htmlFor="cityRegion" className="block text-sm font-bold text-teal-900 mb-2">
                      CITY/REGION
                    </label>
                    <input
                      type="text"
                      id="cityRegion"
                      name="cityRegion"
                      value={citizenData.cityRegion}
                      onChange={handleCitizenChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    />
                  </div>

                  {/* Availability / Message */}
                  <div>
                    <label htmlFor="message" className="block text-sm font-bold text-teal-900 mb-2">
                      TELL US ABOUT YOUR AVAILABILITY & WHY YOU'D LIKE TO JOIN
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={5}
                      value={citizenData.message}
                      onChange={handleCitizenChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 text-white font-bold py-4 px-6 rounded-xl hover:from-emerald-700 hover:to-emerald-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-lg"
                  >
                    {isSubmitting ? 'Submitting...' : 'Submit Application'}
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}