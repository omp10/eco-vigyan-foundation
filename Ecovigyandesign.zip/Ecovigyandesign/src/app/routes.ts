import { createBrowserRouter } from "react-router";
import { Layout } from "./Layout";
import Home from "./Home";
import Explore from "./Explore";
import MushroomHub from "./MushroomHub";
import Donate from "./Donate";
import JoinUs from "./JoinUs";
import Programs from "./Programs";
import ProgramEnrollment from "./ProgramEnrollment";
import Gallery from "./Gallery";
import Reports from "./Reports";
import Dashboard from "./Dashboard";
import ProfileSettings from "./ProfileSettings";
import UserSubmissions from "./UserSubmissions";
import ObservationDetail from "./ObservationDetail";
import Articles from "./Articles";
import ArticleDetail from "./ArticleDetail";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      {
        index: true,
        Component: Home,
      },
      {
        path: "explore",
        Component: Explore,
      },
      {
        path: "shroomhub",
        Component: MushroomHub,
      },
      {
        path: "shroomhub/observation/:observationId",
        Component: ObservationDetail,
      },
      {
        path: "contributor/:contributorName",
        Component: UserSubmissions,
      },
      {
        path: "donate",
        Component: Donate,
      },
      {
        path: "join-us",
        Component: JoinUs,
      },
      {
        path: "programs",
        Component: Programs,
      },
      {
        path: "enroll",
        Component: ProgramEnrollment,
      },
      {
        path: "gallery",
        Component: Gallery,
      },
      {
        path: "reports",
        Component: Reports,
      },
      {
        path: "articles",
        Component: Articles,
      },
      {
        path: "articles/:id",
        Component: ArticleDetail,
      },
      {
        path: "dashboard",
        Component: Dashboard,
      },
      {
        path: "profile-settings",
        Component: ProfileSettings,
      },
    ],
  },
]);