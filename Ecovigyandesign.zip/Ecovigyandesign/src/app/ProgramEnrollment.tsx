import React, { useState } from 'react';
import { ArrowLeft, Send } from 'lucide-react';
import { Link, useSearchParams } from 'react-router';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { useAuth } from './contexts/AuthContext';
import { LoginPrompt } from './components/LoginPrompt';

export default function ProgramEnrollment() {
  const [searchParams] = useSearchParams();
  const programName = searchParams.get('program') || 'Our Program';
  const { user, isAuthenticated } = useAuth();
  
  const [formData, setFormData] = useState({
    fullName: user?.name || '',
    email: user?.email || '',
    phone: '',
    school: '',
    grade: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Save to localStorage
    const enrollment = {
      id: `enrollment-${Date.now()}`,
      userId: user?.id,
      programId: programName,
      programTitle: programName,
      studentName: formData.fullName,
      email: formData.email,
      phone: formData.phone,
      school: formData.school,
      grade: formData.grade,
      message: formData.message,
      status: 'pending',
      submittedAt: new Date().toISOString()
    };

    const existingEnrollments = JSON.parse(localStorage.getItem('ecovigyan_enrollments') || '[]');
    localStorage.setItem('ecovigyan_enrollments', JSON.stringify([...existingEnrollments, enrollment]));
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setIsSubmitted(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
        <Navbar />
        <div className="pt-32 pb-20 px-4">
          <div className="max-w-2xl mx-auto text-center">
            <div className="bg-white rounded-3xl shadow-xl p-12">
              <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-10 h-10 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4 font-serif">
                Registration Successful!
              </h2>
              <p className="text-gray-600 mb-8 leading-relaxed">
                Thank you for registering for <strong>{programName}</strong>. We'll contact you shortly with further details.
              </p>
              <Link to="/programs">
                <button className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-8 py-4 rounded-xl font-bold hover:from-emerald-700 hover:to-teal-700 transition-all shadow-lg">
                  Back to Programs
                </button>
              </Link>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
      <Navbar />
      
      <div className="pt-32 pb-20 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <Link 
            to="/programs"
            className="inline-flex items-center gap-2 text-emerald-700 hover:text-emerald-800 font-semibold mb-8 group"
          >
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span>Back to Programs</span>
          </Link>

          {/* Show login prompt if not authenticated */}
          {!isAuthenticated ? (
            <div className="mb-12">
              <LoginPrompt 
                title="Login to Enroll"
                feature={`enroll in ${programName}`}
                message="Create a free account to enroll in programs, track your progress, and unlock certificates."
              />
            </div>
          ) : (
            <>
              {/* Registration Form */}
              <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
                {/* Header */}
                <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-12 text-center">
                  <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 uppercase tracking-wide">
                    PROGRAM REGISTRATION
                  </h1>
                  <p className="text-xl text-emerald-50 font-medium">
                    {programName}
                  </p>
                </div>

                {/* Form */}
                <form onSubmit={handleSubmit} className="p-8 md:p-12">
                  {/* Full Name */}
                  <div className="mb-8">
                    <label htmlFor="fullName" className="block text-gray-900 font-bold mb-3 uppercase tracking-wide text-sm">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="fullName"
                      name="fullName"
                      required
                      value={formData.fullName}
                      onChange={handleChange}
                      placeholder="Enter your full name"
                      className="w-full px-6 py-4 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition-all outline-none text-gray-900 placeholder-gray-400"
                    />
                  </div>

                  {/* Email */}
                  <div className="mb-8">
                    <label htmlFor="email" className="block text-gray-900 font-bold mb-3 uppercase tracking-wide text-sm">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="your.email@example.com"
                      className="w-full px-6 py-4 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition-all outline-none text-gray-900 placeholder-gray-400"
                    />
                  </div>

                  {/* Phone Number */}
                  <div className="mb-8">
                    <label htmlFor="phone" className="block text-gray-900 font-bold mb-3 uppercase tracking-wide text-sm">
                      Phone Number <span className="text-red-500">*</span> (Indian)
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      required
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="+91 9876543210 or 9876543210"
                      className="w-full px-6 py-4 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition-all outline-none text-gray-900 placeholder-gray-400"
                    />
                  </div>

                  {/* School */}
                  <div className="mb-8">
                    <label htmlFor="school" className="block text-gray-900 font-bold mb-3 uppercase tracking-wide text-sm">
                      School <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="school"
                      name="school"
                      required
                      value={formData.school}
                      onChange={handleChange}
                      placeholder="Enter your school name"
                      className="w-full px-6 py-4 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition-all outline-none text-gray-900 placeholder-gray-400"
                    />
                  </div>

                  {/* Grade */}
                  <div className="mb-8">
                    <label htmlFor="grade" className="block text-gray-900 font-bold mb-3 uppercase tracking-wide text-sm">
                      Grade <span className="text-red-500">*</span>
                    </label>
                    <select
                      id="grade"
                      name="grade"
                      required
                      value={formData.grade}
                      onChange={handleChange}
                      className="w-full px-6 py-4 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition-all outline-none text-gray-900 placeholder-gray-400"
                    >
                      <option value="">Select your grade</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7">7</option>
                      <option value="8">8</option>
                      <option value="9">9</option>
                      <option value="10">10</option>
                      <option value="11">11</option>
                      <option value="12">12</option>
                    </select>
                  </div>

                  {/* Additional Message */}
                  <div className="mb-10">
                    <label htmlFor="message" className="block text-gray-900 font-bold mb-3 uppercase tracking-wide text-sm">
                      Additional Message (Optional)
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={6}
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Any questions or special requirements?"
                      className="w-full px-6 py-4 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition-all outline-none text-gray-900 placeholder-gray-400 resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-8 py-5 rounded-xl font-bold hover:from-emerald-700 hover:to-teal-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3 text-lg uppercase tracking-wide"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Submitting...</span>
                      </>
                    ) : (
                      <>
                        <span>Submit Registration</span>
                        <Send className="w-5 h-5" />
                      </>
                    )}
                  </button>
                </form>
              </div>
            </>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}