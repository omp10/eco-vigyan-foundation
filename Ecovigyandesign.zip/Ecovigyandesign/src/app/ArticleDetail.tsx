import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Calendar, User, FileText, Tag } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Link, useParams, useNavigate } from 'react-router';
import { Article } from './Articles';

const ARTICLES_STORAGE_KEY = 'ecovigyan_articles';

export default function ArticleDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [article, setArticle] = useState<Article | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem(ARTICLES_STORAGE_KEY);
    if (stored) {
      try {
        const articles: Article[] = JSON.parse(stored);
        const found = articles.find(a => a.id === id);
        if (found) {
          setArticle(found);
        } else {
          navigate('/articles');
        }
      } catch {
        navigate('/articles');
      }
    } else {
      navigate('/articles');
    }
  }, [id, navigate]);

  if (!article) {
    return (
      <div className="min-h-screen bg-white">
        <Navbar />
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <FileText className="w-16 h-16 text-emerald-300 mx-auto mb-4" />
            <p className="text-gray-600">Loading article...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Article Header */}
      <article className="pt-32 pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Button */}
          <Link
            to="/articles"
            className="inline-flex items-center gap-2 text-emerald-600 hover:text-emerald-700 font-semibold mb-8 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Articles
          </Link>

          {/* Article Meta */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <div className="flex flex-wrap items-center gap-4 mb-6 text-emerald-600">
              <div className="flex items-center gap-2">
                <User className="w-5 h-5" />
                <span className="font-semibold">{article.author}</span>
                <span className="text-emerald-400">•</span>
                <span className="text-sm text-gray-600">{article.authorRole}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                <span>{new Date(article.publishedDate).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
              </div>
            </div>

            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 font-serif leading-tight">
              {article.title}
            </h1>
          </motion.div>

          {/* Article Images */}
          {article.images.length > 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className={`mb-12 ${article.images.length === 1 ? '' : 'grid md:grid-cols-2 gap-6'}`}
            >
              {article.images.map((image, index) => (
                <div key={index} className="rounded-2xl overflow-hidden border-4 border-emerald-100 shadow-lg">
                  <img
                    src={image}
                    alt={`${article.title} - Image ${index + 1}`}
                    className="w-full h-auto object-cover"
                  />
                </div>
              ))}
            </motion.div>
          )}

          {/* Article Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="prose prose-lg max-w-none"
          >
            {article.content.split('\n\n').map((paragraph, index) => (
              <p key={index} className="text-gray-700 leading-relaxed mb-6 text-lg">
                {paragraph}
              </p>
            ))}
          </motion.div>

          {/* Article Footer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="mt-12 pt-8 border-t-2 border-emerald-100"
          >
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-8">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white text-2xl font-bold shrink-0">
                  {article.author.charAt(0)}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{article.author}</h3>
                  <p className="text-emerald-700 font-semibold mb-2">{article.authorRole}</p>
                  <p className="text-gray-600 text-sm">
                    Contributing to environmental research and conservation education through the Eco Vigyan Foundation.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Navigation */}
          <div className="mt-12 flex justify-center">
            <Link
              to="/articles"
              className="inline-flex items-center gap-2 bg-emerald-600 text-white px-8 py-4 rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200"
            >
              <FileText className="w-5 h-5" />
              View All Articles
            </Link>
          </div>
        </div>
      </article>

      <Footer />
    </div>
  );
}