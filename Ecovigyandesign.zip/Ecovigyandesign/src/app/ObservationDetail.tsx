import React, { useRef, useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { ArrowLeft, Camera, MapPin, Globe, Navigation } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { MUSHROOM_DATA, CONTRIBUTORS } from './mushroom-data';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export default function ObservationDetail() {
  const { observationId } = useParams();
  const navigate = useNavigate();
  const mapRef = useRef(null);
  const [mapInstance, setMapInstance] = useState(null);

  // Find the observation
  const observation = MUSHROOM_DATA.find(obs => obs.id === observationId);
  
  // Find all observations of the same species
  const allSpeciesSightings = observation 
    ? MUSHROOM_DATA.filter(obs => obs.name === observation.name)
    : [];

  // Find the contributor
  const contributor = observation ? CONTRIBUTORS.find(c => {
    const obsContributor = observation.contributor.toLowerCase();
    const fullName = c.name.toLowerCase();
    const obsParts = obsContributor.split(' ').filter(p => p.length > 0);
    return obsParts.every(part => fullName.includes(part));
  }) : null;

  // Initialize map
  useEffect(() => {
    if (!observation || mapInstance || !mapRef.current || allSpeciesSightings.length === 0) return;

    // Calculate bounds for all sightings
    const bounds = L.latLngBounds(allSpeciesSightings.map(obs => [obs.lat, obs.lng]));

    const map = L.map(mapRef.current, {
      zoomControl: true,
      scrollWheelZoom: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    // Fit map to show all sightings
    if (allSpeciesSightings.length > 1) {
      map.fitBounds(bounds, { padding: [50, 50] });
    } else {
      map.setView([observation.lat, observation.lng], 10);
    }

    // Add markers for all sightings
    allSpeciesSightings.forEach((obs, index) => {
      const isCurrentObservation = obs.id === observation.id;
      
      const customIcon = L.divIcon({
        className: 'custom-marker',
        html: `
          <div style="
            background: ${isCurrentObservation ? '#059669' : '#10b981'};
            width: ${isCurrentObservation ? '40px' : '32px'};
            height: ${isCurrentObservation ? '40px' : '32px'};
            border-radius: 50% 50% 50% 0;
            transform: rotate(-45deg);
            border: ${isCurrentObservation ? '3px' : '2px'} solid white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            ${isCurrentObservation ? 'animation: pulse 2s ease-in-out infinite;' : ''}
          ">
            <div style="
              transform: rotate(45deg);
              color: white;
              font-size: ${isCurrentObservation ? '18px' : '14px'};
            ">${isCurrentObservation ? '📍' : '🍄'}</div>
          </div>
          ${isCurrentObservation ? `<style>
            @keyframes pulse {
              0%, 100% { transform: rotate(-45deg) scale(1); }
              50% { transform: rotate(-45deg) scale(1.1); }
            }
          </style>` : ''}
        `,
        iconSize: [isCurrentObservation ? 40 : 32, isCurrentObservation ? 40 : 32],
        iconAnchor: [isCurrentObservation ? 20 : 16, isCurrentObservation ? 40 : 32],
      });

      const marker = L.marker([obs.lat, obs.lng], { icon: customIcon }).addTo(map);
      
      // Add popup with observation details
      const popupContent = `
        <div style="font-family: system-ui, -apple-system, sans-serif; min-width: 200px;">
          <div style="font-weight: bold; font-size: 14px; color: #064e3b; margin-bottom: 4px;">
            ${obs.name}
          </div>
          <div style="font-size: 12px; color: #059669; margin-bottom: 8px;">
            ${obs.location}
          </div>
          <div style="font-size: 11px; color: #6b7280; margin-bottom: 4px;">
            📅 ${obs.date}
          </div>
          <div style="font-size: 11px; color: #6b7280; margin-bottom: 8px;">
            👤 ${obs.contributor}
          </div>
          ${!isCurrentObservation ? `
            <a href="/shroomhub/observation/${obs.id}" style="
              display: inline-block;
              background: #059669;
              color: white;
              padding: 6px 12px;
              border-radius: 8px;
              text-decoration: none;
              font-size: 11px;
              font-weight: bold;
              margin-top: 4px;
            ">View Details →</a>
          ` : '<div style="font-size: 11px; color: #059669; font-weight: bold;">📍 Current Observation</div>'}
        </div>
      `;
      
      marker.bindPopup(popupContent);
      
      // Open popup for current observation
      if (isCurrentObservation) {
        marker.openPopup();
      }
    });

    setMapInstance(map);

    return () => {
      map.remove();
    };
  }, [observation, allSpeciesSightings]);

  if (!observation) {
    return (
      <div className="min-h-screen bg-[#F9FAF8]">
        <Navbar />
        <main className="pt-32 pb-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl font-bold text-emerald-950 mb-4">Observation Not Found</h1>
            <Link to="/shroomhub" className="text-emerald-600 hover:text-emerald-700 font-semibold">
              ← Back to Mushroom Hub
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // Get technical details
  const getTechnicalDetails = () => {
    const details = [];
    
    // Underside
    if (observation.characteristics?.underside) {
      details.push({
        label: 'UNDERSIDE',
        value: observation.characteristics.underside,
        icon: '🍄'
      });
    }
    
    // Stem
    if (observation.characteristics?.stem) {
      details.push({
        label: 'STEM PRESENCE',
        value: observation.characteristics.stem,
        icon: '🌾'
      });
    }
    
    // Common uses
    if (observation.category) {
      details.push({
        label: 'COMMON USES',
        value: observation.category,
        icon: '🍽️'
      });
    }

    return details;
  };

  const technicalDetails = getTechnicalDetails();

  return (
    <div className="min-h-screen bg-[#F9FAF8]">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Button */}
          <Link 
            to="/shroomhub" 
            className="inline-flex items-center gap-2 text-emerald-600 hover:text-emerald-700 font-semibold mb-8 transition-colors"
          >
            <ArrowLeft size={20} />
            Back to gallery
          </Link>

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Left: Image */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative"
            >
              <div className="relative rounded-[48px] overflow-hidden bg-white shadow-2xl border-4 border-white">
                <ImageWithFallback 
                  src={observation.image} 
                  className="w-full aspect-[3/4] object-cover" 
                />
                <div className="absolute top-6 left-6">
                  <span className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest ${
                    observation.category === 'Toxic' ? 'bg-red-500' : 
                    observation.category === 'Medicinal' ? 'bg-purple-500' : 
                    'bg-emerald-500'
                  } text-white shadow-lg`}>
                    {observation.category}
                  </span>
                </div>
              </div>
            </motion.div>

            {/* Right: Details */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              {/* Header */}
              <div>
                <div className="flex items-center gap-2 text-emerald-600 font-bold text-sm uppercase tracking-wider mb-4">
                  <Camera size={16} />
                  Captured {observation.date}
                </div>
                <h1 className="text-5xl md:text-6xl font-bold font-serif text-emerald-950 mb-3">
                  {observation.name}
                </h1>
                {observation.scientificName && (
                  <p className="text-2xl text-emerald-700 italic font-serif">
                    {observation.scientificName}
                  </p>
                )}
              </div>

              {/* Ecological Role and Texture */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {observation.ecologicalRole && (
                  <div className="bg-white rounded-3xl p-6 border border-emerald-100 shadow-sm">
                    <div className="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-2">
                      Ecological Role
                    </div>
                    <div className="text-lg font-bold text-emerald-950">
                      {observation.ecologicalRole}
                    </div>
                  </div>
                )}
                {observation.texture && (
                  <div className="bg-white rounded-3xl p-6 border border-emerald-100 shadow-sm">
                    <div className="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-2">
                      Texture
                    </div>
                    <div className="text-lg font-bold text-emerald-950 flex items-center gap-2">
                      <span>🤚</span>
                      {observation.texture}
                    </div>
                  </div>
                )}
              </div>

              {/* Technical Summary */}
              {technicalDetails.length > 0 && (
                <div className="bg-white rounded-3xl p-8 border border-emerald-100 shadow-sm">
                  <h3 className="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-6">
                    Technical Summary
                  </h3>
                  <div className="space-y-5">
                    {technicalDetails.map((detail, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="text-xs font-bold text-emerald-950/40 uppercase tracking-wider">
                          {detail.label}
                        </div>
                        <div className="flex items-center gap-2 text-emerald-950 font-bold">
                          <span className="text-xl">{detail.icon}</span>
                          {detail.value}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Discovered By */}
              {contributor && (
                <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-3xl p-6 border border-emerald-100">
                  <div className="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-4">
                    Discovered By
                  </div>
                  <Link
                    to={`/user-submissions/${contributor.name.toLowerCase().replace(/\s+/g, '-')}`}
                    className="flex items-center gap-4 group"
                  >
                    <ImageWithFallback 
                      src={contributor.avatar} 
                      className="w-16 h-16 rounded-full object-cover border-2 border-white shadow-md" 
                    />
                    <div>
                      <div className="text-lg font-bold text-emerald-950 group-hover:text-emerald-600 transition-colors">
                        {contributor.name}
                      </div>
                      <div className="text-sm text-emerald-700">
                        {contributor.level}
                      </div>
                    </div>
                  </Link>
                </div>
              )}

              {/* Global Positioning */}
              <div className="bg-white rounded-3xl p-6 border border-emerald-100 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-600 uppercase tracking-wider">
                    <Globe size={16} />
                    Global Distribution
                  </div>
                  <div className="flex items-center gap-2 bg-emerald-50 px-3 py-1.5 rounded-full">
                    <Navigation size={14} className="text-emerald-600" />
                    <span className="text-xs font-bold text-emerald-950">
                      {allSpeciesSightings.length} {allSpeciesSightings.length === 1 ? 'Sighting' : 'Sightings'}
                    </span>
                  </div>
                </div>
                
                {allSpeciesSightings.length > 1 && (
                  <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-4 mb-4">
                    <div className="text-xs text-emerald-700 mb-2">
                      🌍 This species has been documented across multiple locations
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {allSpeciesSightings.slice(0, 5).map((obs, idx) => (
                        <Link
                          key={obs.id}
                          to={`/shroomhub/observation/${obs.id}`}
                          className={`text-xs px-3 py-1.5 rounded-full transition-all ${
                            obs.id === observation.id
                              ? 'bg-emerald-600 text-white font-bold'
                              : 'bg-white text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                          }`}
                        >
                          {obs.location.split(',')[0]}
                        </Link>
                      ))}
                      {allSpeciesSightings.length > 5 && (
                        <div className="text-xs px-3 py-1.5 rounded-full bg-emerald-100 text-emerald-700 font-bold">
                          +{allSpeciesSightings.length - 5} more
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                <div className="mb-4">
                  <div className="text-xs font-bold text-emerald-950/40 uppercase tracking-wider mb-2">
                    This Observation
                  </div>
                  <div className="text-sm font-bold text-emerald-950">
                    {observation.lat.toFixed(5)}° N, {observation.lng.toFixed(5)}° E
                  </div>
                  <div className="text-xs text-emerald-700 mt-1">
                    {observation.location}
                  </div>
                </div>
                
                <div className="text-xs text-emerald-600 mb-4 flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-emerald-600 animate-pulse"></div>
                  {allSpeciesSightings.length === 1 
                    ? 'Interactive map showing this location' 
                    : `Interactive map showing all ${allSpeciesSightings.length} recorded locations`}
                </div>
                
                <div 
                  ref={mapRef} 
                  className="w-full h-64 rounded-2xl overflow-hidden border-2 border-emerald-100"
                />
                
                {allSpeciesSightings.length > 1 && (
                  <div className="mt-4 flex items-start gap-2 text-xs text-emerald-700 bg-emerald-50/50 rounded-xl p-3">
                    <span className="text-base">💡</span>
                    <div>
                      <span className="font-bold">📍 Larger pin</span> = Current observation • 
                      <span className="font-bold ml-1">🍄 Smaller pins</span> = Other sightings (click to view)
                    </div>
                  </div>
                )}
              </div>

              {/* Location */}
              <div className="flex items-start gap-3 text-emerald-800">
                <MapPin size={20} className="text-emerald-600 shrink-0 mt-1" />
                <div>
                  <div className="font-bold text-emerald-950 mb-1">Location</div>
                  <div className="text-sm">{observation.location}</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}