import React from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { motion } from 'motion/react';
import { Search, Filter, BookOpen, Download, FileText, ChevronRight, BarChart3, Database } from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

export default function Explore() {
  const [activeTab, setActiveTab] = React.useState('publications');

  const publications = [
    {
      title: "Impact of Climate Change on Western Ghats Biodiversity",
      authors: "Dr. Anjali Sharma, et al.",
      date: "Oct 2025",
      category: "Research Paper",
      downloads: "1.2k"
    },
    {
      title: "Native Species Reforestation: A 10-Year Case Study",
      authors: "Vikram Mehta, Sarah Chen",
      date: "Aug 2025",
      category: "Case Study",
      downloads: "850"
    },
    {
      title: "Mapping Hornbill Nesting Sites in Eastern Himalayas",
      authors: "Dr. Sarah Chen",
      date: "June 2025",
      category: "Field Report",
      downloads: "2.4k"
    }
  ];

  const datasets = [
    {
      name: "Soil Carbon Database 2024",
      size: "240 MB",
      format: "CSV / JSON",
      lastUpdated: "Dec 2024"
    },
    {
      name: "Floral Taxonomy of Central India",
      size: "1.2 GB",
      format: "SQL / Parquet",
      lastUpdated: "Nov 2024"
    }
  ];

  return (
    <div className="min-h-screen bg-[#F9FAF8] selection:bg-emerald-200">
      <Navbar />
      
      <main className="pt-24 pb-16">
        {/* Header Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-emerald-900 rounded-[40px] p-8 md:p-16 text-white relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-1/3 h-full opacity-10 pointer-events-none">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1766297248160-87aca6fa59ef"
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="relative z-10 max-w-2xl">
              <h1 className="text-4xl md:text-6xl font-bold font-serif mb-6">Explore Our Research</h1>
              <p className="text-emerald-100/70 text-lg mb-8">
                Access over 15 years of ecological data, peer-reviewed publications, and field findings dedicated to preserving biodiversity.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-400 w-5 h-5" />
                  <input 
                    type="text" 
                    placeholder="Search research papers, datasets..."
                    className="w-full bg-white/10 border border-white/20 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:bg-white/20 transition-all"
                  />
                </div>
                <button className="bg-emerald-600 px-8 py-4 rounded-2xl font-bold hover:bg-emerald-500 transition-all flex items-center justify-center gap-2">
                  <Filter size={20} /> Filter
                </button>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Content Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-12">
            
            {/* Sidebar Controls */}
            <aside className="lg:w-64 shrink-0 space-y-8">
              <div>
                <h3 className="text-emerald-900 font-bold font-serif mb-4 flex items-center gap-2">
                  <BookOpen size={18} /> Categories
                </h3>
                <div className="space-y-2">
                  {['All Research', 'Biodiversity', 'Climate Change', 'Reforestation', 'Wildlife'].map((cat) => (
                    <button key={cat} className="block w-full text-left px-4 py-2 rounded-xl text-emerald-800/70 hover:bg-emerald-50 hover:text-emerald-600 transition-all text-sm font-medium">
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-6 bg-emerald-50 rounded-[32px] border border-emerald-100">
                <h4 className="font-bold font-serif text-emerald-900 mb-2">Open Science</h4>
                <p className="text-xs text-emerald-800/60 leading-relaxed mb-4">
                  We believe in sharing knowledge freely. All our publications are open-access under Creative Commons.
                </p>
                <button className="text-emerald-600 text-xs font-bold flex items-center gap-1 hover:gap-2 transition-all">
                  Learn more <ChevronRight size={14} />
                </button>
              </div>
            </aside>

            {/* Main Content Area */}
            <div className="flex-1">
              {/* Tabs */}
              <div className="flex border-b border-emerald-100 mb-8 overflow-x-auto">
                <button 
                  onClick={() => setActiveTab('publications')}
                  className={`px-6 py-4 text-sm font-bold border-b-2 transition-all whitespace-nowrap ${activeTab === 'publications' ? 'border-emerald-600 text-emerald-600' : 'border-transparent text-emerald-800/40 hover:text-emerald-800/60'}`}
                >
                  <FileText size={18} className="inline mr-2" /> Publications
                </button>
                <button 
                  onClick={() => setActiveTab('datasets')}
                  className={`px-6 py-4 text-sm font-bold border-b-2 transition-all whitespace-nowrap ${activeTab === 'datasets' ? 'border-emerald-600 text-emerald-600' : 'border-transparent text-emerald-800/40 hover:text-emerald-800/60'}`}
                >
                  <Database size={18} className="inline mr-2" /> Datasets
                </button>
                <button 
                  className={`px-6 py-4 text-sm font-bold border-b-2 transition-all whitespace-nowrap border-transparent text-emerald-800/40 hover:text-emerald-800/60`}
                >
                  <BarChart3 size={18} className="inline mr-2" /> Visualization Tools
                </button>
              </div>

              {/* Listings */}
              <div className="space-y-6">
                {activeTab === 'publications' ? (
                  publications.map((pub, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="group bg-white p-6 md:p-8 rounded-[32px] border border-emerald-50 hover:shadow-xl hover:shadow-emerald-500/5 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <span className="px-3 py-1 bg-emerald-100 text-emerald-600 text-[10px] font-bold uppercase tracking-wider rounded-full">
                            {pub.category}
                          </span>
                          <span className="text-emerald-800/40 text-xs font-medium">{pub.date}</span>
                        </div>
                        <h3 className="text-xl font-bold font-serif text-emerald-900 mb-2 group-hover:text-emerald-600 transition-colors">
                          {pub.title}
                        </h3>
                        <p className="text-emerald-800/60 text-sm italic">By {pub.authors}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right hidden md:block mr-4">
                          <div className="text-emerald-900 font-bold">{pub.downloads}</div>
                          <div className="text-[10px] text-emerald-800/40 uppercase font-bold">Downloads</div>
                        </div>
                        <button className="bg-emerald-50 text-emerald-600 p-4 rounded-2xl hover:bg-emerald-600 hover:text-white transition-all">
                          <Download size={20} />
                        </button>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  datasets.map((data, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="group bg-white p-6 md:p-8 rounded-[32px] border border-emerald-50 hover:shadow-xl hover:shadow-emerald-500/5 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6"
                    >
                      <div className="flex-1">
                        <h3 className="text-xl font-bold font-serif text-emerald-900 mb-2 group-hover:text-emerald-600 transition-colors">
                          {data.name}
                        </h3>
                        <div className="flex items-center gap-4 text-xs text-emerald-800/40 font-medium">
                          <span>{data.size}</span>
                          <span>•</span>
                          <span>{data.format}</span>
                          <span>•</span>
                          <span>Updated {data.lastUpdated}</span>
                        </div>
                      </div>
                      <button className="bg-emerald-900 text-white px-6 py-3 rounded-xl font-bold text-sm hover:bg-emerald-950 transition-all flex items-center gap-2">
                        Request Access <ChevronRight size={16} />
                      </button>
                    </motion.div>
                  ))
                )}
              </div>
            </div>

          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
