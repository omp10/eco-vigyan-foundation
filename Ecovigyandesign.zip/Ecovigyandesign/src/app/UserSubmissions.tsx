import React from 'react';
import { useParams, useNavigate, Link } from 'react-router';
import { motion } from 'motion/react';
import { ArrowLeft, MapPin, Calendar, ExternalLink, Map as MapIcon } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { MUSHROOM_DATA, CONTRIBUTORS } from './mushroom-data';

export default function UserSubmissions() {
  const { contributorName } = useParams();
  const navigate = useNavigate();

  // Find contributor
  const contributor = CONTRIBUTORS.find(
    c => c.name.toLowerCase().replace(/\s+/g, '-') === contributorName
  );

  // Get all observations by this contributor
  // Handle partial name matching (e.g., "Dr. Sharma" matches "Dr. Anjali Sharma")
  const userObservations = MUSHROOM_DATA.filter(obs => {
    if (!contributor) return false;
    
    // Check for exact match
    if (obs.contributor === contributor.name) return true;
    
    // Check if observation contributor name is contained in full contributor name
    // e.g., "Dr. Sharma" is in "Dr. Anjali Sharma"
    const obsContributor = obs.contributor.toLowerCase();
    const fullName = contributor.name.toLowerCase();
    
    // Split both names and check if all parts of obs contributor are in full name
    const obsParts = obsContributor.split(' ').filter(p => p.length > 0);
    return obsParts.every(part => fullName.includes(part));
  });

  if (!contributor && userObservations.length === 0) {
    return (
      <div className="min-h-screen bg-[#F9FAF8]">
        <Navbar />
        <main className="pt-32 pb-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl font-bold text-emerald-950 mb-4">Contributor Not Found</h1>
            <Link to="/shroomhub" className="text-emerald-600 hover:text-emerald-700 font-semibold">
              ← Back to Mushroom Hub
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const handleViewOnMap = (observation) => {
    // Navigate to mushroom hub with observation ID - only show on map, don't open modal
    navigate('/shroomhub', { state: { selectedObservation: observation, openModal: false } });
  };

  const handleCardClick = (observation) => {
    // Navigate to observation detail page
    navigate(`/shroomhub/observation/${observation.id}`);
  };

  return (
    <div className="min-h-screen bg-[#F9FAF8]">
      <Navbar />
      <main className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Button */}
          <Link 
            to="/shroomhub" 
            className="inline-flex items-center gap-2 text-emerald-600 hover:text-emerald-700 font-semibold mb-8 transition-colors"
          >
            <ArrowLeft size={20} />
            Back to Mushroom Hub
          </Link>

          {/* Profile Header */}
          {contributor && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-[48px] p-8 md:p-12 mb-12 border border-emerald-100"
            >
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="relative">
                  <div className="absolute inset-0 bg-emerald-200 rounded-full scale-110 blur-2xl opacity-30" />
                  <ImageWithFallback 
                    src={contributor.avatar} 
                    className="relative rounded-full w-32 h-32 object-cover border-4 border-white shadow-xl" 
                  />
                </div>
                <div className="text-center md:text-left flex-1">
                  <h1 className="text-4xl md:text-5xl font-bold font-serif text-emerald-950 mb-2">
                    {contributor.name}
                  </h1>
                  <p className="text-emerald-600 font-bold text-lg mb-4">{contributor.level}</p>
                  <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                    <div className="bg-white px-6 py-3 rounded-2xl border border-emerald-100 shadow-sm">
                      <span className="text-2xl font-bold text-emerald-900">{userObservations.length}</span>
                      <span className="text-xs font-bold text-emerald-900/40 uppercase ml-2">Observations</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Submissions Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-3xl font-bold font-serif text-emerald-950 mb-2">Submissions</h2>
                <p className="text-emerald-800/60">Verified field observations</p>
              </div>
              <div className="bg-emerald-600 text-white px-4 py-2 rounded-full font-bold text-sm">
                {userObservations.length} Total
              </div>
            </div>

            {/* Observations Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {userObservations.map((obs) => (
                <motion.div
                  key={obs.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  whileHover={{ y: -4 }}
                  className="bg-white rounded-[32px] overflow-hidden border border-emerald-100 shadow-lg hover:shadow-2xl transition-all cursor-pointer group"
                  onClick={() => handleCardClick(obs)}
                >
                  <div className="relative h-48 overflow-hidden">
                    <ImageWithFallback 
                      src={obs.image} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    <div className="absolute top-3 left-3">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                        obs.category === 'Toxic' ? 'bg-red-500' : 
                        obs.category === 'Medicinal' ? 'bg-purple-500' : 
                        'bg-emerald-500'
                      } text-white`}>
                        {obs.category}
                      </span>
                    </div>
                    <div className="absolute top-3 right-3 bg-emerald-900/80 backdrop-blur-sm p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                      <MapIcon size={16} className="text-white" />
                    </div>
                    <div className="absolute bottom-3 left-3 right-3">
                      <h3 className="text-white font-bold text-sm line-clamp-2">{obs.name}</h3>
                    </div>
                  </div>
                  <div className="p-4 space-y-3">
                    <div className="flex items-start gap-2 text-xs text-emerald-800/70">
                      <MapPin size={14} className="text-emerald-600 shrink-0 mt-0.5" />
                      <span className="line-clamp-1">{obs.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-emerald-800/70">
                      <Calendar size={14} className="text-emerald-600 shrink-0" />
                      <span>{obs.date}</span>
                    </div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleViewOnMap(obs);
                      }}
                      className="w-full bg-emerald-600 text-white py-2 rounded-xl font-bold text-xs hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
                    >
                      <MapIcon size={14} />
                      View on Map
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>

            {userObservations.length === 0 && (
              <div className="text-center py-20 bg-emerald-50 rounded-[32px]">
                <p className="text-emerald-800/60 text-lg">No observations found</p>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}