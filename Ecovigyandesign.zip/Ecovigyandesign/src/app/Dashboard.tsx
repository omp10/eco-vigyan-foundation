import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  MapPin, 
  CheckCircle, 
  Clock, 
  XCircle,
  Users,
  FileText,
  Eye,
  ArrowRight,
  Search,
  AlertCircle,
  Plus,
  Trash2,
  RefreshCw,
  Bell,
  Palette,
  BookOpen,
  Filter,
  ChevronDown,
  ChevronUp,
  ImageIcon,
  Shield,
  FileEdit,
  Upload,
  Database
} from 'lucide-react';
import { Navbar } from './components/Navbar';
import { ReviewObservationModal } from './components/ReviewObservationModal';
import { ImportExcelModal } from './components/ImportExcelModal';
import { Footer } from './components/Footer';
import { useAuth } from './contexts/AuthContext';
import { Link, useNavigate } from 'react-router';
import { Article } from './Articles';
import { ArticleCreateModal, ArticleFormData } from './components/ArticleCreateModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { toast } from 'sonner';
import { MushroomObservation } from './MySubmissions';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

// Storage keys
const OBSERVATIONS_KEY = 'ecovigyan_observations';
const ARTICLES_STORAGE_KEY = 'ecovigyan_articles';

// Dashboard component - points system removed
export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'observations' | 'admin'>('overview');
  const [observationFilter, setObservationFilter] = useState<'all' | 'pending' | 'approved' | 'rejected' | 'system'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [showNotifications, setShowNotifications] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  const [observations, setObservations] = useState<MushroomObservation[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [isArticleModalOpen, setIsArticleModalOpen] = useState(false);
  const [articleToDelete, setArticleToDelete] = useState<Article | null>(null);
  const [observationToDelete, setObservationToDelete] = useState<MushroomObservation | null>(null);
  const [expandedObservation, setExpandedObservation] = useState<string | null>(null);
  const [isBulkDeleteModalOpen, setIsBulkDeleteModalOpen] = useState(false);
  const [observationToReview, setObservationToReview] = useState<MushroomObservation | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
      return;
    }

    loadData();
  }, [user, isAuthenticated, navigate]);

  const loadData = () => {
    // Load data from localStorage
    const storedObservations = JSON.parse(localStorage.getItem(OBSERVATIONS_KEY) || '[]');
    const storedArticles = JSON.parse(localStorage.getItem(ARTICLES_STORAGE_KEY) || '[]');

    // Initialize demo data if empty
    if (storedObservations.length === 0) {
      initializeDemoData();
      return;
    }

    if (user?.role === 'admin') {
      setObservations(storedObservations);
      setArticles(storedArticles);
    } else {
      // Filter by user ID for members
      setObservations(storedObservations.filter((o: MushroomObservation) => o.userId === user?.id));
      setArticles(storedArticles.filter((a: Article) => a.authorRole === 'Writer' || a.authorRole === 'Admin'));
    }
  };

  const initializeDemoData = () => {
    // Demo observations - mushroom sightings that need admin verification
    // Use actual logged-in user ID to ensure they see their data
    const currentUserId = user?.id || 'demo-user';
    
    const demoObservations: MushroomObservation[] = [
      {
        id: 'obs-001',
        userId: currentUserId,
        commonName: 'Oyster Mushroom',
        scientificName: 'Pleurotus ostreatus',
        location: 'Western Ghats Forest Trail',
        coordinates: { lat: 15.4909, lng: 73.8278 },
        photoTimestamp: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'approved',
        approvedAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000).toISOString(),
        approvedBy: 'Admin User',
        images: ['https://images.unsplash.com/photo-1576419113698-559dc0e1e935?w=800'],
        ecologicalRole: ['decomposer'],
        texture: 'soft',
        undersideStructure: 'gills',
        fruitingSurface: 'wood',
        hasStem: true,
        commonUses: ['edible'],
        description: 'Found growing in clusters on a dead tree trunk. Caps were pale grey-white, smooth texture.',
      },
      {
        id: 'obs-002',
        userId: currentUserId,
        commonName: 'Golden Chanterelle',
        scientificName: 'Cantharellus cibarius',
        location: 'Nilgiri Hills, Tamil Nadu',
        coordinates: { lat: 11.4102, lng: 76.6950 },
        photoTimestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'pending',
        images: ['https://images.unsplash.com/photo-1509773896068-7fd415d91e2e?w=800'],
        description: 'Beautiful golden-yellow mushrooms found under oak trees. Distinctive funnel shape with false gills.',
      },
      {
        id: 'obs-003',
        userId: currentUserId,
        commonName: 'Turkey Tail',
        scientificName: 'Trametes versicolor',
        location: 'Coorg Coffee Plantation',
        coordinates: { lat: 12.3375, lng: 75.8069 },
        photoTimestamp: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'approved',
        approvedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
        approvedBy: 'Admin User',
        images: ['https://images.unsplash.com/photo-1459262838948-3e2de6c1ec80?w=800'],
        ecologicalRole: ['decomposer'],
        texture: 'leathery',
        undersideStructure: 'pores',
        fruitingSurface: 'wood',
        hasStem: false,
        commonUses: ['medicinal'],
        description: 'Multiple layers growing on fallen log. Concentric zones of different colors - brown, grey, blue.',
      },
      {
        id: 'obs-004',
        userId: currentUserId,
        commonName: 'Lion\'s Mane',
        scientificName: 'Hericium erinaceus',
        location: 'Silent Valley National Park',
        coordinates: { lat: 11.0931, lng: 76.4333 },
        photoTimestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'approved',
        approvedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
        approvedBy: 'Dr. Sharma',
        images: ['https://images.unsplash.com/photo-1584270354949-c26b0d5b4a0c?w=800'],
        ecologicalRole: ['decomposer'],
        texture: 'soft',
        undersideStructure: 'teeth',
        fruitingSurface: 'wood',
        hasStem: false,
        commonUses: ['edible', 'medicinal'],
        description: 'Rare find! White, cascading spines resembling a lion\'s mane. Growing on hardwood tree.',
      },
      {
        id: 'obs-005',
        userId: currentUserId,
        commonName: 'Indigo Milk Cap',
        scientificName: 'Lactarius indigo',
        location: 'Munnar Tea Estate',
        coordinates: { lat: 10.0889, lng: 77.0595 },
        photoTimestamp: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'rejected',
        rejectedAt: new Date(Date.now() - 19 * 24 * 60 * 60 * 1000).toISOString(),
        rejectionReason: 'Image quality too low for accurate identification. Please resubmit with clearer photos showing the blue milk.',
        images: ['https://images.unsplash.com/photo-1550588640-78d527ef890e?w=800'],
        description: 'Bright blue mushroom that releases blue milk when cut. Very unique coloration.',
      },
      {
        id: 'obs-006',
        userId: currentUserId,
        commonName: 'Chicken of the Woods',
        scientificName: 'Laetiporus sulphureus',
        location: 'Periyar Tiger Reserve',
        coordinates: { lat: 9.4652, lng: 77.2430 },
        photoTimestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'pending',
        images: ['https://images.unsplash.com/photo-1583299113614-2d8049e0e6b9?w=800'],
        description: 'Large bright orange and yellow shelf mushroom on oak tree. Soft and fleshy texture.',
      },
      {
        id: 'obs-007',
        userId: currentUserId,
        commonName: 'Fly Agaric',
        scientificName: 'Amanita muscaria',
        location: 'Kodaikanal Forest',
        coordinates: { lat: 10.2381, lng: 77.4892 },
        photoTimestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'pending',
        images: ['https://images.unsplash.com/photo-1576419113698-559dc0e1e935?w=800'],
        description: 'Classic red cap with white spots! Found under pine trees in misty conditions.',
      },
      {
        id: 'obs-008',
        userId: currentUserId,
        commonName: 'Wood Ear',
        scientificName: 'Auricularia auricula-judae',
        location: 'Wayanad Rainforest',
        coordinates: { lat: 11.6854, lng: 76.1320 },
        photoTimestamp: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'approved',
        approvedAt: new Date(Date.now() - 11 * 24 * 60 * 60 * 1000).toISOString(),
        approvedBy: 'Dr. Patel',
        images: ['https://images.unsplash.com/photo-1509773896068-7fd415d91e2e?w=800'],
        ecologicalRole: ['decomposer'],
        texture: 'jelly-like',
        undersideStructure: 'smooth',
        fruitingSurface: 'wood',
        hasStem: false,
        commonUses: ['edible'],
        description: 'Ear-shaped, gelatinous brown mushroom on elder wood. Common after rain.',
      },
      // Admin can see these other users' submissions
      {
        id: 'obs-009',
        userId: 'member-002',
        commonName: 'Shaggy Mane',
        scientificName: 'Coprinus comatus',
        location: 'Bangalore Urban Park',
        coordinates: { lat: 12.9716, lng: 77.5946 },
        photoTimestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'pending',
        images: ['https://images.unsplash.com/photo-1583299113614-2d8049e0e6b9?w=800'],
        description: 'Tall white mushroom with shaggy scales. Started to dissolve into black ink at the edges.',
      },
      {
        id: 'obs-010',
        userId: 'member-003',
        commonName: 'Reishi',
        scientificName: 'Ganoderma lucidum',
        location: 'Athirapally Forest',
        coordinates: { lat: 10.2855, lng: 76.5700 },
        photoTimestamp: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'approved',
        approvedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        approvedBy: 'Admin User',
        images: ['https://images.unsplash.com/photo-1459262838948-3e2de6c1ec80?w=800'],
        ecologicalRole: ['decomposer'],
        texture: 'hard',
        undersideStructure: 'pores',
        fruitingSurface: 'wood',
        hasStem: true,
        commonUses: ['medicinal'],
        description: 'Red-brown shelf mushroom with glossy surface. Known medicinal mushroom.',
      },
      {
        id: 'obs-011',
        userId: 'member-004',
        commonName: 'Puffball Mushroom',
        scientificName: 'Lycoperdon perlatum',
        location: 'Chikmagalur Hills',
        coordinates: { lat: 13.3161, lng: 75.7720 },
        photoTimestamp: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'pending',
        images: ['https://images.unsplash.com/photo-1584270354949-c26b0d5b4a0c?w=800'],
        description: 'Round white ball mushroom. Releases spores in a puff when touched.',
      },
      // Student observations - diverse submissions from school eco-club members
      {
        id: 'obs-012',
        userId: 'member-001',
        name: 'White Button Mushroom',
        commonName: 'White Button Mushroom',
        scientificName: 'Agaricus bisporus',
        location: 'Delhi Ridge Forest, Delhi',
        coordinates: { lat: 28.7041, lng: 77.1025 },
        photoTimestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        submittedBy: 'Demo Student',
        status: 'pending',
        images: [
          'https://images.unsplash.com/photo-1576419113698-559dc0e1e935?w=800',
          'https://images.unsplash.com/photo-1509773896068-7fd415d91e2e?w=800'
        ],
        description: 'Found these small white mushrooms growing near a tree stump. They have smooth caps and dark gills underneath. Our eco-club is learning to identify local mushrooms!',
      },
      {
        id: 'obs-013',
        userId: 'member-001',
        name: 'Rusty Brown Bracket',
        commonName: 'Rusty Brown Bracket',
        location: 'Aravalli Biodiversity Park, Gurugram',
        coordinates: { lat: 28.4595, lng: 77.0266 },
        photoTimestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        submittedBy: 'Demo Student',
        status: 'pending',
        images: ['https://images.unsplash.com/photo-1459262838948-3e2de6c1ec80?w=800'],
        description: 'Large brown shelf-like mushroom on dead tree. Very hard texture, cannot break it by hand.',
        ecologicalRole: ['decomposer'],
        texture: 'hard to touch',
        fruitingSurface: 'wood',
        stemPresence: 'no stem',
      },
      {
        id: 'obs-014',
        userId: 'member-001',
        name: 'Orange Peel Fungus',
        commonName: 'Orange Peel Fungus',
        scientificName: 'Aleuria aurantia',
        location: 'Lodi Gardens, New Delhi',
        coordinates: { lat: 28.5933, lng: 77.2197 },
        photoTimestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        submittedBy: 'Demo Student',
        status: 'approved',
        approvedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
        approvedBy: 'Dr. Mycologist',
        images: ['https://images.unsplash.com/photo-1583299113614-2d8049e0e6b9?w=800'],
        description: 'Small bright orange cup-shaped mushrooms found on bare soil after rain. Very vibrant color!',
        ecologicalRole: ['decomposer'],
        texture: 'soft',
        fruitingSurface: 'ground',
        stemPresence: 'no stem',
        properties: ['inedible'],
      },
      {
        id: 'obs-015',
        userId: 'member-001',
        name: 'Mystery Purple Mushroom',
        commonName: 'Mystery Purple Mushroom',
        location: 'Yamuna Biodiversity Park, Delhi',
        coordinates: { lat: 28.7196, lng: 77.2615 },
        photoTimestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        submittedBy: 'Demo Student',
        status: 'rejected',
        rejectedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
        rejectionReason: 'Image is too blurry to make accurate identification. Please resubmit with clearer, well-lit photos showing the cap, gills, and stem details.',
        images: ['https://images.unsplash.com/photo-1550588640-78d527ef890e?w=800'],
        description: 'Found purple colored mushroom under tree. Not sure what species.',
        internalNotes: 'Student needs guidance on proper mushroom photography techniques. Suggest they attend the next photo workshop.',
      },
      {
        id: 'obs-016',
        userId: 'student-005',
        name: 'White Coral Fungus',
        commonName: 'White Coral Fungus',
        scientificName: 'Clavulina cristata',
        location: 'Sanjay Van, Delhi',
        coordinates: { lat: 28.5245, lng: 77.1855 },
        photoTimestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        submittedBy: 'Kavya Reddy (Student)',
        status: 'approved',
        approvedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        approvedBy: 'Admin User',
        images: [
          'https://images.unsplash.com/photo-1584270354949-c26b0d5b4a0c?w=800',
          'https://images.unsplash.com/photo-1576419113698-559dc0e1e935?w=800',
          'https://images.unsplash.com/photo-1459262838948-3e2de6c1ec80?w=800'
        ],
        description: 'Amazing coral-like white mushroom! Branching structure like underwater coral. Found in leaf litter during our eco-club field trip.',
        ecologicalRole: ['decomposer'],
        texture: 'brittle',
        fruitingSurface: 'ground',
        stemPresence: 'has stem',
        properties: ['inedible', 'mysterious'],
      },
      {
        id: 'obs-017',
        userId: 'student-006',
        name: 'Brown Toadstool',
        commonName: 'Brown Toadstool',
        location: 'School Garden, Green Valley International School',
        coordinates: { lat: 28.4089, lng: 77.0389 },
        photoTimestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
        submittedBy: 'Aditya Singh (Student)',
        status: 'pending',
        images: ['https://images.unsplash.com/photo-1509773896068-7fd415d91e2e?w=800'],
        description: 'Small brown mushrooms in our school garden. Growing in a fairy ring pattern! Our biology teacher said to submit this.',
        ecologicalRole: ['symbiont'],
        texture: 'soft',
        underside: 'gills',
        fruitingSurface: 'ground',
        stemPresence: 'has stem',
      },
      {
        id: 'obs-018',
        userId: 'student-007',
        name: 'Yellow Shelf Mushroom',
        commonName: 'Yellow Shelf Mushroom',
        scientificName: 'Laetiporus sp.',
        location: 'Asola Bhatti Wildlife Sanctuary',
        coordinates: { lat: 28.4407, lng: 77.2444 },
        photoTimestamp: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
        submittedBy: 'Sneha Joshi (Student)',
        status: 'approved',
        approvedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        approvedBy: 'Dr. Sharma',
        images: ['https://images.unsplash.com/photo-1583299113614-2d8049e0e6b9?w=800'],
        description: 'Bright yellow-orange mushroom shelves on old tree trunk. Looks like stacked pancakes! Very beautiful specimen observed during nature walk.',
        ecologicalRole: ['decomposer'],
        texture: 'soft',
        underside: 'pores',
        fruitingSurface: 'wood',
        stemPresence: 'no stem',
        properties: ['edible', 'other uses'],
      },
      {
        id: 'obs-019',
        userId: 'member-001',
        name: 'Ink Cap Mushroom',
        commonName: 'Ink Cap Mushroom',
        location: 'Nehru Park, Delhi',
        coordinates: { lat: 28.5933, lng: 77.2197 },
        photoTimestamp: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
        submittedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
        submittedBy: 'Demo Student',
        status: 'pending',
        images: [
          'https://images.unsplash.com/photo-1584270354949-c26b0d5b4a0c?w=800',
          'https://images.unsplash.com/photo-1576419113698-559dc0e1e935?w=800'
        ],
        description: 'Found this mushroom that is dissolving into black liquid at the edges! Very cool and weird. Is this normal?? Submitted right after finding it.',
        texture: 'soft',
        underside: 'gills',
        fruitingSurface: 'ground',
        stemPresence: 'has stem',
      },
    ];

    // Demo articles
    const demoArticles: Article[] = [
      {
        id: 'article-001',
        title: 'The Importance of Fungi in Forest Ecosystems',
        content: 'Fungi play a crucial role in maintaining healthy forest ecosystems. They form symbiotic relationships with trees through mycorrhizal networks, helping them absorb nutrients and water. This intricate underground network, often called the "Wood Wide Web," connects trees and allows them to share resources and communicate. Recent research has shown that these fungal networks can extend for miles, creating a complex system that supports entire forest communities.',
        images: ['https://images.unsplash.com/photo-1576319155264-99536e0be1ee?w=1200&h=800&fit=crop'],
        author: 'Admin User',
        authorRole: 'Admin',
        publishedDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 'article-002',
        title: 'Starting Your School Eco Club: A Complete Guide',
        content: 'Creating an environmental club at your school is an excellent way to make a positive impact on your community and the planet. This comprehensive guide will walk you through the essential steps: forming a team of passionate students, setting clear goals and objectives, organizing regular meetings and activities, partnering with local environmental organizations, and measuring your impact through documented projects and initiatives.',
        images: ['https://images.unsplash.com/photo-1497445462247-4330a224fdb1?w=1200&h=800&fit=crop'],
        author: 'Demo Writer',
        authorRole: 'Writer',
        publishedDate: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString()
      }
    ];

    // Save to localStorage
    localStorage.setItem(OBSERVATIONS_KEY, JSON.stringify(demoObservations));
    localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(demoArticles));

    // Reload data
    loadData();
    toast.success('Demo data loaded! Review mushroom observations.');
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    loadData();
    setTimeout(() => {
      setIsRefreshing(false);
      toast.success('Data refreshed successfully!');
    }, 500);
  };

  const updateObservationStatus = (id: string, status: 'approved' | 'rejected', rejectionReason?: string) => {
    const stored = JSON.parse(localStorage.getItem(OBSERVATIONS_KEY) || '[]');
    
    const updated = stored.map((item: MushroomObservation) => {
      if (item.id === id) {
        const updatedItem = { ...item, status };
        
        if (status === 'approved') {
          updatedItem.approvedAt = new Date().toISOString();
          updatedItem.approvedBy = user?.name;
        } else if (status === 'rejected') {
          updatedItem.rejectedAt = new Date().toISOString();
          updatedItem.rejectionReason = rejectionReason || 'Does not meet quality standards';
        }
        
        return updatedItem;
      }
      return item;
    });
    
    localStorage.setItem(OBSERVATIONS_KEY, JSON.stringify(updated));
    
    // Update state
    setObservations(user?.role === 'admin' ? updated : updated.filter((o: MushroomObservation) => o.userId === user?.id));
    
    // Success toast
    toast.success(`Observation ${status} successfully!`);
  };

  const handleDeleteObservation = (observation: MushroomObservation) => {
    setObservationToDelete(observation);
  };

  const confirmDeleteObservation = () => {
    if (!observationToDelete) return;

    const allObservations = JSON.parse(localStorage.getItem(OBSERVATIONS_KEY) || '[]');
    const updated = allObservations.filter((o: MushroomObservation) => o.id !== observationToDelete.id);
    localStorage.setItem(OBSERVATIONS_KEY, JSON.stringify(updated));

    setObservationToDelete(null);
    loadData();
    toast.success('Observation deleted successfully');
  };

  const handleBulkApprove = () => {
    if (selectedItems.size === 0) {
      toast.error('Please select items first');
      return;
    }

    selectedItems.forEach(id => {
      updateObservationStatus(id, 'approved');
    });

    setSelectedItems(new Set());
    toast.success(`${selectedItems.size} observations approved!`);
  };

  const handleBulkDelete = () => {
    if (selectedItems.size === 0) {
      toast.error('Please select items first');
      return;
    }

    setIsBulkDeleteModalOpen(true);
  };

  const confirmBulkDelete = () => {
    const count = selectedItems.size;
    const allObservations = JSON.parse(localStorage.getItem(OBSERVATIONS_KEY) || '[]');
    const updated = allObservations.filter((o: MushroomObservation) => !selectedItems.has(o.id));
    localStorage.setItem(OBSERVATIONS_KEY, JSON.stringify(updated));

    setSelectedItems(new Set());
    setIsBulkDeleteModalOpen(false);
    loadData();
    toast.success(`${count} observation${count > 1 ? 's' : ''} deleted successfully`);
  };

  const toggleItemSelection = (id: string) => {
    const newSelected = new Set(selectedItems);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedItems(newSelected);
  };

  const selectAll = (items: MushroomObservation[]) => {
    const newSelected = new Set(items.map(item => item.id));
    setSelectedItems(newSelected);
  };

  const deselectAll = () => {
    setSelectedItems(new Set());
  };

  const handleSaveReview = (updatedObservation: MushroomObservation) => {
    const allObservations = JSON.parse(localStorage.getItem(OBSERVATIONS_KEY) || '[]');
    const updated = allObservations.map((o: MushroomObservation) =>
      o.id === updatedObservation.id ? updatedObservation : o
    );
    localStorage.setItem(OBSERVATIONS_KEY, JSON.stringify(updated));
    loadData();
    toast.success('Observation review saved successfully');
  };

  const handleImportObservations = (importedObservations: MushroomObservation[]) => {
    const allObservations = JSON.parse(localStorage.getItem(OBSERVATIONS_KEY) || '[]');
    const updated = [...allObservations, ...importedObservations];
    localStorage.setItem(OBSERVATIONS_KEY, JSON.stringify(updated));
    loadData();
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      pending: 'bg-amber-50 text-amber-700 border-amber-200',
      approved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      rejected: 'bg-red-50 text-red-700 border-red-200'
    };
    const icons = {
      pending: Clock,
      approved: CheckCircle,
      rejected: XCircle
    };
    const Icon = icons[status as keyof typeof icons];
    return (
      <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border ${styles[status as keyof typeof styles]}`}>
        <Icon className="w-3.5 h-3.5" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  const stats = {
    totalObservations: observations.length,
    pendingObservations: observations.filter(o => o.status === 'pending').length,
    approvedObservations: observations.filter(o => o.status === 'approved').length,
    rejectedObservations: observations.filter(o => o.status === 'rejected').length,
    systemImports: observations.filter(o => o.userId === 'system@ecovigyan.org').length,
  };

  const handleArticleCreate = (formData: ArticleFormData) => {
    const newArticle: Article = {
      id: Date.now().toString(),
      title: formData.title,
      content: formData.content,
      images: formData.images,
      author: user?.name || 'Unknown',
      authorRole: user?.role === 'admin' ? 'Admin' : user?.role === 'writer' ? 'Writer' : 'Member',
      publishedDate: new Date().toISOString(),
    };
    const updatedArticles = [...articles, newArticle];
    localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(updatedArticles));
    setArticles(updatedArticles);
    setIsArticleModalOpen(false);
    toast.success('Article created successfully! 📝');
  };

  const handleArticleDelete = (article: Article) => {
    setArticleToDelete(article);
  };

  const confirmArticleDelete = () => {
    if (!articleToDelete) return;
    const updatedArticles = articles.filter(a => a.id !== articleToDelete.id);
    localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(updatedArticles));
    setArticles(updatedArticles);
    setArticleToDelete(null);
    toast.success('Article deleted successfully! 🗑️');
  };

  // Filter helper
  const filterByStatus = (items: MushroomObservation[], filter: string) => {
    if (filter === 'all') return items;
    if (filter === 'system') return items.filter(item => item.userId === 'system@ecovigyan.org');
    return items.filter(item => item.status === filter);
  };

  // Search helper
  const filterBySearch = (items: MushroomObservation[], query: string) => {
    if (!query.trim()) return items;
    const lowerQuery = query.toLowerCase();
    return items.filter(item => {
      const searchableText = JSON.stringify(item).toLowerCase();
      return searchableText.includes(lowerQuery);
    });
  };

  // Combined filter and search
  const processObservations = (items: MushroomObservation[], filter: string) => {
    let processed = filterByStatus(items, filter);
    processed = filterBySearch(processed, searchQuery);
    return processed;
  };

  const filteredObservations = processObservations(observations, observationFilter);
  const pendingCount = stats.pendingObservations;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <main className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between mb-2">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-1">
                  Welcome back, {user?.name}
                </h1>
                <p className="text-gray-600">
                  {user?.role === 'admin' 
                    ? 'Manage submissions and oversee platform activities'
                    : 'Track your contributions and environmental impact'
                  }
                </p>
              </div>
              <div className="flex items-center gap-3">
                {/* Notifications */}
                {user?.role === 'admin' && (
                  <div className="relative">
                    <button
                      onClick={() => setShowNotifications(!showNotifications)}
                      className="relative p-2 bg-white rounded-lg border border-gray-200 shadow-sm hover:bg-gray-50 transition-all"
                    >
                      <Bell className="w-5 h-5 text-gray-700" />
                      {pendingCount > 0 && (
                        <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                          {pendingCount}
                        </span>
                      )}
                    </button>
                    
                    {/* Notifications Dropdown */}
                    <AnimatePresence>
                      {showNotifications && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 10 }}
                          className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-lg border border-gray-200 z-50"
                        >
                          <div className="p-4 border-b border-gray-100">
                            <h3 className="font-bold text-gray-900">Notifications</h3>
                          </div>
                          <div className="max-h-96 overflow-y-auto">
                            {pendingCount === 0 ? (
                              <div className="p-8 text-center text-gray-500">
                                <Bell className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                                <p className="text-sm">No new notifications</p>
                              </div>
                            ) : (
                              <div className="divide-y divide-gray-100">
                                <button
                                  onClick={() => {
                                    setActiveTab('observations');
                                    setObservationFilter('pending');
                                    setShowNotifications(false);
                                  }}
                                  className="w-full p-4 hover:bg-gray-50 transition-all text-left"
                                >
                                  <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                                      <MapPin className="w-5 h-5 text-emerald-600" />
                                    </div>
                                    <div className="flex-1">
                                      <p className="font-semibold text-gray-900 text-sm">
                                        {pendingCount} Pending Observation{pendingCount > 1 ? 's' : ''}
                                      </p>
                                      <p className="text-xs text-gray-500">Needs review</p>
                                    </div>
                                  </div>
                                </button>
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                {/* Refresh Button */}
                <button
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                  className="p-2 bg-white rounded-lg border border-gray-200 shadow-sm hover:bg-gray-50 transition-all disabled:opacity-50"
                >
                  <RefreshCw className={`w-5 h-5 text-gray-700 ${isRefreshing ? 'animate-spin' : ''}`} />
                </button>

                {/* Status Indicator */}
                <div className="hidden md:flex items-center gap-2 px-4 py-2 bg-white rounded-lg border border-gray-200 shadow-sm">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium text-gray-700">Active</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Navigation Tabs */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="mb-8"
          >
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-2">
              <div className="flex gap-1 overflow-x-auto">
                {(user?.role === 'admin' 
                  ? [
                      { id: 'overview', label: 'Overview', icon: LayoutDashboard },
                      { id: 'observations', label: 'Mushroom Observations', icon: MapPin, count: stats.pendingObservations },
                    ]
                  : [
                      { id: 'overview', label: 'Overview', icon: LayoutDashboard },
                      { id: 'observations', label: 'My Observations', icon: MapPin },
                    ]
                ).map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-medium text-sm transition-all relative ${
                        isActive
                          ? 'bg-emerald-600 text-white shadow-md'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="whitespace-nowrap">{tab.label}</span>
                      {tab.count !== undefined && tab.count > 0 && (
                        <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                          isActive ? 'bg-white text-emerald-600' : 'bg-red-500 text-white'
                        }`}>
                          {tab.count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </motion.div>

          {/* Content Area */}
          <AnimatePresence mode="wait">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <motion.div
                key="overview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                {/* Stats Grid */}
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {/* Observations Cards */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="bg-white rounded-xl p-6 shadow-sm border border-gray-200"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
                        <MapPin className="w-6 h-6 text-emerald-600" />
                      </div>
                    </div>
                    <h3 className="text-3xl font-bold text-gray-900 mb-1">{stats.totalObservations}</h3>
                    <p className="text-sm text-gray-600 mb-4">{user?.role === 'admin' ? 'Total' : 'My'} Observations</p>
                    <div className="flex items-center gap-4 text-xs">
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                        <span className="text-gray-600">{stats.approvedObservations} Approved</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                        <span className="text-gray-600">{stats.pendingObservations} Pending</span>
                      </div>
                    </div>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="bg-white rounded-xl p-6 shadow-sm border border-gray-200"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
                        <Clock className="w-6 h-6 text-amber-600" />
                      </div>
                    </div>
                    <h3 className="text-3xl font-bold text-gray-900 mb-1">{stats.pendingObservations}</h3>
                    <p className="text-sm text-gray-600 mb-4">Pending Review</p>
                    {user?.role === 'admin' && stats.pendingObservations > 0 && (
                      <button
                        onClick={() => {
                          setActiveTab('observations');
                          setObservationFilter('pending');
                        }}
                        className="text-xs font-semibold text-amber-600 hover:text-amber-700 flex items-center gap-1"
                      >
                        Review now <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="bg-white rounded-xl p-6 shadow-sm border border-gray-200"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
                        <FileText className="w-6 h-6 text-blue-600" />
                      </div>
                    </div>
                    <h3 className="text-3xl font-bold text-gray-900 mb-1">{articles.length}</h3>
                    <p className="text-sm text-gray-600 mb-4">Published Articles</p>
                    {(user?.role === 'admin' || user?.role === 'writer') && (
                      <button
                        onClick={() => setIsArticleModalOpen(true)}
                        className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
                      >
                        Create new <Plus className="w-3 h-3" />
                      </button>
                    )}
                  </motion.div>
                </div>

                {/* Quick Actions */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-200"
                >
                  <h2 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h2>
                  <div className="grid md:grid-cols-3 gap-4">
                    {user?.role !== 'admin' && (
                      <Link
                        to="/my-submissions"
                        className="group flex items-center gap-4 p-4 bg-gradient-to-br from-emerald-50 to-teal-100 rounded-xl hover:shadow-md transition-all border border-emerald-200"
                      >
                        <div className="w-12 h-12 rounded-xl bg-emerald-600 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                          <MapPin className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="font-bold text-emerald-900 mb-0.5">My Submissions</div>
                          <div className="text-xs text-emerald-700">Track your observations</div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-emerald-600 group-hover:translate-x-1 transition-transform" />
                      </Link>
                    )}

                    <Link
                      to="/shroomhub"
                      className="group flex items-center gap-4 p-4 bg-gradient-to-br from-teal-50 to-cyan-100 rounded-xl hover:shadow-md transition-all border border-teal-200"
                    >
                      <div className="w-12 h-12 rounded-xl bg-teal-600 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                        <MapPin className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="font-bold text-teal-900 mb-0.5">Mushroom Hub</div>
                        <div className="text-xs text-teal-700">Add new observations</div>
                      </div>
                      <ArrowRight className="w-5 h-5 text-teal-600 group-hover:translate-x-1 transition-transform" />
                    </Link>

                    <Link
                      to="/programs"
                      className="group flex items-center gap-4 p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl hover:shadow-md transition-all border border-blue-200"
                    >
                      <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                        <BookOpen className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="font-bold text-blue-900 mb-0.5">Browse Programs</div>
                        <div className="text-xs text-blue-700">Enroll in eco programs</div>
                      </div>
                      <ArrowRight className="w-5 h-5 text-blue-600 group-hover:translate-x-1 transition-transform" />
                    </Link>

                    <Link
                      to="/gallery"
                      className="group flex items-center gap-4 p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl hover:shadow-md transition-all border border-purple-200"
                    >
                      <div className="w-12 h-12 rounded-xl bg-purple-600 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                        <Palette className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="font-bold text-purple-900 mb-0.5">View Gallery</div>
                        <div className="text-xs text-purple-700">Browse artwork collection</div>
                      </div>
                      <ArrowRight className="w-5 h-5 text-purple-600 group-hover:translate-x-1 transition-transform" />
                    </Link>
                  </div>
                </motion.div>
              </motion.div>
            )}

            {/* Observations Tab */}
            {activeTab === 'observations' && (
              <motion.div
                key="observations"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                {/* Stats Cards - Better Design */}
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  {[
                    { label: 'All', value: stats.totalObservations, icon: Filter, color: 'bg-blue-500' },
                    { label: 'Pending', value: stats.pendingObservations, icon: Clock, color: 'bg-amber-500' },
                    { label: 'Approved', value: stats.approvedObservations, icon: CheckCircle, color: 'bg-emerald-500' },
                    { label: 'Rejected', value: stats.rejectedObservations, icon: XCircle, color: 'bg-red-500' },
                    ...(user?.role === 'admin' ? [{ label: 'System', value: stats.systemImports, icon: Database, color: 'bg-purple-500' }] : []),
                  ].map((stat) => {
                    const Icon = stat.icon;
                    const isActive = observationFilter === stat.label.toLowerCase();
                    
                    return (
                      <button
                        key={stat.label}
                        onClick={() => setObservationFilter(stat.label.toLowerCase() as any)}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          isActive 
                            ? 'bg-white border-emerald-500 shadow-lg scale-105' 
                            : 'bg-white border-gray-200 hover:border-gray-300 hover:shadow-md'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className={`w-10 h-10 rounded-lg ${stat.color} flex items-center justify-center`}>
                            <Icon className="w-5 h-5 text-white" />
                          </div>
                          <span className="text-2xl font-bold text-gray-900">{stat.value}</span>
                        </div>
                        <div className="text-sm font-semibold text-gray-600">{stat.label}</div>
                      </button>
                    );
                  })}
                </div>

                {/* Admin Bulk Actions & Search */}
                <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                  <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className="text-sm text-gray-600">
                        Showing <span className="font-bold text-gray-900">{filteredObservations.length}</span> {observationFilter === 'all' ? 'total' : observationFilter} submission{filteredObservations.length !== 1 ? 's' : ''}
                      </div>
                      
                      {/* Load Demo Data Button */}
                      {user?.role === 'admin' && (
                        <>
                          <button
                            onClick={initializeDemoData}
                            className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 transition-all flex items-center gap-2"
                          >
                            <RefreshCw className="w-4 h-4" />
                            Load Demo Data
                          </button>
                          <button
                            onClick={() => setIsImportModalOpen(true)}
                            className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-semibold hover:bg-purple-700 transition-all flex items-center gap-2"
                          >
                            <Upload className="w-4 h-4" />
                            Import Excel
                          </button>
                        </>
                      )}
                    </div>

                        {user?.role === 'admin' && filteredObservations.length > 0 && observationFilter === 'pending' && (
                          <div className="flex gap-2">
                            <button
                              onClick={() => selectAll(filteredObservations)}
                              className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-semibold hover:bg-gray-200 transition-all"
                            >
                              Select All
                            </button>
                            {selectedItems.size > 0 && (
                              <>
                                <button
                                  onClick={deselectAll}
                                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-semibold hover:bg-gray-200 transition-all"
                                >
                                  Deselect All
                                </button>
                                <button
                                  onClick={handleBulkApprove}
                                  className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-semibold hover:bg-emerald-700 transition-all"
                                >
                                  Approve ({selectedItems.size})
                                </button>
                                <button
                                  onClick={handleBulkDelete}
                                  className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-semibold hover:bg-red-700 transition-all"
                                >
                                  Delete ({selectedItems.size})
                                </button>
                              </>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          placeholder="Search observations..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>
                    </div>

                    {/* Observations List */}
                    <div className="space-y-4">
                      {filteredObservations.length === 0 ? (
                        <div className="bg-white rounded-xl p-12 text-center border border-gray-200">
                          <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                          <p className="text-gray-600 mb-2">No observations found</p>
                          {user?.role !== 'admin' && (
                            <Link
                              to="/shroomhub"
                              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700 transition-colors mt-4"
                            >
                              <Plus className="w-4 h-4" />
                              Add Your First Observation
                            </Link>
                          )}
                        </div>
                      ) : (
                        filteredObservations.map((obs, index) => (
                          <motion.div
                            key={obs.id}
                            layout
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            transition={{ delay: index * 0.05 }}
                            className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow"
                          >
                            <div className="p-6">
                              <div className="flex flex-col md:flex-row gap-6">
                                {/* Checkbox for admin bulk actions */}
                                {user?.role === 'admin' && observationFilter === 'pending' && (
                                  <input
                                    type="checkbox"
                                    checked={selectedItems.has(obs.id)}
                                    onChange={() => toggleItemSelection(obs.id)}
                                    className="mt-1 w-5 h-5 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 self-start"
                                  />
                                )}
                                
                                {/* Observation Image - Larger thumbnail */}
                                <div className="w-full md:w-48 h-48 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                                  {obs.images && obs.images.length > 0 ? (
                                    <ImageWithFallback
                                      src={obs.images[0]} 
                                      className="w-full h-full object-cover"
                                    />
                                  ) : (
                                    <div className="w-full h-full flex items-center justify-center">
                                      <ImageIcon className="w-12 h-12 text-gray-300" />
                                    </div>
                                  )}
                                </div>
                              
                                <div className="flex-1">
                                  <div className="flex items-start justify-between mb-3">
                                    <div className="flex-1">
                                      <h3 className="text-lg font-bold text-gray-900 mb-1">
                                        {obs.commonName || 'Unidentified Mushroom'}
                                      </h3>
                                      {obs.scientificName && (
                                        <p className="text-sm text-gray-600 italic mb-2">{obs.scientificName}</p>
                                      )}
                                    </div>
                                    <div className="ml-4">
                                      {getStatusBadge(obs.status)}
                                    </div>
                                  </div>

                                  {/* Description */}
                                  {obs.description && (
                                    <p className="text-sm text-gray-700 mb-3">{obs.description}</p>
                                  )}

                                  {/* Location & Time Info */}
                                  <div className="grid md:grid-cols-2 gap-3 mb-3 text-sm">
                                    <div className="flex items-center gap-2 text-gray-600">
                                      <MapPin className="w-4 h-4 text-gray-400 flex-shrink-0" />
                                      <span className="truncate">{obs.location}</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-gray-600">
                                      <Clock className="w-4 h-4 text-gray-400 flex-shrink-0" />
                                      <span>{new Date(obs.submittedAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                                    </div>
                                  </div>

                                  {/* Status-Specific Info */}
                                  {obs.status === 'approved' && obs.approvedAt && (
                                    <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 mb-3">
                                      <div className="flex items-start gap-2">
                                        <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                                        <div className="text-sm">
                                          <p className="font-semibold text-emerald-900">
                                            Approved on {new Date(obs.approvedAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                                            {obs.approvedBy && ` by ${obs.approvedBy}`}
                                          </p>
                                        </div>
                                      </div>
                                    </div>
                                  )}

                                  {obs.status === 'rejected' && obs.rejectionReason && (
                                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-3">
                                      <div className="flex items-start gap-2">
                                        <XCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                                        <div className="text-sm">
                                          <p className="font-semibold text-red-900 mb-1">Rejection Reason:</p>
                                          <p className="text-red-700">{obs.rejectionReason}</p>
                                        </div>
                                      </div>
                                    </div>
                                  )}

                                  {/* Action Buttons */}
                                  <div className="flex gap-2 flex-wrap">
                                    {/* Review button - visible to admins */}
                                    {user?.role === 'admin' && (
                                      <button
                                        onClick={() => setObservationToReview(obs)}
                                        className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 transition-all"
                                      >
                                        <FileEdit className="w-4 h-4" />
                                        Review
                                      </button>
                                    )}
                                    
                                    {/* Admin actions */}
                                    {user?.role === 'admin' && obs.status === 'pending' && (
                                      <>
                                        <button
                                          onClick={() => updateObservationStatus(obs.id, 'approved')}
                                          className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-semibold hover:bg-emerald-700 transition-all"
                                        >
                                          <CheckCircle className="w-4 h-4" />
                                          Approve
                                        </button>
                                        <button
                                          onClick={() => {
                                            const reason = prompt('Enter rejection reason (visible to user):');
                                            if (reason) updateObservationStatus(obs.id, 'rejected', reason);
                                          }}
                                          className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-semibold hover:bg-red-700 transition-all"
                                        >
                                          <XCircle className="w-4 h-4" />
                                          Reject
                                        </button>
                                      </>
                                    )}
                                    
                                    {/* Delete button for own observations or admin */}
                                    {(user?.role === 'admin' || obs.userId === user?.id) && (
                                      <button
                                        onClick={() => handleDeleteObservation(obs)}
                                        className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-red-600 rounded-lg text-sm font-semibold hover:bg-red-50 transition-all ml-auto"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                        Delete
                                      </button>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        ))
                      )}
                    </div>
              </motion.div>
            )}

            {/* Admin Panel Tab */}
            {activeTab === 'admin' && user?.role === 'admin' && (
              <motion.div
                key="admin"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                {/* Admin Panel Content */}
                <div className="bg-white rounded-xl p-12 text-center border border-gray-200">
                  <Shield className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Admin Panel</h3>
                  <p className="text-gray-600">
                    Advanced administrative features and controls
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      <Footer />

      {/* Article Create Modal */}
      <ArticleCreateModal
        isOpen={isArticleModalOpen}
        onClose={() => setIsArticleModalOpen(false)}
        onSubmit={handleArticleCreate}
      />

      {/* Article Delete Confirmation */}
      <DeleteConfirmModal
        isOpen={!!articleToDelete}
        onClose={() => setArticleToDelete(null)}
        onConfirm={confirmArticleDelete}
        title="Delete Article"
        message="Are you sure you want to delete this article? This action cannot be undone."
      />

      {/* Observation Delete Confirmation */}
      <DeleteConfirmModal
        isOpen={!!observationToDelete}
        onClose={() => setObservationToDelete(null)}
        onConfirm={confirmDeleteObservation}
        title="Delete Observation"
        message="Are you sure you want to delete this observation? This action cannot be undone."
      />

      {/* Bulk Delete Confirmation */}
      <DeleteConfirmModal
        isOpen={isBulkDeleteModalOpen}
        onClose={() => setIsBulkDeleteModalOpen(false)}
        onConfirm={confirmBulkDelete}
        title="Delete Multiple Observations"
        message={`Are you sure you want to delete ${selectedItems.size} observation${selectedItems.size > 1 ? 's' : ''}? This action cannot be undone.`}
      />

      {/* Review Observation Modal */}
      <ReviewObservationModal
        isOpen={!!observationToReview}
        onClose={() => setObservationToReview(null)}
        observation={observationToReview}
        onSave={handleSaveReview}
        onApprove={(id) => updateObservationStatus(id, 'approved')}
        onReject={(id, reason) => updateObservationStatus(id, 'rejected', reason)}
      />

      {/* Import Excel Modal */}
      <ImportExcelModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImport={handleImportObservations}
      />
    </div>
  );
}