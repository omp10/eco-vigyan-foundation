import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, School, Users, Calendar, Award, Palette, ChevronLeft, ChevronRight, Upload, Edit, Trash2, Plus, AlertCircle } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Link } from 'react-router';
import { useAuth } from './contexts/AuthContext';
import { ArtworkUploadModal, ArtworkFormData } from './components/ArtworkUploadModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { toast } from 'sonner';

const GALLERY_STORAGE_KEY = 'ecovigyan_gallery_artworks';

interface Artwork {
  id: string;
  title: string;
  imageUrl: string;
  studentName: string;
  school: string;
  program: string;
  year: string;
  description: string;
  theme: string;
  category: 'Nature Art' | 'Recycled Materials' | 'Paintings' | 'Posters' | 'Collage' | 'Mixed Media';
}

const defaultArtworks: Artwork[] = [
  {
    id: '1',
    title: 'Butterfly Symphony',
    imageUrl: 'https://images.unsplash.com/photo-1761799839491-d1c18630e8d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwbmF0dXJlJTIwYXJ0JTIwbGVhdmVzJTIwY3JhZnR8ZW58MXx8fHwxNzcyNDY5MTAzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    studentName: 'Wipro Earthian Team',
    school: 'GGSS SAMBOG SHIMLA',
    program: 'Wipro Earthian Program',
    year: '2023',
    description: 'A beautiful butterfly created using natural leaves and flowers, symbolizing the transformation and beauty of nature. This artwork celebrates biodiversity and the delicate balance of our ecosystems.',
    theme: 'Biodiversity & Nature Care',
    category: 'Nature Art'
  },
  {
    id: '2',
    title: 'Wise Owl Guardian',
    imageUrl: 'https://images.unsplash.com/photo-1625236585783-373ff56ddd57?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZHJlbiUyMGVjbyUyMGFydCUyMHJlY3ljbGVkJTIwbWF0ZXJpYWxzfGVufDF8fHx8MTc3MjQ2OTEwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    studentName: 'Wipro Earthian Team',
    school: 'GGSS SAMBOG SHIMLA',
    program: 'Wipro Earthian Program',
    year: '2023',
    description: 'An artistic owl crafted from fern leaves and natural materials, representing wisdom and the protection of forest ecosystems. Each feather tells a story of nature\'s intricate design.',
    theme: 'Forest Conservation',
    category: 'Nature Art'
  },
  {
    id: '3',
    title: 'Sustainable Tomorrow',
    imageUrl: 'https://images.unsplash.com/photo-1710976483763-25290f0212ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2hvb2wlMjBlbnZpcm9ubWVudGFsJTIwcG9zdGVyJTIwZHJhd2luZ3xlbnwxfHx8fDE3NzI0NjkxMDR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    studentName: 'Krish Verma, Bharti, Ojasvl Daroch, Pranav Thakur, Arpit Thakur',
    school: 'SYN KUMHAR SOLAN',
    program: 'Wipro Earthian Program',
    year: '2023',
    description: 'A vibrant illustration showcasing sustainable and eco-friendly living with green buildings, clean water, and a thriving market. This artwork envisions a future where humans and nature coexist harmoniously.',
    theme: 'Sustainable Development',
    category: 'Posters'
  },
  {
    id: '4',
    title: 'Nature\'s Palette',
    imageUrl: 'https://images.unsplash.com/photo-1706931333738-87738429e35b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmUlMjBjb2xsYWdlJTIwc3R1ZGVudCUyMGFydHdvcmt8ZW58MXx8fHwxNzcyNDY5MTA1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    studentName: 'Green Warriors Team',
    school: 'Eco School Initiative',
    program: 'Chemical Free Living Series',
    year: '2024',
    description: 'A stunning collage made entirely from dried leaves, flowers, and natural pigments collected during forest walks. This piece demonstrates the incredible diversity of colors found in nature.',
    theme: 'Natural Materials',
    category: 'Collage'
  },
  {
    id: '5',
    title: 'Earth Protectors',
    imageUrl: 'https://images.unsplash.com/photo-1727768351795-2390d19b2b41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxraWRzJTIwcGFpbnRpbmclMjBlbnZpcm9ubWVudGFsJTIwdGhlbWV8ZW58MXx8fHwxNzcyNDY5MTA1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    studentName: 'Young Environmentalists',
    school: 'Mountain View School',
    program: 'Wipro Earthian Program',
    year: '2024',
    description: 'Colorful paintings by young students expressing their commitment to environmental protection. Each brushstroke represents a promise to care for our planet.',
    theme: 'Youth Climate Action',
    category: 'Paintings'
  },
  {
    id: '6',
    title: 'Waste to Wonder',
    imageUrl: 'https://images.unsplash.com/photo-1764607913377-709024678fbb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwYmlvZGl2ZXJzaXR5JTIwYXJ0JTIwcHJvamVjdHxlbnwxfHx8fDE3NzI0NjkxMDV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    studentName: 'Recycling Champions',
    school: 'Himachal Eco Academy',
    program: 'Mastering Solid Waste Management',
    year: '2023',
    description: 'Creative art installation made from upcycled materials, demonstrating how waste can be transformed into beautiful decorative pieces following the 3 R\'s principles.',
    theme: 'Waste Management',
    category: 'Recycled Materials'
  }
];

export default function Gallery() {
  const { user, isAuthenticated } = useAuth();
  const [artworks, setArtworks] = useState<Artwork[]>(defaultArtworks);
  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(null);
  const [filter, setFilter] = useState<string>('All');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [editingArtwork, setEditingArtwork] = useState<Artwork | null>(null);
  const [deleteArtwork, setDeleteArtwork] = useState<Artwork | null>(null);

  const categories = ['All', 'Nature Art', 'Recycled Materials', 'Paintings', 'Posters', 'Collage', 'Mixed Media'];

  // Load artworks from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(GALLERY_STORAGE_KEY);
    if (stored) {
      try {
        const parsedArtworks = JSON.parse(stored);
        setArtworks(parsedArtworks.length > 0 ? parsedArtworks : defaultArtworks);
      } catch {
        setArtworks(defaultArtworks);
      }
    } else {
      localStorage.setItem(GALLERY_STORAGE_KEY, JSON.stringify(defaultArtworks));
    }
  }, []);

  const filteredArtworks = filter === 'All' 
    ? artworks 
    : artworks.filter(art => art.category === filter);

  const handleNext = () => {
    if (!selectedArtwork) return;
    const currentIndex = artworks.findIndex(art => art.id === selectedArtwork.id);
    const nextIndex = (currentIndex + 1) % artworks.length;
    setSelectedArtwork(artworks[nextIndex]);
  };

  const handlePrevious = () => {
    if (!selectedArtwork) return;
    const currentIndex = artworks.findIndex(art => art.id === selectedArtwork.id);
    const previousIndex = (currentIndex - 1 + artworks.length) % artworks.length;
    setSelectedArtwork(artworks[previousIndex]);
  };

  const handleSubmit = (formData: ArtworkFormData) => {
    if (editingArtwork) {
      // Update existing artwork
      const updated = artworks.map(art => 
        art.id === editingArtwork.id 
          ? { ...art, ...formData, category: formData.category as any }
          : art
      );
      setArtworks(updated);
      localStorage.setItem(GALLERY_STORAGE_KEY, JSON.stringify(updated));
      toast.success('Artwork updated successfully! 🎨');
      setEditingArtwork(null);
    } else {
      // Add new artwork
      const newArtwork: Artwork = {
        id: Date.now().toString(),
        ...formData,
        category: formData.category as any
      };
      const updated = [...artworks, newArtwork];
      setArtworks(updated);
      localStorage.setItem(GALLERY_STORAGE_KEY, JSON.stringify(updated));
      toast.success('Artwork uploaded successfully! 🎨');
    }
    setIsUploadModalOpen(false);
  };

  const handleEdit = (artwork: Artwork) => {
    setEditingArtwork(artwork);
    setIsUploadModalOpen(true);
  };

  const handleDelete = (artwork: Artwork) => {
    if (deleteArtwork === artwork) {
      const updated = artworks.filter(art => art.id !== artwork.id);
      setArtworks(updated);
      localStorage.setItem(GALLERY_STORAGE_KEY, JSON.stringify(updated));
      setDeleteArtwork(null);
      if (selectedArtwork?.id === artwork.id) {
        setSelectedArtwork(null);
      }
      toast.success('Artwork deleted successfully!');
    } else {
      setDeleteArtwork(artwork);
      setTimeout(() => setDeleteArtwork(null), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-br from-emerald-700 to-emerald-900 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-96 h-96 border-2 border-white rounded-full" />
          <div className="absolute bottom-10 right-10 w-64 h-64 border-2 border-white rounded-full" />
          <div className="absolute top-1/2 left-1/2 w-80 h-80 border border-white rounded-full" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-white/90 text-sm font-medium mb-6">
              <Palette className="w-4 h-4" />
              <span>Student Creativity</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 font-serif">
              ECO-ART GALLERY
            </h1>
            <p className="text-xl md:text-2xl text-emerald-50 max-w-4xl mx-auto leading-relaxed mb-8">
              Art is where young minds speak for the Earth. This gallery showcases artwork created by students as part of our nature education initiatives.
            </p>

            {/* Admin Upload Button */}
            {user?.role === 'admin' && (
              <button
                onClick={() => {
                  setEditingArtwork(null);
                  setIsUploadModalOpen(true);
                }}
                className="inline-flex items-center gap-2 bg-white text-emerald-900 px-8 py-4 rounded-xl font-bold hover:bg-emerald-50 transition-all shadow-xl"
              >
                <Plus className="w-5 h-5" />
                Upload New Artwork
              </button>
            )}
          </motion.div>
        </div>
      </section>

      {/* Statistics Banner */}
      <section className="py-12 bg-gradient-to-r from-emerald-50 to-teal-50 border-y border-emerald-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-emerald-900 mb-2">{artworks.length}+</div>
              <div className="text-sm text-emerald-600 font-medium">Artworks Showcased</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-emerald-900 mb-2">15+</div>
              <div className="text-sm text-emerald-600 font-medium">Schools Represented</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-emerald-900 mb-2">100+</div>
              <div className="text-sm text-emerald-600 font-medium">Young Artists</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-emerald-900 mb-2">3</div>
              <div className="text-sm text-emerald-600 font-medium">Education Programs</div>
            </div>
          </div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-8 bg-white border-b border-emerald-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-3 justify-center">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setFilter(category)}
                className={`px-6 py-2.5 rounded-full font-semibold text-sm transition-all ${
                  filter === category
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200'
                    : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-20 bg-gradient-to-b from-white to-emerald-50/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            layout
          >
            <AnimatePresence mode="popLayout">
              {filteredArtworks.map((artwork, index) => (
                <motion.div
                  key={artwork.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className="group bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border-4 border-white hover:border-emerald-200"
                >
                  {/* Artwork Image */}
                  <div 
                    className="relative aspect-[4/3] overflow-hidden bg-gradient-to-br from-emerald-50 to-teal-50 cursor-pointer"
                    onClick={() => setSelectedArtwork(artwork)}
                  >
                    <img
                      src={artwork.imageUrl}
                      alt={artwork.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    
                    {/* Admin Actions */}
                    {user?.role === 'admin' && (
                      <div className="absolute top-3 right-3 flex gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEdit(artwork);
                          }}
                          className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center hover:bg-blue-700 transition-colors shadow-lg"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(artwork);
                          }}
                          className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors shadow-lg ${
                            deleteArtwork === artwork
                              ? 'bg-red-700 text-white animate-pulse'
                              : 'bg-red-600 text-white hover:bg-red-700'
                          }`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}

                    {/* Overlay Info */}
                    <div className="absolute bottom-0 left-0 right-0 p-4 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                      <div className="text-sm font-semibold mb-1">{artwork.title}</div>
                      <div className="text-xs opacity-90">Click to view details</div>
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="p-6 bg-white">
                    <div className="flex items-start gap-3 mb-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center shrink-0">
                        <Users className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-emerald-900 text-sm mb-1 truncate">
                          {artwork.studentName}
                        </div>
                        <div className="flex items-center gap-1.5 text-xs text-emerald-600">
                          <School className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">{artwork.school}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-emerald-100 to-teal-100 text-emerald-700 text-xs font-semibold">
                        <Award className="w-3.5 h-3.5" />
                        {artwork.category}
                      </span>
                      <span className="text-xs text-gray-500 font-medium">
                        {artwork.year}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>

          {filteredArtworks.length === 0 && (
            <div className="text-center py-20">
              <Palette className="w-16 h-16 text-emerald-300 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-2">No artworks found</h3>
              <p className="text-gray-600">Try selecting a different category</p>
            </div>
          )}
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-br from-emerald-900 to-teal-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 right-20 w-96 h-96 border border-white rounded-full" />
          <div className="absolute bottom-10 left-10 w-64 h-64 border border-white rounded-full" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Palette className="w-16 h-16 text-emerald-400 mx-auto mb-6" />
          <h2 className="text-4xl font-bold text-white mb-6 font-serif">
            Want to Showcase Your Art?
          </h2>
          <p className="text-xl text-emerald-100 mb-8 leading-relaxed">
            Join our education programs and let your creativity speak for the Earth. Every artwork tells a story of environmental awareness and action.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/programs" className="bg-white text-emerald-900 px-8 py-4 rounded-xl font-bold hover:bg-emerald-50 transition-all shadow-xl inline-block text-center">
              Explore Programs
            </Link>
            <button 
              onClick={() => window.location.href = 'mailto:ecovigyan@gmail.com'}
              className="bg-emerald-700 text-white px-8 py-4 rounded-xl font-bold hover:bg-emerald-600 transition-all border-2 border-emerald-500"
            >
              Submit Your Artwork
            </button>
          </div>
        </div>
      </section>

      {/* Artwork Detail Modal */}
      <AnimatePresence>
        {selectedArtwork && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="relative w-full max-w-5xl max-h-[90vh] overflow-y-auto">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white rounded-3xl shadow-2xl"
              >
                {/* Header */}
                <div className="relative bg-gradient-to-r from-emerald-500 to-teal-600 p-4 flex items-center justify-end">
                  <button
                    onClick={() => setSelectedArtwork(null)}
                    className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/30 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Navigation */}
                <button
                  onClick={handlePrevious}
                  className="fixed left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white shadow-xl flex items-center justify-center text-gray-700 hover:bg-emerald-50 transition-colors"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                  onClick={handleNext}
                  className="fixed right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white shadow-xl flex items-center justify-center text-gray-700 hover:bg-emerald-50 transition-colors"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>

                <div className="p-8">
                  {/* Image */}
                  <div className="mb-8 rounded-2xl overflow-hidden border-4 border-emerald-100">
                    <img
                      src={selectedArtwork.imageUrl}
                      alt={selectedArtwork.title}
                      className="w-full aspect-video object-cover"
                    />
                  </div>

                  {/* Details */}
                  <div className="space-y-6">
                    <div>
                      <h2 className="text-4xl font-bold text-emerald-900 mb-2 font-serif">
                        {selectedArtwork.title}
                      </h2>
                      <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-emerald-100 to-teal-100 text-emerald-700 text-sm font-semibold">
                        <Award className="w-4 h-4" />
                        {selectedArtwork.category}
                      </span>
                    </div>

                    <p className="text-lg text-gray-700 leading-relaxed">
                      {selectedArtwork.description}
                    </p>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="bg-emerald-50 p-6 rounded-2xl">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-emerald-600 flex items-center justify-center">
                            <Users className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <div className="text-xs text-emerald-600 font-semibold uppercase">Artist(s)</div>
                            <div className="text-base font-bold text-emerald-900">{selectedArtwork.studentName}</div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-blue-50 p-6 rounded-2xl">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center">
                            <School className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <div className="text-xs text-blue-600 font-semibold uppercase">School</div>
                            <div className="text-base font-bold text-blue-900">{selectedArtwork.school}</div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-purple-50 p-6 rounded-2xl">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-purple-600 flex items-center justify-center">
                            <Palette className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <div className="text-xs text-purple-600 font-semibold uppercase">Program</div>
                            <div className="text-base font-bold text-purple-900">{selectedArtwork.program}</div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-amber-50 p-6 rounded-2xl">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-amber-600 flex items-center justify-center">
                            <Calendar className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <div className="text-xs text-amber-600 font-semibold uppercase">Year & Theme</div>
                            <div className="text-base font-bold text-amber-900">{selectedArtwork.year} - {selectedArtwork.theme}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Upload/Edit Modal */}
      <ArtworkUploadModal
        isOpen={isUploadModalOpen}
        onClose={() => {
          setIsUploadModalOpen(false);
          setEditingArtwork(null);
        }}
        onSubmit={handleSubmit}
        editData={editingArtwork || undefined}
        isEditing={!!editingArtwork}
      />

      {/* Delete Confirm Modal */}
      <DeleteConfirmModal
        isOpen={!!deleteArtwork}
        onClose={() => setDeleteArtwork(null)}
        onConfirm={() => {
          if (deleteArtwork) {
            const updated = artworks.filter(art => art.id !== deleteArtwork.id);
            setArtworks(updated);
            localStorage.setItem(GALLERY_STORAGE_KEY, JSON.stringify(updated));
            if (selectedArtwork?.id === deleteArtwork.id) {
              setSelectedArtwork(null);
            }
            toast.success('Artwork deleted successfully! 🗑️');
          }
          setDeleteArtwork(null);
        }}
        title={deleteArtwork?.title || ''}
        itemName={`By ${deleteArtwork?.studentName} from ${deleteArtwork?.school}`}
      />

      <Footer />
    </div>
  );
}