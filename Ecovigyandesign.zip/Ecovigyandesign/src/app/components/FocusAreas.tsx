import React from 'react';
import { motion } from 'motion/react';
import { Microscope, TreePine, Users, GraduationCap } from 'lucide-react';

export function FocusAreas() {
  const areas = [
    {
      title: 'Scientific Research',
      description: 'Mapping biodiversity and monitoring ecosystem health using advanced field techniques.',
      icon: <Microscope className="w-8 h-8" />,
      color: 'bg-emerald-50',
      iconColor: 'text-emerald-600'
    },
    {
      title: 'Conservation Action',
      description: 'Implementing on-ground restoration projects for endangered flora and fauna.',
      icon: <TreePine className="w-8 h-8" />,
      color: 'bg-emerald-50',
      iconColor: 'text-emerald-600'
    },
    {
      title: 'Community Outreach',
      description: 'Partnering with local communities to promote sustainable living practices.',
      icon: <Users className="w-8 h-8" />,
      color: 'bg-emerald-50',
      iconColor: 'text-emerald-600'
    },
    {
      title: 'Nature Education',
      description: 'Developing curriculum and training programs for the next generation of ecologists.',
      icon: <GraduationCap className="w-8 h-8" />,
      color: 'bg-emerald-50',
      iconColor: 'text-emerald-600'
    }
  ];

  return (
    <section id="focus" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-emerald-600 font-bold tracking-wider uppercase text-sm mb-3">What We Do</h2>
          <h3 className="text-4xl font-bold font-serif text-emerald-950 mb-4">Our Core Focus Areas</h3>
          <p className="text-emerald-800/70 max-w-2xl mx-auto">
            We integrate scientific methodology with practical conservation to create lasting impact for our planet's fragile ecosystems.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {areas.map((area, index) => (
            <motion.div
              key={area.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group p-8 rounded-3xl border border-emerald-50 hover:border-emerald-100 hover:shadow-xl hover:shadow-emerald-500/5 transition-all duration-300 bg-white"
            >
              <div className={`${area.color} ${area.iconColor} w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                {area.icon}
              </div>
              <h4 className="text-xl font-bold text-emerald-900 mb-3">{area.title}</h4>
              <p className="text-emerald-800/60 text-sm leading-relaxed">
                {area.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
