import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Clock, Users, Star, CheckCircle2, MapPin, ArrowLeft, Check, ChevronRight, Leaf, Recycle } from 'lucide-react';

interface Program {
  id: string;
  title: string;
  tagline: string;
  description: string;
  isPrimary?: boolean;
  icon: React.ElementType;
  duration: string;
  participants: string;
  highlights: string[];
  syllabus: string[];
  outcomes: string[];
  targetAudience: string[];
  image: string;
  color: string;
  statistics?: {
    label: string;
    value: string;
    description: string;
  };
  locations?: string[];
  testimonials?: {
    name: string;
    text: string;
  }[];
  videoUrl?: string;
  videoEmbed?: string;
  additionalLink?: {
    text: string;
    url: string;
  };
}

interface ProgramModalProps {
  program: Program;
  modalView: 'details' | 'enrollment' | 'success';
  formData: {
    fullName: string;
    email: string;
    phone: string;
    message: string;
  };
  isSubmitting: boolean;
  onClose: () => void;
  onEnrollClick: () => void;
  onBackToDetails: () => void;
  onSubmit: (e: React.FormEvent) => void;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
}

export function ProgramModal({
  program,
  modalView,
  formData,
  isSubmitting,
  onClose,
  onEnrollClick,
  onBackToDetails,
  onSubmit,
  onChange
}: ProgramModalProps) {
  const contentRef = React.useRef<HTMLDivElement>(null);

  // Scroll to top when modalView changes
  React.useEffect(() => {
    if (contentRef.current) {
      contentRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [modalView]);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="relative w-full max-w-4xl max-h-[90vh] flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className="bg-white rounded-3xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        >
          {/* Modal Header - Same for all views */}
          <div className={`relative bg-gradient-to-br ${program.color} p-8`}>
            <button
              onClick={modalView === 'enrollment' ? onBackToDetails : onClose}
              className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/30 transition-colors z-10"
            >
              {modalView === 'enrollment' ? <ArrowLeft className="w-5 h-5" /> : '✕'}
            </button>
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <program.icon className="w-9 h-9 text-white" />
              </div>
              {program.isPrimary && (
                <span className="bg-yellow-400 text-yellow-900 px-4 py-1.5 rounded-full text-sm font-bold">
                  FEATURED PROGRAM
                </span>
              )}
            </div>
            <h2 className="text-4xl font-bold text-white mb-3 font-serif">
              {program.title}
            </h2>
            <p className="text-xl text-white/90">
              {program.tagline}
            </p>
          </div>

          {/* Modal Content - Changes based on modalView */}
          <div className="p-8 overflow-y-auto relative" ref={contentRef}>
            <AnimatePresence mode="wait">
              {modalView === 'details' && (
                <motion.div
                  key="details"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.25 }}
                >
                  {/* Quick Info Grid */}
                  <div className="grid md:grid-cols-2 gap-4 mb-8">
                    <div className="bg-emerald-50 p-4 rounded-xl">
                      <Clock className="w-6 h-6 text-emerald-600 mb-2" />
                      <div className="text-xs text-gray-600 mb-1">Duration</div>
                      <div className="font-bold text-gray-900">{program.duration}</div>
                    </div>
                    <div className="bg-emerald-50 p-4 rounded-xl">
                      <Users className="w-6 h-6 text-emerald-600 mb-2" />
                      <div className="text-xs text-gray-600 mb-1">Group Size</div>
                      <div className="font-bold text-gray-900">{program.participants}</div>
                    </div>
                  </div>

                  {/* Description */}
                  <div className="mb-8">
                    <h3 className="text-xl font-bold text-gray-900 mb-3">About This Program</h3>
                    <p className="text-gray-600 leading-relaxed">{program.description}</p>
                  </div>

                  {/* Video Section */}
                  {program.videoEmbed && (
                    <div className="mb-8">
                      <div className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200 rounded-2xl p-6">
                        <h3 className="text-lg font-bold text-gray-900 mb-4 text-center">
                          📺 To get a quick program overview, watch this video!
                        </h3>
                        <div className="aspect-video rounded-xl overflow-hidden shadow-lg">
                          <iframe
                            width="100%"
                            height="100%"
                            src={program.videoEmbed}
                            title="Program Overview Video"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                            className="w-full h-full"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Additional Link */}
                  {program.additionalLink && (
                    <div className="mb-8">
                      <a
                        href={program.additionalLink.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block bg-gradient-to-r from-purple-100 to-pink-100 border-2 border-purple-300 rounded-2xl p-6 hover:from-purple-200 hover:to-pink-200 transition-all group"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-gray-900 font-semibold">
                            {program.additionalLink.text}
                          </span>
                          <ChevronRight className="w-5 h-5 text-purple-600 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </a>
                    </div>
                  )}

                  {/* Program Focus (for Wipro) */}
                  {program.id === 'wipro-earthian' && (
                    <div className="mb-8">
                      <h3 className="text-xl font-bold text-gray-900 mb-4">Program Focus</h3>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl p-6 text-center">
                          <Leaf className="w-10 h-10 text-green-600 mx-auto mb-3" />
                          <h4 className="font-bold text-gray-900 mb-1">Biodiversity &</h4>
                          <h4 className="font-bold text-gray-900">Nature Care</h4>
                        </div>
                        <div className="bg-gradient-to-br from-blue-50 to-cyan-50 border-2 border-blue-200 rounded-xl p-6 text-center">
                          <Recycle className="w-10 h-10 text-blue-600 mx-auto mb-3" />
                          <h4 className="font-bold text-gray-900 mb-1">Water & Waste</h4>
                          <h4 className="font-bold text-gray-900">Management</h4>
                        </div>
                        <div className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200 rounded-xl p-6 text-center">
                          <Users className="w-10 h-10 text-purple-600 mx-auto mb-3" />
                          <h4 className="font-bold text-gray-900 mb-1">Community</h4>
                          <h4 className="font-bold text-gray-900">Awareness</h4>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Statistics */}
                  {program.statistics && (
                    <div className="mb-8">
                      <div className="bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-200 rounded-2xl p-6">
                        <div className="text-center">
                          <div className="text-sm font-semibold text-emerald-700 uppercase tracking-wide mb-2">
                            {program.statistics.label}
                          </div>
                          <div className="text-5xl font-bold text-emerald-900 mb-3">
                            {program.statistics.value}
                          </div>
                          <p className="text-gray-700 leading-relaxed">
                            {program.statistics.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Locations */}
                  {program.locations && program.locations.length > 0 && (
                    <div className="mb-8">
                      <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <MapPin className="w-5 h-5 text-emerald-600" />
                        Walk Locations (2021-23)
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {program.locations.map((location, idx) => (
                          <span
                            key={idx}
                            className="bg-white border border-emerald-200 text-gray-700 px-4 py-2 rounded-lg text-sm hover:bg-emerald-50 transition-colors"
                          >
                            {location}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* All Highlights */}
                  <div className="mb-8">
                    <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                      <Star className="w-5 h-5 text-yellow-500" />
                      What You'll Get
                    </h3>
                    <ul className="grid md:grid-cols-2 gap-3">
                      {program.highlights.map((highlight, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                          <span className="text-gray-700">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Syllabus */}
                  <div className="mb-8">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Program Syllabus</h3>
                    <div className="space-y-3">
                      {program.syllabus.map((item, idx) => (
                        <div key={idx} className="flex gap-3 items-start">
                          <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-xs font-bold shrink-0">
                            {idx + 1}
                          </div>
                          <p className="text-gray-700">{item}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Learning Outcomes */}
                  <div className="mb-8">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Learning Outcomes</h3>
                    <ul className="space-y-3">
                      {program.outcomes.map((outcome, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <CheckCircle2 className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                          <span className="text-gray-700">{outcome}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Target Audience */}
                  <div className="mb-8">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Perfect For</h3>
                    <div className="flex flex-wrap gap-2">
                      {program.targetAudience.map((audience, idx) => (
                        <span
                          key={idx}
                          className="bg-emerald-100 text-emerald-800 px-4 py-2 rounded-full text-sm font-medium"
                        >
                          {audience}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Testimonials/Feedback */}
                  {program.testimonials && program.testimonials.length > 0 && (
                    <div className="mb-8">
                      <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                        Participant Feedback
                      </h3>
                      <div className="space-y-4">
                        {program.testimonials.map((testimonial, idx) => (
                          <div
                            key={idx}
                            className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-6"
                          >
                            <div className="flex gap-2 mb-3">
                              {[...Array(5)].map((_, i) => (
                                <Star key={i} className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                              ))}
                            </div>
                            <p className="text-gray-700 leading-relaxed mb-4 italic">
                              "{testimonial.text}"
                            </p>
                            <div className="font-bold text-gray-900">— {testimonial.name}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Enrollment CTA */}
                  <button 
                    onClick={onEnrollClick}
                    className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-8 py-4 rounded-xl font-bold hover:from-emerald-700 hover:to-teal-700 transition-all shadow-lg"
                  >
                    Enroll in This Program
                  </button>
                </motion.div>
              )}

              {modalView === 'enrollment' && (
                <motion.div
                  key="enrollment"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.25 }}
                >
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Enroll in {program.title}</h3>
                  <form onSubmit={onSubmit}>
                    <div className="grid md:grid-cols-2 gap-4 mb-6">
                      <div className="bg-emerald-50 p-4 rounded-xl">
                        <Clock className="w-6 h-6 text-emerald-600 mb-2" />
                        <div className="text-xs text-gray-600 mb-1">Duration</div>
                        <div className="font-bold text-gray-900">{program.duration}</div>
                      </div>
                      <div className="bg-emerald-50 p-4 rounded-xl">
                        <Users className="w-6 h-6 text-emerald-600 mb-2" />
                        <div className="text-xs text-gray-600 mb-1">Group Size</div>
                        <div className="font-bold text-gray-900">{program.participants}</div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <label className="block text-sm font-bold text-gray-900 mb-2">FULL NAME *</label>
                      <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={onChange}
                        placeholder="Enter your full name"
                        className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        required
                      />
                    </div>

                    <div className="mb-4">
                      <label className="block text-sm font-bold text-gray-900 mb-2">EMAIL ADDRESS *</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={onChange}
                        placeholder="your.email@example.com"
                        className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        required
                      />
                    </div>

                    <div className="mb-4">
                      <label className="block text-sm font-bold text-gray-900 mb-2">PHONE NUMBER * (INDIAN)</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={onChange}
                        placeholder="+91 9876543210 or 9876543210"
                        className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        required
                      />
                    </div>

                    <div className="mb-6">
                      <label className="block text-sm font-bold text-gray-900 mb-2">ADDITIONAL MESSAGE (OPTIONAL)</label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={onChange}
                        placeholder="Any questions or special requirements?"
                        className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        rows={5}
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-8 py-4 rounded-xl font-bold hover:from-emerald-700 hover:to-teal-700 transition-all shadow-lg"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? 'Submitting...' : 'Enroll Now'}
                    </button>
                  </form>
                </motion.div>
              )}

              {modalView === 'success' && (
                <motion.div
                  key="success"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.25 }}
                  className="text-center py-8"
                >
                  <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Check className="w-10 h-10 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Enrollment Successful!</h3>
                  <p className="text-gray-600 leading-relaxed mb-8 max-w-md mx-auto">
                    Thank you for enrolling in {program.title}. We have received your details and will get back to you shortly with further instructions.
                  </p>
                  <button
                    onClick={onClose}
                    className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-8 py-4 rounded-xl font-bold hover:from-emerald-700 hover:to-teal-700 transition-all shadow-lg"
                  >
                    Close
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  );
}