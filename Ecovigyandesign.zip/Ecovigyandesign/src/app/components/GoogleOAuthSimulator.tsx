import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check } from 'lucide-react';

interface GoogleOAuthSimulatorProps {
  onSuccess: (userData: { email: string; name: string; avatar: string }) => void;
  onClose: () => void;
}

export function GoogleOAuthSimulator({ onSuccess, onClose }: GoogleOAuthSimulatorProps) {
  const [step, setStep] = useState<'select' | 'loading'>('select');

  // Mock Google accounts
  const mockGoogleAccounts = [
    {
      email: 'sarah.johnson@gmail.com',
      name: 'Sarah Johnson',
      avatar: 'https://i.pravatar.cc/150?img=1'
    },
    {
      email: 'rahul.sharma@gmail.com',
      name: 'Rahul Sharma',
      avatar: 'https://i.pravatar.cc/150?img=13'
    },
    {
      email: 'priya.patel@gmail.com',
      name: 'Priya Patel',
      avatar: 'https://i.pravatar.cc/150?img=5'
    }
  ];

  const handleAccountSelect = (account: typeof mockGoogleAccounts[0]) => {
    setStep('loading');
    
    // Simulate OAuth processing
    setTimeout(() => {
      onSuccess(account);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden"
      >
        {step === 'select' ? (
          <>
            {/* Header */}
            <div className="relative bg-white border-b border-gray-200 p-6">
              <button
                onClick={onClose}
                className="absolute top-4 right-4 w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="flex items-center gap-3 mb-2">
                <svg viewBox="0 0 24 24" className="w-8 h-8">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">Sign in with Google</h2>
                  <p className="text-sm text-gray-600">Choose an account</p>
                </div>
              </div>
            </div>

            {/* Account List */}
            <div className="p-4 space-y-2 max-h-[400px] overflow-y-auto">
              <p className="text-xs text-gray-600 px-2 mb-3">
                🎭 Demo Mode: Select a mock Google account
              </p>
              
              {mockGoogleAccounts.map((account) => (
                <button
                  key={account.email}
                  onClick={() => handleAccountSelect(account)}
                  className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 rounded-xl transition-colors border-2 border-transparent hover:border-blue-200"
                >
                  <img 
                    src={account.avatar} 
                    alt={account.name}
                    className="w-12 h-12 rounded-full border-2 border-gray-200"
                  />
                  <div className="flex-1 text-left">
                    <div className="font-semibold text-gray-900">{account.name}</div>
                    <div className="text-sm text-gray-600">{account.email}</div>
                  </div>
                </button>
              ))}
            </div>

            {/* Footer */}
            <div className="p-4 bg-gray-50 border-t border-gray-200">
              <p className="text-xs text-gray-600 text-center">
                By continuing, you agree to Eco Vigyan Foundation's Terms of Service and Privacy Policy
              </p>
            </div>
          </>
        ) : (
          // Loading state
          <div className="p-12 text-center">
            <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Signing you in...</h3>
            <p className="text-sm text-gray-600">Please wait while we verify your account</p>
          </div>
        )}
      </motion.div>
    </div>
  );
}
