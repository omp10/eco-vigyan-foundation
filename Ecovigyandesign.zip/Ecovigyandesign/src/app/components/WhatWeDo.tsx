import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Pause, Play } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import slide1Image from 'figma:asset/9194aaca469e797183fe76ba7795e2c431513053.png';
import slide2Image from 'figma:asset/857cc0f6e2c19fabaf98728adb81cde1b371ff67.png';
import slide3Image from 'figma:asset/88e5b7a0e4cdb4f959cee53ad062acd4fd17c3ad.png';
import slide4Image from 'figma:asset/97eec498ab6be4bf42e13b6748d149e2d7757f55.png';
import slide5Image from 'figma:asset/733393f59e0d9a301929caf168c5a26115b34005.png';
import slide6Image from 'figma:asset/1777f46278a92ee5d30fc9ac67c6f77829b48a62.png';

interface Slide {
  tagline: string;
  heading: string;
  description: string;
  image: string;
}

export function WhatWeDo() {
  const slides: Slide[] = [
    {
      tagline: 'SUSTAINABILITY EDUCATION',
      heading: 'Cultivating Eco-Conscious Schools Across India',
      description: 'Empowering students to learn, explore, and care for nature.',
      image: slide1Image
    },
    {
      tagline: 'LEARNING THROUGH NATURE',
      heading: 'Where Every Child Becomes a Budding Scientist',
      description: 'Igniting curiosity through hands-on experiences in the natural world.',
      image: slide2Image
    },
    {
      tagline: 'FUNGI & BIODIVERSITY AWARENESS',
      heading: 'Revealing Nature\'s Hidden Heroes',
      description: 'Exploring the unseen world of fungi to inspire wonder and understanding.',
      image: slide3Image
    },
    {
      tagline: 'ECO-CLUB TRANSFORMATION',
      heading: 'Building Stronger Eco-Clubs, One School at a Time',
      description: 'Nurturing young changemakers through meaningful environmental action.',
      image: slide4Image
    },
    {
      tagline: 'HEAD, HEART & HAND LEARNING',
      heading: 'Transforming Education Through Experience',
      description: 'Connecting thinking, feeling, and doing for deeper understanding.',
      image: slide5Image
    },
    {
      tagline: 'COMMUNITY & CONSERVATION',
      heading: 'Sharing Knowledge, Growing Impact',
      description: 'Inspiring collective action for a sustainable future.',
      image: slide6Image
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [direction, setDirection] = useState(0);

  // Safety check: Reset index if it's out of bounds
  useEffect(() => {
    if (currentIndex >= slides.length) {
      setCurrentIndex(0);
    }
  }, [currentIndex, slides.length]);

  const nextSlide = useCallback(() => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % slides.length);
  }, [slides.length]);

  const prevSlide = useCallback(() => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + slides.length) % slides.length);
  }, [slides.length]);

  const goToSlide = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  // Auto-play functionality
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      nextSlide();
    }, 5000); // 5 seconds per slide

    return () => clearInterval(interval);
  }, [isPlaying, nextSlide]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') prevSlide();
      if (e.key === 'ArrowRight') nextSlide();
      if (e.key === ' ') {
        e.preventDefault();
        setIsPlaying(!isPlaying);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide, isPlaying]);

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  return (
    <section 
      id="what-we-do"
      className="relative h-[600px] md:h-[700px] lg:h-[800px] overflow-hidden bg-emerald-900"
      onMouseEnter={() => setIsPlaying(false)}
      onMouseLeave={() => setIsPlaying(true)}
    >
      {/* Slides */}
      <AnimatePresence initial={false} custom={direction}>
        <motion.div
          key={currentIndex}
          custom={direction}
          variants={slideVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.5 }
          }}
          className="absolute inset-0"
        >
          {/* Background Image */}
          <div className="absolute inset-0">
            <ImageWithFallback
              src={slides[currentIndex].image}
              alt={slides[currentIndex].heading}
              className="w-full h-full object-cover"
            />
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-black/30" />
          </div>

          {/* Content */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="inline-block px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white text-xs md:text-sm font-semibold tracking-wider mb-6"
              >
                {slides[currentIndex].tagline}
              </motion.div>
              
              <motion.h2
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold font-serif text-white mb-6 leading-tight px-4"
              >
                {slides[currentIndex].heading}
              </motion.h2>
              
              <motion.p
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="text-lg md:text-xl lg:text-2xl text-white/90 max-w-3xl mx-auto px-4"
              >
                {slides[currentIndex].description}
              </motion.p>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 w-12 h-12 md:w-14 md:h-14 bg-white/10 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all z-20 group"
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-6 h-6 group-hover:scale-110 transition-transform" />
      </button>
      
      <button
        onClick={nextSlide}
        className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 w-12 h-12 md:w-14 md:h-14 bg-white/10 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all z-20 group"
        aria-label="Next slide"
      >
        <ChevronRight className="w-6 h-6 group-hover:scale-110 transition-transform" />
      </button>

      {/* Play/Pause Button */}
      <button
        onClick={() => setIsPlaying(!isPlaying)}
        className="absolute left-4 md:left-8 bottom-20 md:bottom-8 w-10 h-10 bg-white/10 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all z-20"
        aria-label={isPlaying ? 'Pause carousel' : 'Play carousel'}
      >
        {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
      </button>

      {/* Dot Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`transition-all ${
              index === currentIndex
                ? 'w-8 md:w-12 h-2 bg-emerald-400'
                : 'w-2 h-2 bg-white/40 hover:bg-white/60'
            } rounded-full`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Progress Bar */}
      {isPlaying && (
        <motion.div
          className="absolute bottom-0 left-0 h-1 bg-emerald-400 z-20"
          initial={{ width: '0%' }}
          animate={{ width: '100%' }}
          transition={{ duration: 5, ease: 'linear' }}
          key={currentIndex}
        />
      )}
    </section>
  );
}