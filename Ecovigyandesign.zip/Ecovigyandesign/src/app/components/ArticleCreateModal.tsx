import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Upload, FileText, ImageIcon, AlertCircle } from 'lucide-react';

export interface ArticleFormData {
  title: string;
  content: string;
  images: string[];
}

interface ArticleCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: ArticleFormData) => void;
  editData?: ArticleFormData & { id: string };
  isEditing?: boolean;
}

export function ArticleCreateModal({ isOpen, onClose, onSubmit, editData, isEditing }: ArticleCreateModalProps) {
  const [formData, setFormData] = useState<ArticleFormData>(
    editData || {
      title: '',
      content: '',
      images: []
    }
  );
  const [imageUrls, setImageUrls] = useState<string[]>(editData?.images || []);
  const [errors, setErrors] = useState<{ title?: string; content?: string; images?: string }>({});

  const validateForm = () => {
    const newErrors: { title?: string; content?: string; images?: string } = {};

    // Title validation (5-200 characters)
    if (formData.title.length < 5) {
      newErrors.title = 'Title must be at least 5 characters';
    } else if (formData.title.length > 200) {
      newErrors.title = 'Title cannot exceed 200 characters';
    }

    // Content validation (50-10,000 characters)
    if (formData.content.length < 50) {
      newErrors.content = 'Content must be at least 50 characters';
    } else if (formData.content.length > 10000) {
      newErrors.content = 'Content cannot exceed 10,000 characters';
    }

    // Image validation (max 2 images)
    if (imageUrls.length > 2) {
      newErrors.images = 'Maximum 2 images allowed';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      onSubmit({
        ...formData,
        images: imageUrls
      });
      handleClose();
    }
  };

  const handleClose = () => {
    setFormData({ title: '', content: '', images: [] });
    setImageUrls([]);
    setErrors({});
    onClose();
  };

  const handleAddImage = () => {
    if (imageUrls.length < 2) {
      const url = prompt('Enter image URL:');
      if (url && url.trim()) {
        setImageUrls([...imageUrls, url.trim()]);
      }
    }
  };

  const handleRemoveImage = (index: number) => {
    setImageUrls(imageUrls.filter((_, i) => i !== index));
  };

  if (!isOpen) return null;

  const titleCharCount = formData.title.length;
  const contentCharCount = formData.content.length;
  const titleColor = titleCharCount < 5 ? 'text-red-600' : titleCharCount > 200 ? 'text-red-600' : 'text-emerald-600';
  const contentColor = contentCharCount < 50 ? 'text-red-600' : contentCharCount > 10000 ? 'text-red-600' : 'text-emerald-600';

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full my-8"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                  <FileText className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white font-serif">
                    {isEditing ? 'Edit Article' : 'Write New Article'}
                  </h2>
                  <p className="text-emerald-100 text-sm">Share environmental insights and stories</p>
                </div>
              </div>
              <button
                onClick={handleClose}
                className="w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Form */}
          <div className="p-8 max-h-[70vh] overflow-y-auto">
            <div className="space-y-6">
              {/* Title */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-bold text-gray-700">
                    Title <span className="text-red-500">*</span>
                  </label>
                  <span className={`text-xs font-semibold ${titleColor}`}>
                    {titleCharCount}/200
                  </span>
                </div>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Enter article title (5-200 characters)"
                  className={`w-full px-4 py-3 border-2 rounded-xl focus:outline-none ${
                    errors.title ? 'border-red-300 focus:border-red-500' : 'border-gray-200 focus:border-emerald-500'
                  }`}
                  maxLength={200}
                />
                {errors.title && (
                  <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {errors.title}
                  </p>
                )}
              </div>

              {/* Content */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-bold text-gray-700">
                    Content <span className="text-red-500">*</span>
                  </label>
                  <span className={`text-xs font-semibold ${contentColor}`}>
                    {contentCharCount}/10,000
                  </span>
                </div>
                <textarea
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder="Write your article content here (50-10,000 characters)..."
                  rows={12}
                  className={`w-full px-4 py-3 border-2 rounded-xl focus:outline-none resize-none ${
                    errors.content ? 'border-red-300 focus:border-red-500' : 'border-gray-200 focus:border-emerald-500'
                  }`}
                  maxLength={10000}
                />
                {errors.content && (
                  <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {errors.content}
                  </p>
                )}
              </div>

              {/* Images */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <label className="block text-sm font-bold text-gray-700">
                    Images (Optional - Max 2)
                  </label>
                  <span className="text-xs font-semibold text-gray-500">
                    {imageUrls.length}/2
                  </span>
                </div>

                {/* Image Preview Grid */}
                {imageUrls.length > 0 && (
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    {imageUrls.map((url, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={url}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-40 object-cover rounded-xl border-2 border-gray-200"
                        />
                        <button
                          type="button"
                          onClick={() => handleRemoveImage(index)}
                          className="absolute top-2 right-2 w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Add Image Button */}
                {imageUrls.length < 2 && (
                  <button
                    type="button"
                    onClick={handleAddImage}
                    className="w-full px-4 py-3 border-2 border-dashed border-emerald-300 rounded-xl hover:border-emerald-500 hover:bg-emerald-50 transition-all flex items-center justify-center gap-2 text-emerald-700 font-semibold"
                  >
                    <ImageIcon className="w-5 h-5" />
                    Add Image URL
                  </button>
                )}

                {errors.images && (
                  <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {errors.images}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="px-8 pb-8 pt-4 border-t border-gray-200 flex gap-4">
            <button
              onClick={handleClose}
              className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              disabled={titleCharCount < 5 || titleCharCount > 200 || contentCharCount < 50 || contentCharCount > 10000}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl font-semibold hover:from-emerald-700 hover:to-teal-700 transition-all shadow-lg shadow-emerald-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Upload className="w-4 h-4" />
              {isEditing ? 'Update Article' : 'Publish Article'}
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}