import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Mail, Lock, User, LogIn, UserPlus, AlertCircle, CheckCircle, KeyRound } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { GoogleOAuthSimulator } from './GoogleOAuthSimulator';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'login' | 'signup' | 'reset';
}

export function AuthModal({ isOpen, onClose, defaultMode = 'login' }: AuthModalProps) {
  const [mode, setMode] = useState<'login' | 'signup' | 'reset'>(defaultMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showGoogleAuth, setShowGoogleAuth] = useState(false);
  const [resetToken, setResetToken] = useState('');
  const [showResetForm, setShowResetForm] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const { login, signup, resetPassword, updatePasswordWithToken } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsLoading(true);

    try {
      if (mode === 'login') {
        const result = await login(email, password);
        if (result.success) {
          onClose();
          setEmail('');
          setPassword('');
        } else {
          setError(result.error || 'Login failed');
        }
      } else if (mode === 'signup') {
        if (!name.trim()) {
          setError('Please enter your name');
          setIsLoading(false);
          return;
        }
        const result = await signup(name, email, password);
        if (result.success) {
          onClose();
          setName('');
          setEmail('');
          setPassword('');
        } else {
          setError(result.error || 'Signup failed');
        }
      } else if (mode === 'reset') {
        if (!showResetForm) {
          // Step 1: Request reset token
          const result = await resetPassword(email);
          if (result.success && result.resetToken) {
            setSuccess(`Reset code generated: ${result.resetToken}`);
            setResetToken(result.resetToken || '');
            setShowResetForm(true);
            setError('');
          } else {
            setError(result.error || 'Failed to send reset email');
          }
        } else {
          // Step 2: Reset password with token
          if (newPassword !== confirmPassword) {
            setError('Passwords do not match');
            setIsLoading(false);
            return;
          }
          if (newPassword.length < 6) {
            setError('Password must be at least 6 characters');
            setIsLoading(false);
            return;
          }
          
          const result = await updatePasswordWithToken(email, resetToken, newPassword);
          if (result.success) {
            setSuccess('Password reset successfully! Redirecting to login...');
            setError('');
            setTimeout(() => {
              setShowResetForm(false);
              setResetToken('');
              setNewPassword('');
              setConfirmPassword('');
              setEmail('');
              switchMode('login');
            }, 2000);
          } else {
            setError(result.error || 'Failed to reset password');
          }
        }
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSuccess = async (userData: { email: string; name: string; avatar: string }) => {
    setIsLoading(true);
    
    const usersData = localStorage.getItem('ecovigyan_users');
    const users = usersData ? JSON.parse(usersData) : [];
    
    let user = users.find((u: any) => u.email === userData.email);
    
    if (!user) {
      user = {
        id: `member-${Date.now()}`,
        email: userData.email,
        name: userData.name,
        avatar: userData.avatar,
        role: 'member',
        authProvider: 'google',
        joinedDate: new Date().toISOString()
      };
      users.push(user);
      localStorage.setItem('ecovigyan_users', JSON.stringify(users));
    }
    
    const { password, ...userWithoutPassword } = user;
    localStorage.setItem('ecovigyan_current_user', JSON.stringify(userWithoutPassword));
    
    setShowGoogleAuth(false);
    setIsLoading(false);
    onClose();
    
    window.location.reload();
  };

  const switchMode = (newMode: 'login' | 'signup' | 'reset') => {
    setMode(newMode);
    setError('');
    setSuccess('');
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl max-w-md w-full shadow-2xl overflow-hidden"
        >
          {/* Header */}
          <div className="relative bg-gradient-to-r from-emerald-600 to-teal-600 p-8 text-white">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/30 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-3 mb-4">
              {mode === 'reset' ? (
                <KeyRound className="w-8 h-8" />
              ) : mode === 'login' ? (
                <LogIn className="w-8 h-8" />
              ) : (
                <UserPlus className="w-8 h-8" />
              )}
              <h2 className="text-3xl font-bold">
                {mode === 'reset' ? 'Reset Password' : mode === 'login' ? 'Welcome Back' : 'Join Us'}
              </h2>
            </div>
            <p className="text-emerald-50">
              {mode === 'reset'
                ? 'Enter your email to receive password reset instructions'
                : mode === 'login'
                ? 'Login to access your dashboard and contribute to conservation'
                : 'Create an account to enroll in programs and make an impact'}
            </p>
          </div>

          {/* Demo Credentials Info - only show for login */}
          {mode === 'login' && (
            <div className="bg-blue-50 border-l-4 border-blue-500 p-4 m-6 rounded">
              <p className="text-sm font-semibold text-blue-900 mb-2">🔑 Demo Credentials:</p>
              <div className="text-xs text-blue-800 space-y-1">
                <div><strong>Admin:</strong> admin@ecovigyan.org / admin123</div>
                <div><strong>Member:</strong> student@example.com / student123</div>
              </div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-8 pt-4 space-y-5">
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3"
              >
                <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                <p className="text-sm text-red-800">{error}</p>
              </motion.div>
            )}

            {success && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-start gap-3"
              >
                <CheckCircle className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
                <p className="text-sm text-green-800">{success}</p>
              </motion.div>
            )}

            {/* Google Sign In Button - show only for login and signup */}
            {mode !== 'reset' && (
              <>
                <button
                  type="button"
                  onClick={() => setShowGoogleAuth(true)}
                  className="w-full bg-white border-2 border-gray-300 text-gray-700 py-4 rounded-xl font-bold hover:bg-gray-50 transition-all shadow-sm flex items-center justify-center gap-3"
                >
                  <svg viewBox="0 0 24 24" className="w-6 h-6">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  Continue with Google
                </button>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-300"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-4 bg-white text-gray-500">Or continue with email</span>
                  </div>
                </div>
              </>
            )}

            {mode === 'signup' && (
              <div>
                <label htmlFor="name" className="block text-sm font-bold text-gray-700 mb-2">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-none transition-colors"
                    placeholder="Enter your name"
                    required={mode === 'signup'}
                  />
                </div>
              </div>
            )}

            <div>
              <label htmlFor="email" className="block text-sm font-bold text-gray-700 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-none transition-colors"
                  placeholder="your@email.com"
                  required
                />
              </div>
            </div>

            {mode !== 'reset' && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label htmlFor="password" className="block text-sm font-bold text-gray-700">
                    Password
                  </label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => switchMode('reset')}
                      className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold"
                    >
                      Forgot?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="password"
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-none transition-colors"
                    placeholder="••••••••"
                    required={mode !== 'reset'}
                    minLength={6}
                  />
                </div>
                {mode === 'signup' && (
                  <p className="text-xs text-gray-500 mt-2">At least 6 characters</p>
                )}
              </div>
            )}

            {showResetForm && (
              <>
                <div>
                  <label htmlFor="newPassword" className="block text-sm font-bold text-gray-700 mb-2">
                    New Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="password"
                      id="newPassword"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-none transition-colors"
                      placeholder="••••••••"
                      required
                      minLength={6}
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">At least 6 characters</p>
                </div>

                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-bold text-gray-700 mb-2">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="password"
                      id="confirmPassword"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-none transition-colors"
                      placeholder="••••••••"
                      required
                      minLength={6}
                    />
                  </div>
                </div>
              </>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-4 rounded-xl font-bold hover:from-emerald-700 hover:to-teal-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  {mode === 'login' ? 'Logging in...' : mode === 'signup' ? 'Creating account...' : showResetForm ? 'Resetting password...' : 'Generating code...'}
                </span>
              ) : (
                mode === 'login' ? 'Login' : mode === 'signup' ? 'Create Account' : showResetForm ? 'Reset Password' : 'Get Reset Code'
              )}
            </button>

            <div className="text-center space-y-2">
              {mode === 'reset' ? (
                <button
                  type="button"
                  onClick={() => switchMode('login')}
                  className="text-sm text-emerald-600 hover:text-emerald-700 font-semibold"
                >
                  ← Back to login
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => switchMode(mode === 'login' ? 'signup' : 'login')}
                  className="text-sm text-emerald-600 hover:text-emerald-700 font-semibold"
                >
                  {mode === 'login'
                    ? "Don't have an account? Sign up"
                    : 'Already have an account? Login'}
                </button>
              )}
            </div>
          </form>
        </motion.div>
      </div>

      {/* Google OAuth Simulator */}
      {showGoogleAuth && (
        <GoogleOAuthSimulator
          onSuccess={handleGoogleSuccess}
          onClose={() => setShowGoogleAuth(false)}
        />
      )}
    </>
  );
}