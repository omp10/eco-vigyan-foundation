import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, LogIn } from 'lucide-react';
import { AuthModal } from './AuthModal';

interface LoginPromptProps {
  title?: string;
  message?: string;
  feature: string;
}

export function LoginPrompt({ 
  title = "Login Required", 
  message,
  feature 
}: LoginPromptProps) {
  const [showAuthModal, setShowAuthModal] = useState(false);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-200 rounded-2xl p-8 text-center max-w-md mx-auto"
      >
        <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
          <Lock className="w-8 h-8 text-emerald-600" />
        </div>
        
        <h3 className="text-2xl font-bold text-emerald-900 mb-3 font-serif">
          {title}
        </h3>
        
        <p className="text-gray-600 mb-6">
          {message || `Please login or create an account to ${feature}.`}
        </p>

        <button
          onClick={() => setShowAuthModal(true)}
          className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-8 py-4 rounded-xl font-bold hover:from-emerald-700 hover:to-teal-700 transition-all shadow-lg flex items-center justify-center gap-2"
        >
          <LogIn className="w-5 h-5" />
          Login / Sign Up
        </button>

        <p className="text-xs text-gray-500 mt-4">
          Free to join • Instant access
        </p>
      </motion.div>

      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </>
  );
}
