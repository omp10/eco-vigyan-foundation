import React, { useState, useRef } from 'react';
import { X, Upload, FileSpreadsheet, AlertCircle, CheckCircle, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as XLSX from 'xlsx';
import { toast } from 'sonner';
import { MushroomObservation } from '../MySubmissions';

interface ImportExcelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (observations: MushroomObservation[]) => void;
}

export function ImportExcelModal({ isOpen, onClose, onImport }: ImportExcelModalProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const fileExtension = file.name.split('.').pop()?.toLowerCase();
      if (fileExtension === 'xlsx' || fileExtension === 'xls') {
        setSelectedFile(file);
      } else {
        toast.error('Please select a valid Excel file (.xlsx or .xls)');
      }
    }
  };

  const convertGoogleDriveLink = (link: string): string => {
    if (!link) return '';
    
    // Handle Google Drive links
    if (link.includes('drive.google.com')) {
      const fileIdMatch = link.match(/\/d\/([a-zA-Z0-9-_]+)/);
      if (fileIdMatch) {
        return `https://drive.google.com/uc?export=view&id=${fileIdMatch[1]}`;
      }
    }
    
    return link;
  };

  const parseExcelFile = async (file: File): Promise<MushroomObservation[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData: any[] = XLSX.utils.sheet_to_json(worksheet);

          const observations: MushroomObservation[] = jsonData.map((row, index) => {
            // Extract required fields
            const photoUrl = convertGoogleDriveLink(row['Photo/Image'] || row['photo/image'] || row['Photo'] || row['photo'] || '');
            const latitude = parseFloat(row['Latitude'] || row['latitude'] || row['Lat'] || row['lat'] || '0');
            const longitude = parseFloat(row['Longitude'] || row['longitude'] || row['Lng'] || row['lng'] || row['Long'] || row['long'] || '0');
            
            // Optional fields
            const name = row['Name'] || row['name'] || row['Common Name'] || row['common name'] || '';
            const stemValue = (row['Stem'] || row['stem'] || '').toLowerCase();
            const hasStem = stemValue.includes('has-stem') || stemValue.includes('yes') || stemValue.includes('true');
            const undersideValue = row['Bottom/Underside'] || row['bottom/underside'] || row['Underside'] || row['underside'] || '';
            const textureValue = row['Texture'] || row['texture'] || '';
            const roleValue = row['Role'] || row['role'] || row['Ecological Role'] || row['ecological role'] || '';
            const useValue = row['Use'] || row['use'] || row['Uses'] || row['uses'] || '';

            // Map underside values
            let undersideStructure: string | undefined;
            if (undersideValue) {
              const lowerUnderside = undersideValue.toLowerCase();
              if (lowerUnderside.includes('gill')) undersideStructure = 'gills';
              else if (lowerUnderside.includes('pore')) undersideStructure = 'pores';
              else if (lowerUnderside.includes('teeth')) undersideStructure = 'teeth';
              else undersideStructure = 'smooth';
            }

            // Map texture values
            let texture: string | undefined;
            if (textureValue) {
              const lowerTexture = textureValue.toLowerCase();
              if (lowerTexture.includes('soft')) texture = 'soft';
              else if (lowerTexture.includes('hard')) texture = 'hard';
              else if (lowerTexture.includes('jelly') || lowerTexture.includes('gelatinous')) texture = 'jelly-like';
              else if (lowerTexture.includes('leather')) texture = 'leathery';
              else if (lowerTexture.includes('brittle')) texture = 'brittle';
            }

            // Map ecological role
            let ecologicalRole: string[] | undefined;
            if (roleValue) {
              const lowerRole = roleValue.toLowerCase();
              const roles: string[] = [];
              if (lowerRole.includes('decomposer')) roles.push('decomposer');
              if (lowerRole.includes('symbiont') || lowerRole.includes('mycorrhizal')) roles.push('symbiont');
              if (lowerRole.includes('parasite')) roles.push('parasite');
              if (roles.length > 0) ecologicalRole = roles;
            }

            // Map uses/properties
            let commonUses: string[] | undefined;
            if (useValue) {
              const lowerUse = useValue.toLowerCase();
              const uses: string[] = [];
              if (lowerUse.includes('edible')) uses.push('edible');
              if (lowerUse.includes('inedible') || lowerUse.includes('not edible')) uses.push('inedible');
              if (lowerUse.includes('poison')) uses.push('poisonous');
              if (lowerUse.includes('medicinal') || lowerUse.includes('medicine')) uses.push('medicinal');
              if (uses.length > 0) commonUses = uses;
            }

            // Validate required fields
            if (!photoUrl || !latitude || !longitude) {
              throw new Error(`Row ${index + 2}: Missing required fields (Photo/Image, Latitude, Longitude)`);
            }

            const observation: MushroomObservation = {
              id: `system-import-${Date.now()}-${index}`,
              userId: 'system@ecovigyan.org', // System imports
              commonName: name,
              location: row['Location'] || row['location'] || `Imported Location ${index + 1}`,
              coordinates: {
                lat: latitude,
                lng: longitude
              },
              photoTimestamp: new Date().toISOString(),
              submittedAt: new Date().toISOString(),
              status: 'approved', // Auto-approve system imports
              approvedAt: new Date().toISOString(),
              approvedBy: 'system',
              images: [photoUrl],
              description: row['Description'] || row['description'] || row['Notes'] || row['notes'] || '',
              ecologicalRole: ecologicalRole,
              texture: texture,
              underside: undersideStructure,
              stemPresence: stemValue ? (hasStem ? 'has-stem' : 'has-no-stem') : undefined,
              properties: commonUses,
            };

            return observation;
          });

          resolve(observations);
        } catch (error) {
          reject(error);
        }
      };

      reader.onerror = () => {
        reject(new Error('Failed to read file'));
      };

      reader.readAsBinaryString(file);
    });
  };

  const handleImport = async () => {
    if (!selectedFile) {
      toast.error('Please select a file first');
      return;
    }

    setIsProcessing(true);

    try {
      const observations = await parseExcelFile(selectedFile);
      
      if (observations.length === 0) {
        toast.error('No valid observations found in the Excel file');
        setIsProcessing(false);
        return;
      }

      onImport(observations);
      toast.success(`Successfully imported ${observations.length} mushroom observation${observations.length > 1 ? 's' : ''}!`);
      
      // Reset and close
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      onClose();
    } catch (error) {
      console.error('Import error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to import Excel file. Please check the format.');
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadTemplate = () => {
    // Create sample data
    const templateData = [
      {
        'Photo/Image': 'https://drive.google.com/file/d/YOUR_FILE_ID/view',
        'Latitude': '19.0760',
        'Longitude': '72.8777',
        'Name': 'Button Mushroom',
        'Location': 'Mumbai, Maharashtra',
        'Stem': 'has-stem',
        'Bottom/Underside': 'gills',
        'Texture': 'soft-to-touch',
        'Role': 'decomposer',
        'Use': 'edible',
        'Description': 'Found in urban garden'
      }
    ];

    // Create worksheet
    const ws = XLSX.utils.json_to_sheet(templateData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Mushrooms');

    // Save file
    XLSX.writeFile(wb, 'mushroom_import_template.xlsx');
    toast.success('Template downloaded!');
  };

  const handleClose = () => {
    if (!isProcessing) {
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="fixed inset-0 bg-black/50 z-50 backdrop-blur-sm"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={handleClose}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="sticky top-0 bg-white border-b border-gray-200 px-8 py-6 flex items-center justify-between rounded-t-2xl z-10">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                    <FileSpreadsheet className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Import System Data</h2>
                    <p className="text-sm text-gray-600 mt-1">Bulk upload reference mushroom data from Excel</p>
                  </div>
                </div>
                <button
                  onClick={handleClose}
                  disabled={isProcessing}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-50"
                >
                  <X className="w-6 h-6 text-gray-500" />
                </button>
              </div>

              {/* Content */}
              <div className="px-8 py-6 space-y-6">
                {/* Download Template Button */}
                <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-purple-900">Need a template?</h3>
                    <p className="text-sm text-purple-700">Download our Excel template with sample data</p>
                  </div>
                  <button
                    onClick={downloadTemplate}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-semibold hover:bg-purple-700 transition-all flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Download Template
                  </button>
                </div>

                {/* File Upload */}
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-3">
                    Excel File (.xlsx, .xls)
                  </label>
                  <div className="relative">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".xlsx,.xls"
                      onChange={handleFileSelect}
                      disabled={isProcessing}
                      className="block w-full text-sm text-gray-900 border border-gray-300 rounded-xl cursor-pointer bg-gray-50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent p-3 disabled:opacity-50"
                    />
                    {selectedFile && (
                      <div className="mt-3 flex items-center gap-2 text-sm text-purple-600">
                        <CheckCircle className="w-4 h-4" />
                        <span>{selectedFile.name}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Expected Format Guide */}
                <div className="bg-purple-50 border border-purple-200 rounded-xl p-6">
                  <h3 className="text-lg font-bold text-purple-900 mb-4">Expected Excel Format:</h3>
                  
                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="font-bold text-purple-800">Photo/Image:</span>{' '}
                      <span className="text-purple-700">Google Drive link or direct URL</span>{' '}
                      <span className="text-red-600">*Required</span>
                    </div>
                    <div>
                      <span className="font-bold text-purple-800">Latitude:</span>{' '}
                      <span className="text-purple-700">Decimal format (e.g., 19.0760)</span>{' '}
                      <span className="text-red-600">*Required</span>
                    </div>
                    <div>
                      <span className="font-bold text-purple-800">Longitude:</span>{' '}
                      <span className="text-purple-700">Decimal format (e.g., 72.8777)</span>{' '}
                      <span className="text-red-600">*Required</span>
                    </div>
                    <div className="pt-2 border-t border-purple-200">
                      <p className="font-bold text-purple-800 mb-1">Optional Fields:</p>
                    </div>
                    <div>
                      <span className="font-bold text-purple-800">Name:</span>{' '}
                      <span className="text-purple-700">Common or scientific name</span>
                    </div>
                    <div>
                      <span className="font-bold text-purple-800">Location:</span>{' '}
                      <span className="text-purple-700">Place name or description</span>
                    </div>
                    <div>
                      <span className="font-bold text-purple-800">Stem:</span>{' '}
                      <span className="text-purple-700">"has-stem" or "has-no-stem"</span>
                    </div>
                    <div>
                      <span className="font-bold text-purple-800">Bottom/Underside:</span>{' '}
                      <span className="text-purple-700">"gills", "pores", "teeth", "smooth"</span>
                    </div>
                    <div>
                      <span className="font-bold text-purple-800">Texture:</span>{' '}
                      <span className="text-purple-700">"soft", "hard", "jelly-like", "leathery"</span>
                    </div>
                    <div>
                      <span className="font-bold text-purple-800">Role:</span>{' '}
                      <span className="text-purple-700">"decomposer", "symbiont", "parasite"</span>
                    </div>
                    <div>
                      <span className="font-bold text-purple-800">Use:</span>{' '}
                      <span className="text-purple-700">"edible", "inedible", "poisonous", "medicinal"</span>
                    </div>
                    <div>
                      <span className="font-bold text-purple-800">Description:</span>{' '}
                      <span className="text-purple-700">Notes or additional details</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-purple-200">
                    <p className="text-sm text-purple-700 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                      <span><strong>System Imports:</strong> All imported observations are automatically approved, assigned to system@ecovigyan.org, and can be filtered separately in the dashboard.</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-8 py-4 flex items-center justify-end gap-3 rounded-b-2xl">
                <button
                  onClick={handleClose}
                  disabled={isProcessing}
                  className="px-6 py-2.5 text-gray-700 font-semibold rounded-xl hover:bg-gray-200 transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleImport}
                  disabled={!selectedFile || isProcessing}
                  className="px-6 py-2.5 bg-purple-600 text-white font-semibold rounded-xl hover:bg-purple-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  <Upload className="w-4 h-4" />
                  {isProcessing ? 'Importing...' : 'Import'}
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}