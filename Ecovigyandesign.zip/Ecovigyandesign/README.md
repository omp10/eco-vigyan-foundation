
  # Extract designs from URL

  This is a code bundle for Extract designs from URL. The original project is available at https://www.figma.com/design/WhN3fUB12aw1Dqha9eqPlB/Extract-designs-from-URL.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  